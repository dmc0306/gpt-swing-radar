"""Frozen numeric score only. No training, orders, alerts or paper mutation."""
import json,math,struct,bisect
from pathlib import Path
from functools import lru_cache
@lru_cache(maxsize=1)
def model():return json.loads((Path(__file__).parent/'reports/pattern-model.json').read_text())
def predict(m,features):
    x=[float(features[k]) for k in m['features']]
    if m['kind']=='logistic':
        z=m['intercept']+sum(w*(v-a)/s for w,v,a,s in zip(m['coef'],x,m['mean'],m['scale']))
        return 1/(1+math.exp(-max(-50,min(50,z))))
    # sklearn tree inference converts numeric inputs to float32.
    x=[struct.unpack('f',struct.pack('f',v))[0] for v in x];i=0
    while m['children_left'][i]!=-1:i=m['children_left'][i] if x[m['feature_index'][i]]<=m['threshold'][i] else m['children_right'][i]
    return m['values'][i]
def score_one(m,row):
    features=row['features'];raw=predict(m,features)
    bucket=next((b for b in m['bands'] if b['upper'] is None or raw<b['upper']),m['bands'][-1])
    score=round(100*bisect.bisect_right(m['score_quantiles'],raw)/len(m['score_quantiles']),1)
    outside=[k for k,(lo,hi) in m['feature_range'].items() if features[k]<lo or features[k]>hi]
    factors=sorted([{'feature':k,'contribution':w*(features[k]-a)/sd} for k,w,a,sd in zip(m['features'],m.get('coef',[]),m.get('mean',[]),m.get('scale',[]))],key=lambda x:-abs(x['contribution']))[:4]
    return {'factors':factors,'score':score,'raw_model_value':raw,'above_cut':raw>=m['top_cut'],'calibration':bucket['cal'],'later':bucket['later'],'out_of_range':outside,'gate_pass':m['gate_pass'],'model_kind':m['kind']}
def build(pool,gate,now,expected,config,budget):
    import reward_candidates
    trained=model();rows=[];blocked=[];today=now.date().isoformat()
    fixed=config.copy();fixed.update(fee_pct=.2,slippage_pct=.05)
    for row in pool.get('pattern_rows',[]):
        d=gate.decision(row['code'],today,now.isoformat(timespec='seconds'))
        reasons=[]
        if not d['allowed']:reasons.append(d['reason'])
        if pool['latest']!=expected:reasons.append('필요한 가격 날짜 불일치')
        if pool['filtered']:reasons.append('당일 미완성/미래 날짜가 제외됨 · 자료 확인 필요')
        if row['close']<max(1000,config['min_price']) or row['turnover']<max(1e9,config['min_turnover']):continue
        win=None if row['features']['atr_pct']*1.5>8 else score_one(trained['win'],row)
        jump=score_one(trained['jump'],row)
        sig={**row,'volume_limit':row['volume_limit']*config['max_participation_pct']/100}
        q=reward_candidates.quote(sig,row['close'],fixed,budget,.4,True)
        price_reasons=list(dict.fromkeys(reasons+q['reasons']))
        if config['fee_pct']!=.2 or config['slippage_pct']!=.05:price_reasons.append('현재 비용 설정이 모델 계산 기준과 다름')
        entry={**row,'win_score':win,'jump_score':jump,'eligibility':d,'data_reasons':reasons,'price_reasons':price_reasons,'reference_level':q,'trade_allowed':False,'observation_only':True}
        (blocked if reasons else rows).append(entry)
    rows.sort(key=lambda r:(-(r['win_score']['raw_model_value'] if r['win_score'] else -1),-r['jump_score']['raw_model_value'],r['code']))
    blocked.sort(key=lambda r:(-(r['win_score']['raw_model_value'] if r['win_score'] else -1),r['code']))
    return {'rows':rows,'blocked':blocked,'excluded_count':len(blocked),'feature_failures':pool.get('pattern_failures',{}),'entry_day':pool.get('pattern_entry_day'),'calendar_note':pool.get('pattern_calendar_note'),'model_id':trained['id'],'overview':trained['summary'],'trained_through':'2025-08-31','calibrated_through':'2026-03-31','evaluated_through':'2026-09-29','note':'점수는 과거 지표로 만든 관찰 순위입니다. 동일 점수구간의 과거 승률과 이후 재분석 비율을 보여줍니다. 오늘 현재가에서 매수한 승률이나 보장된 확률이 아닙니다.','win_rule':'다음 거래일 시가 · 0.4R 전량익절 · 1.5ATR 손절 · 최대15일 · 최초위험폭8% 이하 · 시가갭1ATR 이내 · 비용0.2%/편도슬리피지0.05%','jump_rule':'다음 관측일 종가가 신호 종가보다5% 이상 상승. 실제매매 승률과 별도.'}
