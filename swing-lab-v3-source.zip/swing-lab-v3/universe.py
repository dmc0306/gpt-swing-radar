"""Current-universe discovery; never represents historical constituents."""
import json, re, time
from datetime import datetime
from zoneinfo import ZoneInfo
import data_source, store, eligibility
import market_cache

PATH=store.ROOT/'universe.json'
def get():return json.loads(PATH.read_text()) if PATH.exists() else None

def discover(options,years,progress):
    from kiwoom import _post
    minimum=float(options.get('min_price',1000));turnover=float(options.get('min_turnover',1000000000));limit=int(options.get('limit',1000))
    if not 0<=minimum<=1000000 or not 0<=turnover<=1e13 or not 10<=limit<=market_cache.MAX_SYMBOLS:raise ValueError('주가 0~100만원, 거래대금 0~10조원, 종목 수 10~3000 범위')
    cache_before=market_cache.snapshot()
    today=datetime.now(ZoneInfo('Asia/Seoul'));stamp=today.date().isoformat();cache_day=stamp+('-closed' if today.hour*60+today.minute>=940 else '-before-close')
    report={'code_hash':store.code_hash(),'flow_id':options.get('flow_id'),'started':store.now(),'status':'목록 조회','options':{'min_price':minimum,'min_turnover':turnover,'limit':limit},'errors':[],'selected':[], 'note':'현재 상장·현재 유동성으로 고른 종목입니다. 과거 평가에는 생존·선택 및 미래정보 편향이 있습니다.'}
    store.write(PATH,report)
    try:
        allstocks={};gate=eligibility.Gate(live=True);excluded=unknown=0
        for market in ('0','10'):
            cont=key=None;seen=set()
            for page in range(30):
                progress(stage=('코스피' if market=='0' else '코스닥')+' 종목 목록 조회',done=page,total=30)
                response,data=_post('/api/dostk/stkinfo','ka10099',{'mrkt_tp':market},cont_yn=cont,next_key=key)
                if not isinstance(data.get('list'),list):raise ValueError('종목 목록 응답 형식 오류: list 없음')
                for r in data['list']:
                    code=str(r.get('code','')).strip();name=str(r.get('name','')).strip();mc=str(r.get('marketCode','')).strip()
                    if not re.fullmatch(r'[0-9A-Z]{6}',code) or mc not in ('0','10'):continue
                    observed=eligibility.api_row(r,store.now())
                    if observed['screen']['blocked']:excluded+=1;continue
                    if not observed['screen']['allowed']:unknown+=1;continue
                    decision=gate.decision(code,stamp,store.now())
                    if not decision['allowed']:
                        if decision['reason'].startswith('제외:'):excluded+=1
                        else:unknown+=1
                        continue
                    allstocks[code]={'code':code,'name':name or code,'market':mc}
                cont=response.headers.get('cont-yn');key=response.headers.get('next-key')
                if cont!='Y':break
                if not key or key in seen:raise ValueError('종목 목록 연속조회 키 누락/반복')
                seen.add(key);time.sleep(.3)
            else:raise ValueError('목록 조회 페이지 상한 초과: 전체 목록을 확보하지 못했습니다.')
        report.update(exclusion={'excluded':excluded,'unknown':unknown,'allowed':len(allstocks)});store.write(PATH,report)
        if not allstocks:raise ValueError('자동 선별을 통과한 후보가 없습니다. 상태 수집 결과와 제외/미확인 사유를 확인하세요.')
        report.update(status='유동성 조사',listed=len(allstocks));store.write(PATH,report)
        screens=[]
        for i,(code,stock) in enumerate(sorted(allstocks.items())):
            progress(stage=f'유동성 확인 · {stock["name"]}',done=i,total=len(allstocks))
            cache=store.ROOT/'screen_cache'/cache_day/(code+'.json')
            try:
                if cache.exists():screen=json.loads(cache.read_text());market_cache.count('screen_cache_hits')
                else:
                    hist=store.ROOT/'history_cache'/(code+'.json')
                    cached=json.loads(hist.read_text()) if hist.exists() else None
                    if cached and cached.get('checked')==cache_day:
                        rows=cached['rows'];market_cache.count('screen_from_history')
                    else:
                        first,_,_=market_cache.first_page(code)
                        rows,_=data_source.normalize(data_source.map_bars(first,code,stock['name']))
                    rows=sorted(rows,key=lambda r:r['date'])[-20:]
                    screen={**stock,'date':rows[-1]['date'],'close':rows[-1]['close'],'days':len(rows),'volume':rows[-1]['volume'],'turnover':sum(r['close']*r['volume'] for r in rows)/len(rows)}
                    store.write(cache,screen)
                screens.append(screen)
            except InterruptedError:raise
            except Exception as e:
                report['errors'].append({'code':code,'error':str(e)[:180]});time.sleep(.3)
            if (i+1)%25==0:report['checked']=i+1;store.write(PATH,report)
        if not screens:raise ValueError('유동성을 확인한 종목이 없습니다.')
        latest=max(s['date'] for s in screens)
        eligible=[s for s in screens if s['date']==latest and s['days']==20 and s['volume']>0 and s['close']>=minimum and s['turnover']>=turnover]
        eligible.sort(key=lambda s:(-s['turnover'],s['code']));chosen=eligible[:limit]
        report.update(checked=len(allstocks),eligible=len(eligible),selected=chosen,asof=latest,status='과거 일봉 수집',cache_summary=market_cache.delta(cache_before),limited_out=max(0,len(eligible)-len(chosen)))
        store.write(PATH,report)
        if not chosen:raise ValueError('조건에 맞는 종목이 없습니다. 필터를 완화하세요.')
        result=data_source.collect([s['code'] for s in chosen],years,progress,names={s['code']:s['name'] for s in chosen},note=report['note'])
        report.update(status='완료',finished=store.now(),dataset_id=result['dataset']['id'],history_errors=result['errors'],cache_summary=market_cache.delta(cache_before))
        store.write(PATH,report)
        return result
    except InterruptedError:
        report.update(status='일시정지');store.write(PATH,report);raise
    except Exception as e:
        report.update(status='실패',error=str(e),finished=store.now());store.write(PATH,report);raise
