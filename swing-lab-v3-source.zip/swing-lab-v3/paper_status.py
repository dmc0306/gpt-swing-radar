"""Read-only operating diagnostics. Never modifies an account or evidence."""
from collections import Counter
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
import session_calendar,store

def next_check(now,enabled):
    if not enabled:return None
    explicit=session_calendar.get()['days']
    for offset in range(370):
        day=now.date()+timedelta(days=offset)
        if day.weekday()>4 or explicit.get(day.isoformat())==0:continue
        candidate=datetime.combine(day,datetime.min.time(),tzinfo=now.tzinfo).replace(hour=15,minute=40)
        if candidate>now:return {'at':candidate.isoformat(),'confirmed_session':explicit.get(day.isoformat())==1,'note':'자료 수집 시작 예정 · 완료 후 정산. 휴장·중단 작업·진행 작업에 따라 지연될 수 있습니다.'}
    return None

def describe(group,settings,datasets,now=None):
    if not group:return None
    now=now or datetime.now(ZoneInfo('Asia/Seoul'))
    latest=max(datasets,key=lambda d:(d.get('end',''),d.get('created','')),default={})
    active=bool(group.get('active'));blocked=group.get('blocked');readonly=group.get('read_only')
    status='ended' if not active else 'incompatible' if readonly else 'blocked' if blocked else 'waiting'
    labels={'ended':'종료','incompatible':'갱신 차단','blocked':'정산 보류','waiting':'진행 중 · 정산 대기'}
    accounts=[]
    for a in group.get('accounts',[group]):
        b=a.get('book',{});events=b.get('events',[]);last=b.get('last_date')
        counts=Counter(x.get('reason','미확인') for x in events if x.get('date')==last)
        pending=b.get('pending',[]);positions=b.get('positions',[])
        evidence=None
        if group.get('schema')==2 and last:
            path=store.ROOT/'paper_shared_evidence'/(group['id']+'-'+last+'.json')
            if path.exists():
                import json
                e=json.loads(path.read_text());decisions=e.get('exclusion_decisions',{})
                evidence={'mode':e.get('signal_mode'),'new_signals':len(e.get('signals',{}).get(a['id'],[])),'restricted_symbols':sum(not d.get('allowed',False) for d in decisions.values())}
        reason='계좌가 종료되어 자동 정산하지 않습니다.' if not a.get('active') else '계산 버전이 달라 갱신을 차단했습니다.' if readonly else blocked.get('reason','자료 확인 필요') if blocked else '다음 거래일 시가 체결 대기' if pending else '보유 종목의 손절·익절 조건을 관찰합니다.' if positions else '마지막 관찰일에 신규 신호가 없습니다.' if evidence and evidence['mode']=='observed_today' else '아직 당일 신호를 관찰하지 않았습니다.'
        accounts.append({**a,'diagnostics':{'status':status if a.get('active') else 'ended','reason':reason,'last_settlement':last,'last_trade':max([t.get('exit_date','') for t in b.get('trades',[])]+[p.get('entry_date','') for p in positions],default='') or None,'pending':len(pending),'positions':len(positions),'rejections':[{'reason':k,'count':v} for k,v in counts.items()],'evidence':evidence}})
    return {**group,'accounts':accounts,'operating':{'status':status,'label':labels[status],'price_date':latest.get('end'),'last_settlement':group.get('last_date'),'automatic':bool(settings.get('auto')),'next_check':next_check(now,bool(settings.get('auto'))) if active and not readonly else None,'execution':'확정 일봉 → 다음 거래일 시가 가상 체결','intraday_supported':False,'checked_at':now.isoformat(timespec='seconds')}}
