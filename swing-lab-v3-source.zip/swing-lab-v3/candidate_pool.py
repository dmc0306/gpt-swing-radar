"""One bounded-memory pass for all five daily strategies. No quote/permission cache."""
import copy, hashlib, json, threading
from pathlib import Path
import engine, store, price_store, candidate_diagnostics, pattern_features

LOCK=threading.RLock()

def version():
    root=Path(__file__).parent
    names=('candidate_pool.py','engine.py','focus_indicators.py','candidate_diagnostics.py','strategies.py','reports/curated-five.json','pattern_features.py','pattern_rank.py','reports/pattern-model.json')
    return hashlib.sha256(b''.join((root/n).read_bytes() for n in names)).hexdigest()

def load(ident,cfg,today,closed,progress=lambda **kw:None):
    import session_calendar
    key=store.digest([ident,today,closed,session_calendar.get(),{k:cfg[k] for k in ('min_price','min_turnover','max_participation_pct')},version()])
    path=store.ROOT/'signal_cache'/('pool-'+key+'.json')
    with LOCK:
        if path.exists():
            try:return json.loads(path.read_text()),True
            except (ValueError,OSError):pass
        data=price_store.Dataset(ident,before=today,inclusive=closed)
        days=data.days();codes=data.codes()
        if not days:raise ValueError('확정된 하루 가격이 없습니다. 장 마감 후 자료를 받으세요.')
        latest=days[-1];recent=set(days[-140:]);breadth={};stale=[];short=0
        from datetime import date,timedelta
        import session_calendar
        calendar=session_calendar.get()['days'];entry=date.fromisoformat(latest)+timedelta(days=1)
        for _ in range(31):
            known=calendar.get(entry.isoformat())
            if known==1 or (known is None and entry.weekday()<5):break
            entry+=timedelta(days=1)
        entry_day=entry.isoformat();calendar_note='사용자 달력' if calendar.get(entry_day)==1 else '다음 평일 추정 · 휴장일 확인 필요'
        pattern_rows=[];pattern_failures={}
        signals={s:[] for s in engine.STRATEGIES};diagnostics={s:[] for s in engine.STRATEGIES}
        for i,(code,rows) in enumerate(data.items()):
            progress(stage='5개 방법 함께 확인 · '+rows[-1]['name'],done=i,total=len(codes))
            if len(rows)<120:short+=1
            if rows[-1]['date']!=latest:stale.append(code);continue
            extra={'_missing_days':len(recent-{r['date'] for r in rows}),
                   '_bar_invalid':rows[-1]['volume']<=0 or rows[-1]['high']==rows[-1]['low']}
            feature,reason=pattern_features.extract(rows,days,entry_day)
            if feature:pattern_rows.append(feature)
            else:pattern_failures[reason]=pattern_failures.get(reason,0)+1
            prepared=engine.prepare(rows,cfg)
            breadth.update(prepared['breadth'].get(latest,{}))
            for kind in signals:
                signals[kind].extend({**s,**extra} for s in prepared['signals'][kind].get(latest,[]))
                detail=candidate_diagnostics.inspect(rows,cfg,kind,latest)
                if detail:diagnostics[kind].append({**detail,**extra})
            del prepared,rows
        for rows in signals.values():
            rows.sort(key=lambda s:(-s['score'],s['code']))
            for s in rows:s.update(breadth_count=len(breadth),breadth_pct=100*sum(breadth.values())/len(breadth) if breadth else 0)
        result={'pattern_rows':pattern_rows,'pattern_failures':pattern_failures,'pattern_entry_day':entry_day,'pattern_calendar_note':calendar_note,'signals':signals,'diagnostics':diagnostics,'breadth':breadth,'days':days,'latest':latest,
                'stale':stale,'short':short,'symbols':len(codes),'codes':codes,
                'filtered':len(data)!=len(price_store.Dataset(ident))}
        progress(stage='후보 계산 저장',done=len(codes),total=len(codes))
        store.write(path,result)
        return result,False

def project(pool,spec):
    kind=spec['strategy'];day=pool['latest'];raw=pool['signals'][kind]
    signals=engine.select_signals({'signals':{kind:{day:raw}}},day,spec)
    # summarize appends a filter check; each strategy must get a separate copy.
    details=copy.deepcopy(pool['diagnostics'][kind])
    funnel,watch=candidate_diagnostics.summarize(details,spec,pool['breadth'])
    return {**{k:pool[k] for k in ('days','latest','stale','short','symbols','codes','filtered')},
            'signals':signals,'watchlist':watch,'condition_funnel':funnel,
            'score_details':{r['code']:{'checks':r['checks'],'condition_score':r['condition_score']} for r in details},
            'funnel':[{'label':'검색 종목','count':pool['symbols']},
                      {'label':'최신 일봉 있음','count':pool['symbols']-len(pool['stale'])},
                      {'label':'진입 지표 신호','count':len(raw)},
                      {'label':'전략 필터 통과','count':len(signals)}]}
