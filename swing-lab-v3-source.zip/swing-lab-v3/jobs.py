import copy, json, secrets, threading, time
from concurrent.futures import ThreadPoolExecutor
from fastapi import HTTPException
import store, alerts, workflows, operations

PATH=store.ROOT/'job.json';LOCK=threading.RLock();PAUSE=threading.Event();POOL=ThreadPoolExecutor(max_workers=1)
JOB=json.loads(PATH.read_text()) if PATH.exists() else {'running':False,'stage':'대기','done':0,'total':0,'error':None,'result':None}
if JOB.get('running'):JOB.update(running=False,paused=True,stage='서버 재시작 · 이어받기 가능' if JOB.get('task') else '서버 재시작 · 작업을 다시 시작하세요.')
_last_write=0.

def snapshot():
    with LOCK:return copy.deepcopy(JOB)

def persist():store.write(PATH,JOB)

def progress(**kw):
    global _last_write
    if PAUSE.is_set():raise InterruptedError('사용자 요청 또는 서버 종료로 일시정지')
    with LOCK:
        JOB.update(kw)
        if time.monotonic()-_last_write>1:persist();_last_write=time.monotonic()

def submit(fn=None,task=None,resuming=False):
    operations.available()
    with LOCK:
        if JOB['running']:raise HTTPException(409,'진행 중인 작업이 있습니다.')
        if operations.HEAVY.locked():raise HTTPException(409,'후보 조회 또는 자료 내보내기가 진행 중입니다. 완료 후 다시 시도하세요.')
        if JOB.get('task') and (JOB.get('paused') or JOB.get('error')) and not resuming:raise HTTPException(409,'중단 작업이 있습니다. 이어받거나 기록 보관 후 새 작업을 시작하세요.')
        recipe=copy.deepcopy(task)
        if recipe:recipe.setdefault('id',secrets.token_hex(12))
        PAUSE.clear();JOB.update(running=True,paused=False,stage='시작',done=0,total=1,error=None,result=None,task=recipe);persist()
    def work():
        try:
            with operations.access(),operations.compute():
                result=workflows.execute(recipe,progress) if recipe else fn()
            with LOCK:JOB.update(running=False,paused=False,stage='완료',result=result);persist()
        except InterruptedError:
            with LOCK:JOB.update(running=False,paused=True,stage='일시정지 · 이어받기 가능' if recipe else '일시정지 · 같은 작업을 다시 시작하세요.',error=None);persist()
        except Exception as exc:
            with LOCK:JOB.update(running=False,paused=False,stage='실패',error=str(exc));persist()
            alerts.add([recipe.get('id') if recipe else store.now(),'failure',str(exc)],'error','작업 실패',str(exc)[:400])
    POOL.submit(work);return {'ok':True}

def pause():
    with LOCK:
        if JOB['running']:PAUSE.set();JOB['stage']='현재 처리 후 일시정지';persist()
    return {'ok':True}

def resume():
    with LOCK:
        if JOB['running']:raise HTTPException(409,'현재 처리 후 다시 시도하세요.')
        if not JOB.get('task') or not (JOB.get('paused') or JOB.get('error')):raise ValueError('이어받을 작업이 없습니다.')
        return submit(task=JOB['task'],resuming=True)


def archive_interrupted():
    with LOCK:
        if JOB.get('running'):raise HTTPException(409,'실행 중에는 중단 작업을 보관할 수 없습니다.')
        if not JOB.get('task'):raise ValueError('보관할 중단 작업이 없습니다.')
        ident=JOB['task']['id'];store.write(store.ROOT/'job_archive'/(ident+'.json'),JOB)
        JOB.update(running=False,paused=False,error=None,task=None,stage='중단 작업 기록 보관 완료')
        persist();return {'ok':True,'archived_task':ident}
