"""Resumable per-symbol history with overlap checks for adjusted-price revisions."""
import json, time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import store
import market_cache

def history(code,name,years,progress,force=False):
    from kiwoom import _post
    from data_source import normalize,map_bars
    now=datetime.now(ZoneInfo('Asia/Seoul'));end=now.date();start=end-timedelta(days=365*years+30)
    label=end.isoformat()+('-closed' if now.hour*60+now.minute>=940 else '-before-close')
    path=store.ROOT/'history_cache'/(code+'.json');part=store.ROOT/'history_parts'/(code+'.json')
    old=json.loads(path.read_text()) if path.exists() else None
    if not force and old and old.get('covered_start','9999')<=start.isoformat() and old.get('checked')==label:
        market_cache.count('history_cache_hits')
        return [{**r,'name':name} for r in old['rows'] if r['date']>=start.isoformat()]
    incremental=not force and bool(old) and old.get('covered_start','9999')<=start.isoformat()
    market_cache.count('history_incremental' if incremental else 'history_full')
    cutoff=max(start.isoformat(),(datetime.fromisoformat(old['rows'][-1]['date']).date()-timedelta(days=35)).isoformat()) if incremental else start.isoformat()
    signature={'code':code,'label':label,'cutoff':cutoff,'incremental':incremental}
    saved=json.loads(part.read_text()) if part.exists() else {}
    checkpoint=saved if saved.get('signature')==signature else {'signature':signature,'raw':[],'cont':None,'key':None,'pages':0,'complete':False,'seen':[]}
    # Continuation keys can expire across process downtime: restart paging, retain completed symbol caches.
    for restart in range(2):
        try:
            while not checkpoint['complete']:
                progress(stage=f'{name} · 일봉 {checkpoint["pages"]+1}페이지')
                if checkpoint['pages']>=80:raise ValueError('일봉 페이지 상한 초과')
                if checkpoint['pages']==0:
                    batch,cont,key=market_cache.first_page(code,refresh=force or restart>0,cutoff=cutoff.replace('-',''))
                else:
                    response,data=_post('/api/dostk/chart','ka10081',{'stk_cd':code,'base_dt':end.strftime('%Y%m%d'),'upd_stkpc_tp':'1'},cont_yn=checkpoint['cont'],next_key=checkpoint['key'])
                    batch=data.get('stk_dt_pole_chart_qry') or []
                    cont=response.headers.get('cont-yn');key=response.headers.get('next-key');market_cache.count('continuation_requests');time.sleep(.3)
                complete=not batch or min(str(r.get('dt','99999999')) for r in batch)<=cutoff.replace('-','') or cont!='Y'
                if not complete and (not key or key in checkpoint['seen']):raise ValueError('일봉 연속조회 키 누락/반복')
                checkpoint['raw'].extend(batch);checkpoint.update(cont=cont,key=key,pages=checkpoint['pages']+1,complete=complete)
                if key:checkpoint['seen'].append(key)
                store.write(part,checkpoint)
            break
        except InterruptedError:raise
        except Exception:
            if restart:raise
            checkpoint={'signature':signature,'raw':[],'cont':None,'key':None,'pages':0,'complete':False,'seen':[]};saved={}
    rows,_=normalize(map_bars(checkpoint['raw'],code,name));rows=sorted(rows,key=lambda r:r['date'])
    if incremental:
        previous={r['date']:r for r in old['rows']};overlap=[r for r in rows if r['date'] in previous]
        revised=any(any(abs(r[k]-previous[r['date']][k])>1e-7 for k in ('open','high','low','close','volume')) for r in overlap)
        if not overlap or revised:
            market_cache.count('history_revisions')
            progress(stage=f'{name} · 가격 기준 재확인, 전체 이력 갱신')
            return history(code,name,years,progress,force=True)
        previous.update({r['date']:r for r in rows});rows=sorted(previous.values(),key=lambda r:r['date'])
    rows=[{**r,'name':name} for r in rows if r['date']>=start.isoformat()]
    if not rows:raise ValueError('요청 기간에 완성된 일봉 없음')
    store.write(path,{'rows':rows,'covered_start':start.isoformat(),'checked':label,'updated':store.now(),'mode':'incremental' if incremental else 'full'})
    if part.exists():part.unlink()
    return rows
