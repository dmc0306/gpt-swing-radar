"""Input quality, not a claim of investment validity or exchange-calendar coverage."""
from collections import defaultdict
from pathlib import Path
import json
import store, price_store

def inspect(ident,expected=None,errors=None,progress=lambda **kw:None):
    data=price_store.Dataset(ident);codes=data.codes();days=data.days()
    if not days:raise ValueError('가격 자료 없음')
    index={d:i for i,d in enumerate(days)};items=[]
    for i,(code,rs) in enumerate(data.items()):
        progress(stage='종목별 품질 점검',done=i,total=len(codes))
        rs.sort(key=lambda r:r['date']);dates={r['date'] for r in rs}
        missing=[d for d in days[index[rs[0]['date']]:index[rs[-1]['date']]+1] if d not in dates]
        items.append({'code':code,'name':rs[-1]['name'],'bars':len(rs),'start':rs[0]['date'],'end':rs[-1]['date'],
                      'internal_gaps':len(missing),'gap_examples':missing[:10],'zero_volume':sum(r['volume']==0 for r in rs),
                      'short':len(rs)<140,'stale':rs[-1]['date']<days[-1]})
    absent=sorted(set(expected or [])-set(codes))
    value={'dataset_id':ident,'created':store.now(),'symbols':len(items),'days':len(days),'start':days[0],'end':days[-1],
           'short_count':sum(x['short'] for x in items),'stale_count':sum(x['stale'] for x in items),
           'gap_count':sum(x['internal_gaps'] for x in items),'absent':absent,'errors':errors or [],'items':items,
           'note':'누락은 데이터 내 전체 날짜 합집합과 비교합니다. 거래소 달력이나 거래정지 여부를 확정하지 않으며 누락값을 임의로 채우지 않습니다.'}
    progress(stage='품질 점검 완료',done=len(codes),total=len(codes))
    store.write(store.ROOT/'quality'/(ident+'.json'),value);return value

def get(ident):
    store.check_id(ident)
    path=store.ROOT/'quality'/(ident+'.json')
    return json.loads(path.read_text()) if path.exists() else inspect(ident)
