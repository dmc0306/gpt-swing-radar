"""Resolve display names from saved metadata without changing price datasets."""
import json
import re
import store


def valid(code, name):
    text = str(name or '').strip()
    return bool(text and text != str(code) and not re.fullmatch(r'[0-9A-Z]{6}', text))


def saved_names():
    names = {}
    def put(code, name):
        if re.fullmatch(r'[0-9A-Z]{6}', str(code)) and valid(code, name):
            names[str(code)] = str(name).strip()
    paths = [store.ROOT/'collection.json', store.ROOT/'universe.json']
    paths += sorted((store.ROOT/'eligibility'/'observations').glob('*.json'),
                    key=lambda p: (p.stat().st_mtime_ns, p.name))
    for path in paths:
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        for code, name in (data.get('names') or {}).items():
            put(code, name)
        for row in (data.get('selected') or []) + (data.get('rows') or []):
            if not isinstance(row, dict):
                continue
            raw = row.get('raw') or row
            put(raw.get('code'), raw.get('name'))
    return names


def hydrate(value):
    """Fill missing names in a fresh response; never rewrite saved results."""
    names = saved_names()
    def visit(item):
        if isinstance(item, dict):
            code = item.get('code')
            if code and 'name' in item and not valid(code, item['name']):
                item['name'] = names.get(str(code), '종목명 미확인')
            for child in item.values():
                visit(child)
        elif isinstance(item, list):
            for child in item:
                visit(child)
    visit(value)
    return value
