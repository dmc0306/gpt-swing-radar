"""Exclude destructive data operations while requests/background work are using data."""
from contextlib import contextmanager
import threading
from fastapi import HTTPException
LOCK=threading.Lock();ACTIVE=0;RESETTING=False

def available():
    with LOCK:
        if RESETTING:raise HTTPException(409,'데이터 정리 중입니다. 완료 후 다시 시도하세요.')

@contextmanager
def access(reset=False):
    global ACTIVE,RESETTING
    with LOCK:
        if RESETTING or (reset and ACTIVE):raise HTTPException(409,'다른 작업이 자료를 사용 중입니다. 잠시 후 다시 시도하세요.')
        ACTIVE+=1
        if reset:RESETTING=True
    try:yield
    finally:
        with LOCK:
            ACTIVE-=1
            if reset:RESETTING=False

HEAVY=threading.Lock()
@contextmanager
def compute():
    if not HEAVY.acquire(blocking=False):raise HTTPException(409,'수집·계산·후보 조회 중입니다. 완료 후 다시 시도하세요.')
    try:yield
    finally:HEAVY.release()
