"""Read-only historical comparisons plus the active fixed-five records."""
import json
from pathlib import Path
import store

def _path(ident):
    if not ident or len(ident)!=24 or any(c not in '0123456789abcdef' for c in ident):raise ValueError('비교 번호 오류')
    return store.ROOT/'comparisons'/(ident+'.json')

def get(ident):
    path=_path(ident)
    if path.exists():return json.loads(path.read_text())
    for name in ('comparison.json','exit-comparison.json','dynamic-comparison.json','selective-comparison.json','risk-partial-comparison.json','focus-comparison.json'):
        bundled=Path(__file__).parent/'reports'/name
        if bundled.exists():
            r=json.loads(bundled.read_text())
            if r['id']==ident:return r
    raise ValueError('조건 비교 기록이 없습니다.')

def catalog():
    values=[];paths=list((store.ROOT/'comparisons').glob('*.json'))
    for name in ('comparison.json','exit-comparison.json','dynamic-comparison.json','selective-comparison.json','risk-partial-comparison.json','focus-comparison.json'):
        bundled=Path(__file__).parent/'reports'/name
        if bundled.exists():paths.append(bundled)
    for p in paths:
        r=json.loads(p.read_text());values.append({**{k:r[k] for k in ('id','created','start','end','dataset_id','eligible_ids','label')},'suite':r.get('suite','entry')})
    return sorted({x['id']:x for x in values}.values(),key=lambda x:x['created'],reverse=True)[:30]
