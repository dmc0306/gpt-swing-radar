"""Local notification inbox. No messages sent to external services."""
import threading
import store
_LOCK=threading.RLock()

def init():
    with store.db() as c:c.execute('CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY,created TEXT,kind TEXT,title TEXT,body TEXT,seen INTEGER DEFAULT 0)')

def add(key,kind,title,body):
    with _LOCK:
        init()
        with store.db() as c:c.execute('INSERT OR IGNORE INTO alerts VALUES(?,?,?,?,?,0)',(store.digest(key),store.now(),kind,title,body))

def inbox():
    with _LOCK:
        init()
        with store.db() as c:
            total=c.execute('SELECT count(*) FROM alerts WHERE seen=0').fetchone()[0]
            rows=c.execute('SELECT id,created,kind,title,body,seen FROM alerts ORDER BY created DESC LIMIT 100').fetchall()
    return {'unread':total,'items':[dict(zip(('id','created','kind','title','body','seen'),r)) for r in rows]}

def read_all():
    with _LOCK:
        init()
        with store.db() as c:c.execute('UPDATE alerts SET seen=1')
    return inbox()

def paper_events(state):
    if not state:return
    b=state['book'];day=b['last_date'];ident=state['id'];prefix=(state.get('label','')+' · '+state.get('name','')).strip(' ·')
    if prefix:prefix+=' · '
    if b['pending']:add([ident,day,'pending'],'candidate',prefix+'다음 거래일 매수 후보',', '.join(x['name'] for x in b['pending'][:20])+' · 실제 체결은 갭·현금·위험 한도에 따라 달라집니다.')
    for p in b['positions']:
        if p['held']>=state['spec']['hold']-1:add([ident,day,p['code'],'due'],'exit',prefix+'보유기간 만료 임박',f"{p['name']} · {p['held']}/{state['spec']['hold']}거래일 · 다음 실제 거래일 청산 조건 확인")
    for t in b['trades']:
        add([ident,t['code'],t['entry_date'],t['exit_date']],'trade',prefix+'모의 청산 기록',f"{t['name']} · {t['exit_date']} · {t['exit_reason']} · 손익 {t['pnl']:,.0f}원")
    for p in b['trades']+b['positions']:
        for leg in p.get('exit_legs',[]):
            if leg['qty']<p.get('initial_qty',p['qty']):
                add([ident,p['code'],p['entry_date'],'fill',leg['number']],'trade',prefix+'모의 매도 체결',f"{p['name']} · {leg['date']} · {leg['qty']}주 · {leg['reason']} · 이 체결은 별도 승리로 세지 않습니다.")
        for change in p.get('stop_history',[]):
            add([ident,p['code'],p['entry_date'],'trail',change['observed_date']],'exit',prefix+'모의 추적선 갱신',f"{p['name']} · {change['observed_date']} 종가 확인 · {change['new_stop']:,.0f}원 · 다음 거래일부터 적용")
    for w in state.get('warnings',[]):add([ident,w],'data',prefix+'모의계좌 자료 확인',w)
