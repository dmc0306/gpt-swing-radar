from pathlib import Path
import json,html,hashlib,shutil,zipfile
B=Path(__file__).resolve().parent;A=B.parent/'v317-work';m=json.loads((A/'reports/pattern-model.json').read_text());r=json.loads((B/'report.json').read_text());snapshot=json.loads((B/'snapshot.json').read_text())
f=lambda x,n=2:'없음' if x is None else format(x,','+'.'+str(n)+'f')
def table(headers,rows):return '| '+' | '.join(headers)+' |\n|'+'|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n'
lines=['# 후보 선택용 데이터 패턴 순위 · v3.17.0','', '작성 2026-09-30. 사용자 제공 1,662종목 자료를 실제 계산했습니다. 후보 선택 버튼에 두 목표의 순위를 추가합니다. 오늘 현재가에서 매수한 성과를 검증한 결과는 아닙니다.','', '**선택 품질은 일부 개선됐지만 실전 채택 기준은 미달입니다.** 0.4R 순위의 이후 상위군 승률73.50%는 전체69.05%보다 높았지만 평균 순손익−0.0235%, 비용2배 고정 진단−0.3230%입니다. 80% 승률이나 작은 낙폭을 확보했다고 주장하지 않습니다. 급등 순위는 같은 이후 표본에서12.14%→18.97%였지만 다음날−5% 이하 비율도11.08%→21.04%로 커졌습니다.','', '## 후보 버튼에서 보는 것','', '- 기본: 이익으로 끝나는 비율 우선. 0.4R 전량익절·1.5ATR 손절·최대15거래일·최초위험폭8% 이내의 결과를 학습한 점수 순위입니다.', '- 전환: 다음 날 종가5% 급등 관찰. 급등 사건의 빈도를 학습한 별도 점수이며, 매매 승률과 합치지 않습니다.', '- 종목별 모델 순위 점수, 같은 점수구간의 보정기간 실제 승률/급등률, 이후 재분석 기간 같은 점수구간 성적, 각각의 관측 수를 표시합니다. 점수80은 승률80%가 아닙니다.', '- 확정 종가·지표·참고기간·제외 상태·가격 날짜·학습범위 이탈을 표시합니다. 승률 모형 범위 종목은 종가 기준 목표/손절/수량과 현재가 점검 버튼이 있습니다.', '- 가격 점검은 기존 키움 정보조회 API만 사용합니다. 실제주문을 보내지 않고 검증된 장중 매수 신호로 바꾸지 않습니다. 다음시가 진입을 기준으로 계산했습니다. 장중 타이밍 분석에는 분봉·호가자료가 별도로 필요합니다.', '- 초기 위험폭8% 초과 종목은 급등 관찰 순위에는 나타날 수 있지만 승률 모형 가격계획은 제공하지 않습니다. 매매 채택 기준이 미달인 순위는 연구용으로 표시합니다.', '- 최신 일봉 불일치·오늘 제외상태 미확인/제외 종목은 보류 목록으로 분리합니다. 보류 목록을 보는 체크가 있으며 기존5개 방법이 후보0이어도 별도 패턴 순위의 유무를 구분합니다.', '- 현재 가격·계좌 현금/보유·진입일 여부가 모두 검증된 종목 목록을 뜻하지 않습니다. 모델만으로 ‘지금 사도 된다’를 판정하지 않습니다.','', '## 시간 순서와 모델 선택','', '모든 입력은 신호일까지의 최대120개 일봉이고 목표 사건일 기준 최대달력6개월 안에 있어야 합니다. 코드의 미래 수익·청산 결과를 입력 지표에 넣지 않았습니다. 보정/선택에 사용하는 완료 거래가 다음 기간으로 넘어가지 않게 제외했습니다. 다음 시가 갭1ATR 이내와 위험폭8% 조건은 당시 실제 진입 가격을 확인한 거래에만 적용했습니다. 후보 점수는 진입 가격이 아직 없으므로 조건부 결과입니다.', '', table(['단계','기간','용도'],[['학습','2024-03-01~2025-08-31','계수/트리 학습'],['보정·모델 선택','2025-09-01~2026-03-31','상위10% 점수 문턱 고정·둘 중 모델 선택'],['이후 재분석','2026-04-01~2026-09-29','고정 모델·문턱 성적 비교']]),'이후 구간도 이미 확인했던 과거 가격을 재사용합니다. 독립 미사용 최종 검증이 아닙니다. 두 모델은 사전 고정한 표준화 로지스틱 회귀(C=1)와 깊이4·최소잎1000 의사결정나무입니다. 이후 성적으로 다시 모델/문턱을 고르지 않았습니다. 두 목표 모두 보정 구간에서 로지스틱 회귀가 선택되었습니다.','', '문턱은 보정기간 점수90백분위수입니다. 이후 데이터에서 상위10%를 매번 다시 뽑은 결과가 아닙니다. 시기 변화와 동점 때문에 해당 군의 비중은10%보다 크거나 작을 수 있습니다.','']
for target,title in [('win','0.4R 매매 결과'),('jump','다음 날5% 급등 결과')]:
 lines +=['## '+title,'',table(['구간','전체 관측','전체 승률/급등률','고정 상위군 관측','상위군 승률/급등률','상위군 평균 순손익/종가수익'],[[seg,f(p['all']['observations'],0),f(p['all']['win_rate_pct'])+'%',f(p['top']['observations'],0),f(p['top']['win_rate_pct'])+'%',f(p['top'].get('mean_net_pct',p['top'].get('mean_return_pct')))+'%'] for seg,p in m[target]['parts'].items()])]
 lines +=['보정기간에서 비교한 모델:',table(['모델','보정 상위군 관측','보정 상위군 승률/급등률'],[[model['kind'],f(model['parts']['cal']['top']['observations'],0),f(model['parts']['cal']['top']['win_rate_pct'])+'%'] for model in r['targets'][target]['models']]), '점수 구간별 실제 성적:', table(['모델 원점수 하한','상한(미만)','보정 관측','보정 성적','이후 관측','이후 성적'],[[f(b['lower'],4),f(b['upper'],4),f(b['cal']['observations'],0),f(b['cal']['win_rate_pct'])+'%',f(b['later']['observations'],0),f(b['later']['win_rate_pct'])+'%'] for b in m[target]['bands']])]
 lines +=['분기 편차:',table(['분기','전체 성적','고정 상위군 성적','상위군 평균 순손익/종가수익'],[[q['quarter'],f(q['all']['win_rate_pct'])+'%',f(q['top']['win_rate_pct'])+'%',f(q['top'].get('mean_net_pct',q['top'].get('mean_return_pct')))+'%'] for q in m[target]['quarters']])]
lines +=['', '급등 모형의 이후 분모는87,797관측으로, 이전 ATR8% 이상 군의46,118관측·17.4%와 다릅니다. 따라서18.97%를17.4%와 직접 비교한 개선 수치로 쓰지 않습니다. 같은 기간 같은 모형 표본의 기준12.14%와 비교했습니다. 모델별 분모와 매매 목표 역시 달라서 승률과 급등률을 섞어 정렬하거나 계좌 수익을 합산하지 않습니다.', '', '## 실제로 점수에 영향을 준 지표','', '각 지표의 표준화 계수는 다른 지표와 함께 본 모델 내부의 영향입니다. 예를 들어 승률 모형에서120일 평균과의 거리·이전20일 고가와의 거리는 양의 방향,60일 평균과의 거리는 음의 방향이었습니다. 급등 모형에서 변동폭과20일 평균/이전20일 고가와의 거리가 영향을 주었습니다. 지표가 서로 연관되어 있으므로 이를 인과적 매매 법칙으로 읽지 않습니다. 종목 카드에는 그 종목에서 점수에 가장 크게 영향을 준4개 지표와 방향을 표시합니다.', '', '## 실제 데이터 계산 범위','', '- 0.4R 라벨은 다음 시가+편도슬리피지0.05% 진입, 손절1.5ATR, 익절0.4R, 최대15일, 동일봉 양쪽 터치시 손절우선, 갭손절 시가, 왕복비용0.2%를 적용합니다. 구간 내부 완료된 거래만 승률에 포함합니다.', '- 각 신호의 결과는 서로 겹칠 수 있습니다. 관측 수는 독립 거래 표본 수나 실제10종목 계좌에서 가능한 거래 수가 아닙니다. 현금·수량·동시보유 제약을 적용한 계좌 백테스트는 수행하지 않았습니다. 계좌 수익률·MDD를 보고하지 않습니다.', '- 비용2배는 같은 진입/청산 거래의 비용 진단이며 비용 변경 후 재시뮬레이션이 아닙니다.', '- 모델의 실제 데이터 추론값과 내보낸 JSON 추론값을2,000개씩 대조했고 최대차이는3.33e-16입니다. 후보용 지표 추출도 실제 과거100행과 대조했고 최대차이는'+f(snapshot['feature_parity']['max_abs_error'],12)+'입니다. 이는 실제 데이터 계산의 일관성 확인입니다.', '- 앱 실행·브라우저·API 호출·설치·회귀/부하 테스트·자동서버배포는 사용자 요청에 따라 생략했습니다. 실제현재가를 이 환경에서 조회하거나 주문하지 않았습니다.', '', '## 현재 첨부 자료의 마지막 스냅샷','',f"가격 날짜 {snapshot['date']}, 가격·이력 공통 조건을 통과한 {snapshot['total']}종목을 계산했습니다. 이 중 종목별 순위는 research_pattern/snapshot.json에 저장했습니다. 오늘 실제 후보가 아니며 당시/현재 제외 상태와 현재가는 확인하지 못했습니다. 설치 후 최신 가격을 받고 후보 선택을 다시 눌러야 합니다.", '', '## 보존과 설치','', '기존5개 전략·모의계좌·저장가격·인증·포트8000을 보존합니다. 모델을 서버에서 다시 학습하지 않고 작은 JSON계수와 지표만 읽습니다. 종목 한 개씩 최대120봉을 계산하며 전체 가격자료를 새로 메모리에 펼치지 않습니다. 실제1GB 서버 최대 메모리는 측정하지 않았습니다.', '', '```bash','mkdir -p ~/swing-lab-v317-update','unzip -o ~/swing-lab-v3.zip -d ~/swing-lab-v317-update','cd ~/swing-lab-v317-update/swing-lab-v3','bash install.sh --update','```', '', '자료 준비 → 저장 가격 새로 받기 → 종목 찾기 → 후보 선택·승률과 급등 패턴 보기. 지표 캐시는 코드/모델/거래일 달력 버전 변경을 감지해 재계산합니다. 지난 조회기록에 새 점수를 소급해서 채우지 않습니다. 현재가격 점검도 이전 날짜 조회 또는 바뀐 모델을 감지하면 재조회를 요구합니다.', '', '## 한계와 참고','', '현재 선택1662종목의 생존/선택 편향 및 당시 제외상태/구성/가격조정 이력 부재가 남습니다. 급등·손절 갭, 전일 정보로 알 수 없는 뉴스, 미래 실제 체결/호가 차이도 반영하지 못합니다. 8% 선별은 실제손실이나 낙폭의 상한이 아닙니다. 승률 모형의 이후 상위군 최악 한 거래도−11.62%였습니다.', '공식 구현 참고(2026-09-30 확인): https://scikit-learn.org/1.8/modules/generated/sklearn.linear_model.LogisticRegression.html 및 https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html . 실제 학습 환경 scikit-learn1.8.0. 서버 런타임에 scikit-learn을 설치하지 않습니다.', '숫자의 출처는 사용자 제공 가격·실제 계산 기록입니다. research_pattern에 프로토콜, 실행 소스, 선택 보고서, 이후 전체 관측 CSV를 포함합니다. 원본 가격과 커다란 labels.sqlite는 중복/크기 때문에 제외했습니다. 실전 매수 규칙 채택을 보류하고 화면에서는 연구용 순위로 표시합니다.']
md='\n'.join(lines)+'\n';(A/'reports/pattern-report.md').write_text(md)
parts=[];inside=False
for line in lines:
 if line.startswith('|'):
  if not line.replace('|','').replace('-','').replace(':','').strip():continue
  tag='td' if inside else 'th'
  if not inside:parts.append('<div class="wrap"><table>');inside=True
  parts.append('<tr>'+''.join('<'+tag+'>'+html.escape(x.strip())+'</'+tag+'>' for x in line.strip('|').split('|'))+'</tr>');continue
 if inside:parts.append('</table></div>');inside=False
 if line.startswith('#'):
  n=len(line)-len(line.lstrip('#'));parts.append('<h'+str(n)+'>'+html.escape(line[n:].strip())+'</h'+str(n)+'>')
 elif line:parts.append('<p>'+html.escape(line)+'</p>')
if inside:parts.append('</table></div>')
(A/'reports/pattern-report.html').write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>후보 패턴 순위 분석</title><style>body{max-width:1100px;margin:auto;padding:20px;font:16px/1.7 system-ui;background:#f5f8f6;color:#203432}p{overflow-wrap:anywhere}table{border-collapse:collapse;background:white;width:100%}th,td{padding:10px;border:1px solid #d5e1db;text-align:left;min-width:100px}th{background:#dceee7}.wrap{overflow:auto}</style>'+''.join(parts)+'</html>')
D=A/'research_pattern';D.mkdir(exist_ok=True)
for fpath in B.iterdir():
 if fpath.suffix in ('.py','.json','.csv'):(D/fpath.name).write_bytes(fpath.read_bytes())
(D/'README.md').write_text('실제 계산 프로토콜·소스·관측 기록. 학습 소스는 기존 작업환경의 가격 SQLite를 참조하며 앱 서버에서 그대로 실행하는 설치파일이 아닙니다. 모델은 reports/pattern-model.json에 저장했습니다. 상세 성과와 범위는 reports/pattern-report.md를 읽으세요.\n')
intro='''# v3.17.0 · 데이터로 후보 순위 고르기

- 후보 선택 버튼에 **0.4R 승률 우선 / 다음 날5% 급등 관찰** 두 순위를 추가했습니다.
- 종목별 점수, 같은 점수구간의 과거 성적과 이후 성적, 관측 수, 점수에 영향을 준 지표, 날짜·제외 상태·누락·학습범위 이탈을 표시합니다.
- 승률 모형 범위 종목은 종가 기준 익절/손절/수량 계획과 기존 API의 현재가 점검을 제공합니다. 현재가를 확인했다고 장중 진입 승률을 검증한 것은 아닙니다.
- 실제 계산에서 이후0.4R 상위군 승률 **73.50% (1,872관측)**, 평균순손익 **−0.0235%**, 비용2배 고정 진단 **−0.3230%**입니다. 목표80%와 실전 채택 기준은 미달입니다. 화면에 연구용 순위로 명시하고 계좌·실제주문·자동알림에는 추가하지 않습니다.
- 급등 모형의 같은 이후 표본은 **12.14%→18.97%**이며 하락 위험도 커졌습니다. 이전17.4% 표본과 분모가 달라 직접 비교하지 않습니다.
- 학습·보정·이후 구간을 시간순으로 분리했고 소수의 고정 모델만 비교했습니다. 이후 자료는 이미 확인한 과거자료 재사용이며 독립 최종검증이 아닙니다.
- 기존 데이터·설정·계좌·5개 전략·포트8000을 유지합니다. 설치 후 가격 자료를 갱신하고 후보 선택을 다시 누르세요.
- 실제 데이터/모델 계산과 내보낸 수학값 대조를 완료했습니다. 앱/브라우저/API/설치/회귀/부하 테스트·서버 배포는 요청대로 생략했습니다.

상세 결과: reports/pattern-report.html 또는 pattern-report.md. 실행한 계산 소스·근거는 research_pattern/에 있습니다.

```bash
mkdir -p ~/swing-lab-v317-update
unzip -o ~/swing-lab-v3.zip -d ~/swing-lab-v317-update
cd ~/swing-lab-v317-update/swing-lab-v3
bash install.sh --update
```
'''
(A/'CHANGES-v3.17.0.md').write_text(intro)
for name in ['README.md','CHANGELOG.md','OVERNIGHT_PROGRESS.md']:
 p=A/name;p.write_text(intro+'\n---\n\n'+p.read_text())
p=A/'install.sh';s=p.read_text().replace('"$SOURCE_DIR/CHANGES-v3.16.2.md"','"$SOURCE_DIR/CHANGES-v3.16.2.md" "$SOURCE_DIR/CHANGES-v3.17.0.md"').replace('research_10 research_expansion','research_10 research_expansion research_pattern');p.write_text(s)
manifest=json.loads((A/'BUILD_MANIFEST.json').read_text());manifest.update(version='3.17.0',base_library_version=24,feature='候補순위'.replace('候補','후보')+'·승률/급등 별도모형·구간별실제성적·현재가격계획·자료보류',verification='실제 라벨/학습/시간순 성적·내보낸 추론값/지표 수학 대조 완료. 앱/브라우저/API/설치/회귀/부하 테스트·배포 생략.',strategy_changes='기존5개 전략 유지. 패턴 순위는 연구용이며 실전 채택 기준 미달. 계좌/알림 자동 적용 없음.')
# Preserve frozen paper engine source identity as part of packaging.
old=json.loads((B.parent/'v3162-work/BUILD_MANIFEST.json').read_text())
for name in ['engine.py','focus_indicators.py','strategies.py','paper.py','store.py','membership.py','comparison.py','session_calendar.py','eligibility.py','universe.py','workflows.py','data_source.py','price_store.py','quality.py']:
 if hashlib.sha256((A/name).read_bytes()).hexdigest()!=old['source_sha256'][name]:raise ValueError('기존계좌 해시 파일 변경: '+name)
manifest['source_sha256']={str(x.relative_to(A)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(A.rglob('*')) if x.is_file() and x.name!='BUILD_MANIFEST.json' and '__pycache__' not in str(x)}
(A/'BUILD_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
out=B.parent/'output/v3.17.0/swing-lab-v3.zip';out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for x in sorted(A.rglob('*')):
  if x.is_file() and '__pycache__' not in str(x):z.write(x,'swing-lab-v3/'+str(x.relative_to(A)))
print(out,out.stat().st_size)
