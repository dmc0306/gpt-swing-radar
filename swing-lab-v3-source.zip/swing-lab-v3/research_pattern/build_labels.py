import json,sqlite3,time
from pathlib import Path
B=Path(__file__).resolve().parent;P=json.loads((B/'protocol.json').read_text())
src=sqlite3.connect('file:'+str(B.parent/'analysis-1662/data/price_indexes'/(P['dataset_id']+'.sqlite'))+'?mode=ro',uri=True)
obs=sqlite3.connect('file:'+str(B.parent/'analysis-jump5/observations.sqlite')+'?mode=ro',uri=True)
out=sqlite3.connect(B/'labels.sqlite');out.execute('CREATE TABLE IF NOT EXISTS labels(code TEXT,name TEXT,signal TEXT,entry_day TEXT,exit_day TEXT,segment TEXT,net REAL,cost2 REAL,reason TEXT,features TEXT,PRIMARY KEY(code,signal))');out.execute('CREATE TABLE IF NOT EXISTS done(code TEXT PRIMARY KEY)')
done={r[0] for r in out.execute('select code from done')};days=[r[0] for r in src.execute('select distinct date from bars order by date')];di={d:i for i,d in enumerate(days)}
segments=[('train','2024-03-01','2025-08-31'),('cal','2025-09-01','2026-03-31'),('later','2026-04-01','2026-09-29')];tick=0
for k,(code,) in enumerate(obs.execute('select distinct code from obs').fetchall()):
 if code in done:continue
 rows=[json.loads(r[0]) for r in src.execute('select payload from bars where code=? order by date',(code,))];idx={r['date']:i for i,r in enumerate(rows)};records=[]
 for name,signal,entry_day,raw in obs.execute('select name,signal,event_day,features from obs where code=? order by signal',(code,)):
  f=json.loads(raw)
  if 1.5*f['atr_pct']>8:continue
  i=idx[signal];j=i+1;atr=f['atr_pct']*rows[i]['close']/100;risk=1.5*atr;entry=rows[j]['open']*1.0005
  if abs(rows[j]['open']-rows[i]['close'])>atr or risk/entry>.08:continue
  seg=next((x for x in segments if x[1]<=entry_day<=x[2]),None)
  if not seg:continue
  exit_i=None;stop=entry-risk;target=entry+.4*risk
  for z in range(j,min(j+15,len(rows))):
   r=rows[z]
   if r['date']>seg[2] or di[r['date']]-di[rows[j]['date']]!=z-j or r['volume']<=0 or r['low']<=0 or r['high']<max(r['open'],r['close']) or r['low']>min(r['open'],r['close']):break
   if r['open']<=stop:price=r['open'];reason='gap_stop';exit_i=z;break
   if r['low']<=stop:price=stop;reason='stop';exit_i=z;break
   if r['high']>=target:price=target;reason='target';exit_i=z;break
   if z==j+14:price=r['close'];reason='timeout';exit_i=z;break
  if exit_i is None:continue
  net=100*(price*.9995*.999/(entry*1.001)-1);stress=100*(price*.999*.998/(rows[j]['open']*1.001*1.002)-1)
  records.append((code,name,signal,entry_day,rows[exit_i]['date'],seg[0],net,stress,reason,raw))
 with out:out.executemany('insert or replace into labels values(?,?,?,?,?,?,?,?,?,?)',records);out.execute('insert or replace into done values(?)',(code,))
 if time.monotonic()-tick>25:print('동일0.4R 매매 결과 계산',k+1,flush=True);tick=time.monotonic()
print(out.execute('select segment,count(*),avg(net>0),avg(net) from labels group by segment').fetchall(),flush=True)
for c in [src,obs,out]:c.close()
