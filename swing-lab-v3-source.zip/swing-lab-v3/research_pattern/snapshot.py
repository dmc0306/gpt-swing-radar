import sqlite3,json,sys,math,time
from pathlib import Path
import pandas as pd
B=Path(__file__).resolve().parent;A=B.parent/'v317-work';sys.path.insert(0,str(A));import pattern_features,pattern_rank
P=json.loads((B/'protocol.json').read_text());src=sqlite3.connect('file:'+str(B.parent/'analysis-1662/data/price_indexes'/(P['dataset_id']+'.sqlite'))+'?mode=ro',uri=True)
obs=sqlite3.connect('file:'+str(B.parent/'analysis-jump5/observations.sqlite')+'?mode=ro',uri=True)
days=[x[0] for x in src.execute('select distinct date from bars order by date')];latest=days[-1];sample=obs.execute("select code,signal,event_day,features from obs order by event_day desc,code limit 100").fetchall();error=0;matched=0
for code,signal,event,raw in sample:
 rows=[json.loads(x[0]) for x in src.execute('select payload from bars where code=? and date<=? order by date',(code,signal))]
 row,reason=pattern_features.extract(rows,[x for x in days if x<=signal],event)
 if not row:raise ValueError(reason)
 f=json.loads(raw);error=max(error,max(abs(f[k]-row['features'][k]) for k in f));matched+=1
if error>1e-6:raise ValueError('학습/후보 지표 계산 차이')
entry=(pd.Timestamp(latest)+pd.offsets.BDay(1)).date().isoformat();all_rows=[];fails={};tick=0
for i,(code,) in enumerate(src.execute('select distinct code from bars').fetchall()):
 rows=[json.loads(x[0]) for x in src.execute('select payload from bars where code=? order by date',(code,))]
 if rows[-1]['date']!=latest:continue
 row,reason=pattern_features.extract(rows,days,entry)
 if not row:fails[reason]=fails.get(reason,0)+1;continue
 if row['close']<1000 or row['turnover']<1e9:continue
 models=pattern_rank.model();row['win']=pattern_rank.score_one(models['win'],row) if row['features']['atr_pct']*1.5<=8 else None;row['jump']=pattern_rank.score_one(models['jump'],row);all_rows.append(row)
 if time.monotonic()-tick>25:print('저장 자료의 마지막 날짜 순위',i+1,flush=True);tick=time.monotonic()
all_rows.sort(key=lambda r:-(r['win']['raw_model_value'] if r['win'] else -1))
(B/'snapshot.json').write_text(json.dumps({'date':latest,'expected_entry_estimate':entry,'note':'제공 자료의 마지막 날짜 스냅샷. 오늘 실제 매수 후보가 아니며 당시/현재 제외 상태와 현재가 미확인.','feature_parity':{'samples':matched,'max_abs_error':error},'failures':fails,'total':len(all_rows),'top20_win':all_rows[:20],'top20_jump':sorted(all_rows,key=lambda r:-r['jump']['raw_model_value'])[:20]},ensure_ascii=False,indent=2)+'\n')
print('DONE',len(all_rows),matched,error)
