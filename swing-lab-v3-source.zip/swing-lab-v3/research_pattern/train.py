import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
import json,sqlite3,sys,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
B=Path(__file__).resolve().parent;A=B.parent/'v317-work';sys.path.insert(0,str(A));import pattern_rank
P=json.loads((B/'protocol.json').read_text());features=P['features']
models={};report={'protocol':P,'targets':{}}
def metrics(d,mask,target):
 z=d.loc[mask];n=len(z);result={'observations':n,'stocks':z.code.nunique(),'days':z.entry_day.nunique(),'win_rate_pct':100*z.y.mean() if n else None}
 if target=='win':result.update(mean_net_pct=z.net.mean() if n else None,mean_cost2_pct=z.cost2.mean() if n else None,worst_trade_pct=z.net.min() if n else None)
 else:result.update(mean_return_pct=z.net.mean() if n else None,down5_pct=100*(z.net<=-5).mean() if n else None)
 return result
for target in ['win','jump']:
 if target=='win':
  c=sqlite3.connect('file:'+str(B/'labels.sqlite')+'?mode=ro',uri=True);d=pd.read_sql_query('select code,entry_day,segment,net,cost2,features from labels',c);c.close();d['y']=(d.net>0).astype(int)
 else:
  c=sqlite3.connect('file:'+str(B.parent/'analysis-jump5/observations.sqlite')+'?mode=ro',uri=True);d=pd.read_sql_query('select code,event_day as entry_day,jump as y,actual_ret as net,features from obs',c);c.close();d['segment']=np.where(d.entry_day<='2025-08-31','train',np.where(d.entry_day<='2026-03-31','cal','later'))
 X=np.array([[json.loads(raw)[f] for f in features] for raw in d.features]);d=d.drop(columns='features');tr=d.segment=='train';cal=d.segment=='cal';later=d.segment=='later';y=d.y.to_numpy();scaler=StandardScaler().fit(X[tr]);choices=[]
 ranges={f:[float(X[tr,i].min()),float(X[tr,i].max())] for i,f in enumerate(features)}
 for kind in ['logistic','tree']:
  if kind=='logistic':model=LogisticRegression(C=1,max_iter=300,random_state=20260930).fit(scaler.transform(X[tr]),y[tr]);pred=model.predict_proba(scaler.transform(X))[:,1];export={'kind':kind,'features':features,'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),'coef':model.coef_[0].tolist(),'intercept':float(model.intercept_[0])}
  else:
   model=DecisionTreeClassifier(max_depth=4,min_samples_leaf=1000,criterion='entropy',random_state=20260930).fit(X[tr],y[tr]);pred=model.predict_proba(X)[:,1];t=model.tree_;vals=t.value[:,0,:];vals=vals[:,1]/vals.sum(axis=1)
   export={'kind':kind,'features':features,'children_left':t.children_left.tolist(),'children_right':t.children_right.tolist(),'feature_index':t.feature.tolist(),'threshold':t.threshold.tolist(),'values':vals.tolist()}
  cut=float(np.quantile(pred[cal],.9));selection=metrics(d,cal&(pred>=cut),target)
  # Evaluate exported inference on actual price feature rows, not application tests.
  ids=np.linspace(0,len(X)-1,min(2000,len(X)),dtype=int);manual=np.array([pattern_rank.predict(export,dict(zip(features,X[i]))) for i in ids]);diff=float(np.max(np.abs(manual-pred[ids])))
  if diff>1e-6:raise ValueError('내보낸 모델과 실제 계산값 불일치')
  parts={seg:{'all':metrics(d,d.segment==seg,target),'top':metrics(d,(d.segment==seg)&(pred>=cut),target)} for seg in ['train','cal','later']}
  thresholds=sorted(set(float(x) for x in np.quantile(pred[cal],[.2,.4,.6,.8,.9])))
  bands=[];lower=None
  for upper in thresholds+[None]:
   mask=np.ones(len(d),dtype=bool)
   if lower is not None:mask&=pred>=lower
   if upper is not None:mask&=pred<upper
   if (cal&mask).sum():bands.append({'lower':lower,'upper':upper,'cal':metrics(d,cal&mask,target),'later':metrics(d,later&mask,target)})
   lower=upper
  if not bands or bands[-1]['upper'] is not None:raise ValueError('점수구간 오류')
  quarters=[]
  for q in sorted(pd.to_datetime(d.loc[later,'entry_day']).dt.to_period('Q').astype(str).unique()):
   qm=pd.to_datetime(d.entry_day).dt.to_period('Q').astype(str)==q;quarters.append({'quarter':q,'all':metrics(d,qm,target),'top':metrics(d,qm&(pred>=cut),target)})
  export.update(top_cut=cut,bands=bands,feature_range=ranges,score_quantiles=np.quantile(pred[cal],np.linspace(0,1,101)).tolist(),parts=parts,quarters=quarters,export_max_error=diff)
  choices.append((selection['win_rate_pct'] or 0,selection.get('mean_net_pct',0) or 0,kind,export,pred))
  print(target,kind,parts,flush=True)
 selected=max(choices,key=lambda x:(x[0],x[1]));chosen=selected[3];pred=selected[4];top=chosen['parts']['later']['top'];base=chosen['parts']['later']['all']
 gate=top['observations']>=200 and (top['win_rate_pct'] or 0)>(base['win_rate_pct'] or 0)
 if target=='win':gate=gate and (top['mean_net_pct'] or 0)>0 and (top['mean_cost2_pct'] or 0)>0
 chosen['gate_pass']=bool(gate);chosen['goal80']=target=='win' and (top['win_rate_pct'] or 0)>=80;models[target]=chosen
 report['targets'][target]={'chosen':selected[2],'models':[{k:v for k,v in item[3].items() if k in ['kind','parts','quarters','export_max_error','top_cut']} for item in choices],'bands':chosen['bands'],'gate_pass':gate,'goal80':chosen['goal80']}
 evidence=d.loc[later].copy();evidence['score_raw']=pred[later];evidence['fixed_top_group']=pred[later]>=chosen['top_cut'];evidence.to_csv(B/(target+'-evidence.csv'),index=False,encoding='utf-8-sig')
summary={target:{'kind':m['kind'],'later_base':m['parts']['later']['all'],'later_top':m['parts']['later']['top'],'gate_pass':m['gate_pass'],'goal80':m['goal80'],'quarters':m['quarters']} for target,m in models.items()}
artifact={'schema':1,'id':hashlib.sha256(json.dumps(P,sort_keys=True).encode()).hexdigest()[:16],**models,'summary':summary,'protocol':P}
(A/'reports/pattern-model.json').write_text(json.dumps(artifact,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,'item') else x)+'\n');(B/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,'item') else x)+'\n')
print('SELECTED',summary,flush=True)
