실제 계산 프로토콜·소스·관측 기록. 학습 소스는 기존 작업환경의 가격 SQLite를 참조하며 앱 서버에서 그대로 실행하는 설치파일이 아닙니다. 모델은 reports/pattern-model.json에 저장했습니다. 상세 성과와 범위는 reports/pattern-report.md를 읽으세요.
