"""All selected snapshot symbols, with per-symbol disk staging and daily portfolios.

Paper rules are unchanged. Never subsample symbols to meet a memory budget.
"""
import hashlib,json,secrets
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import comparison,engine,eligibility,membership,price_store,store,strategies

def calculation_hash():
    return hashlib.sha256(Path(__file__).read_bytes()+store.code_hash().encode()).hexdigest()

def summaries():
    out=[];version=calculation_hash()
    for path in (store.ROOT/'comparison_summaries').glob('*.json'):
        value=json.loads(path.read_text())
        if value.get('calculation_hash')==version:out.append(value)
    return sorted(out,key=lambda r:r['created'],reverse=True)[:100]

def compare(payload,progress=lambda **kw:None):
    ident=payload.get('dataset_id') or strategies.latest_dataset()
    cfg=engine.config({'max_positions':10,**(payload.get('config') or {})})
    now=datetime.now(ZoneInfo('Asia/Seoul'))
    progress(stage='전체 가격 색인 준비 · 처음에는 시간이 걸려요',done=0,total=1)
    data=price_store.Dataset(ident,before=now.date().isoformat(),inclusive=now.hour*60+now.minute>=940)
    codes=data.codes();all_days=data.days();usable=all_days[120:]
    if not usable:raise ValueError('지표 준비용 120거래일 이후 가격이 필요해요.')
    start=payload.get('start') or (usable[-252] if len(usable)>=252 else usable[0])
    end=payload.get('end') or usable[-1]
    dates=[d for d in usable if start<=d<=end]
    if len(dates)<63:raise ValueError('지표 준비120거래일 이후 평가구간63거래일 이상이 필요해요.')
    mid=payload.get('membership_id') or None;eid=payload.get('eligibility_id') or None
    spans=defaultdict(list)
    if mid:
        record=membership.load(mid)
        needed={r['code'] for r in record['rows'] if r['start']<=dates[-1] and r['end']>=dates[0]}
        missing=sorted(needed-set(codes))
        if missing:raise ValueError('과거 구성 종목 가격 누락: '+', '.join(missing))
        for r in record['rows']:spans[r['code']].append(r)
    def allowed(code,day):
        return not mid or any(r['known_at']<=day and r['start']<=day<=r['end'] for r in spans[code])
    version=calculation_hash()
    key=store.digest({'dataset':ident,'config':cfg,'membership':mid,'dates':dates,'calculation':version})
    folder=store.ROOT/'research_cache';folder.mkdir(parents=True,exist_ok=True)
    con=price_store.connect(folder/(key+'.sqlite'))
    try:
        con.executescript('''CREATE TABLE IF NOT EXISTS bars(day TEXT,code TEXT,payload TEXT,PRIMARY KEY(day,code)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS signals(day TEXT,kind TEXT,code TEXT,payload TEXT,PRIMARY KEY(day,kind,code)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS breadth(day TEXT,code TEXT,up INTEGER,PRIMARY KEY(day,code)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS completed(code TEXT PRIMARY KEY,short INTEGER);''')
        done={r[0] for r in con.execute('SELECT code FROM completed')}
        for i,code in enumerate(codes):
            progress(stage='전체 종목 지표 계산 · '+code,done=i,total=len(codes))
            if code in done:continue
            rows=data.symbol(code);p=engine.prepare(rows,cfg)
            with con:
                for day in dates:
                    b=p['bars'].get(day,{}).get(code)
                    if b:con.execute('INSERT INTO bars VALUES(?,?,?)',(day,code,store.encode(b).decode()))
                    if not allowed(code,day):continue
                    up=p['breadth'].get(day,{}).get(code)
                    if up is not None:con.execute('INSERT INTO breadth VALUES(?,?,?)',(day,code,int(up)))
                    for kind,mapping in p['signals'].items():
                        for sig in mapping.get(day,[]):con.execute('INSERT INTO signals VALUES(?,?,?,?)',(day,kind,code,store.encode(sig).decode()))
                con.execute('INSERT INTO completed VALUES(?,?)',(code,int(len(rows)<140)))
            del rows,p
        sample={day:(n,up) for day,n,up in con.execute('SELECT day,count(*),sum(up) FROM breadth GROUP BY day')}
        definitions=list(strategies.DEFS.values())
        stress_cfg={**cfg,'fee_pct':cfg['fee_pct']*2,'slippage_pct':cfg['slippage_pct']*2}
        books=[(s,c,engine.fresh(c)) for s in definitions for c in (cfg,stress_cfg)]
        recent_dates=dates[-63:]
        recent_books=[(s,c,engine.fresh(c)) for s in definitions for c in (cfg,stress_cfg)]
        exclusions={'allowed':0,'excluded':0,'unknown':0} if eid else None
        gate=eligibility.Gate(eid,days=dates) if eid else None
        missing_day_bars=0
        for i,day in enumerate(dates):
            progress(stage='전체 종목 · 5가지 방법 일별 비교',done=i,total=len(dates))
            bars={code:json.loads(raw) for code,raw in con.execute('SELECT code,payload FROM bars WHERE day=?',(day,))}
            missing_day_bars+=len(codes)-len(bars)
            signals={kind:{day:[]} for kind in engine.STRATEGIES}
            count,up=sample.get(day,(0,0))
            for kind,raw in con.execute('SELECT kind,payload FROM signals WHERE day=?',(day,)):
                sig=json.loads(raw);sig.update(breadth_count=count,breadth_pct=100*up/count if count else 0)
                signals[kind][day].append(sig)
            for mapping in signals.values():mapping[day].sort(key=lambda s:(-s['score'],s['code']))
            prepared={'dates':[day],'bars':{day:bars},'signals':signals}
            if gate:
                counts=gate.apply(prepared)
                for k in exclusions:exclusions[k]+=counts[k]
            for s,c,book in books:
                engine.advance(book,day,bars,engine.select_signals(prepared,day,s['spec']),s['spec'],c)
            if day>=recent_dates[0]:
                for s,c,book in recent_books:
                    engine.advance(book,day,bars,engine.select_signals(prepared,day,s['spec']),s['spec'],c)
        variants=[]
        for i,s in enumerate(definitions):
            book=books[i*2][2];stress=books[i*2+1][2]
            result={'metrics':engine.metrics(book),'curve':book['curve'],'trades':book['trades'],
                    'open':book['positions'],'pending':book['pending'],'events':book['events']}
            variants.append({'id':s['id'],'name':s['name'],'spec':s['spec'],'result':result,
                'stress':engine.metrics(stress),'fixed_cost':engine.fixed_cost_diagnostic(result,cfg,2),
                'recent':{'start':recent_dates[0],'end':recent_dates[-1],
                    'metrics':engine.metrics(recent_books[i*2][2]),'stress':engine.metrics(recent_books[i*2+1][2]),
                    'note':'마지막63거래일을 같은 원금·빈 계좌로 다시 계산. 앞 구간의 보유·대기 주문을 가져오지 않으며 새 독립 검증이 아닙니다.'},
                'eligible':False,'ineligible_reasons':['동일 과거 재분석 · 독립 검증 없음'],
                'reason':s['conditions']+' '+s['exit']})
        scope={'symbols':len(codes),'symbols_with_bars_in_period':con.execute('SELECT count(DISTINCT code) FROM bars').fetchone()[0],
               'short_histories':con.execute('SELECT sum(short) FROM completed').fetchone()[0],
               'absent_symbol_days':missing_day_bars,'selection_limit':None,
               'note':'선택 가격 자료의 전체 종목. 거래 건수는 조건 통과·실제 가상 체결·완료 여부로 결정됩니다. 상장 전/수집 누락 일봉도 빈 날짜 수에 포함됩니다.'}
        r={'id':secrets.token_hex(12),'schema':5,'suite':'curated','created':store.now(),
           'label':'선택 자료 전체 종목 · 5가지 방법 과거 재분석','dataset_id':ident,
           'code_hash':store.code_hash(),'calculation_hash':version,'config':cfg,
           'start':dates[0],'end':dates[-1],'requested_period':{'start':payload.get('start') or None,'end':payload.get('end') or None},'membership_id':mid,'eligibility_id':eid,
           'scope':scope,'eligible_ids':[],'variants':variants,'exclusion_counts':exclusions,
           'limitations':['현재 선택·수집된 종목 전체를 평가합니다. 전체 상장 주식과 같다는 뜻은 아닙니다.',
               '이미 본 과거 자료의 재분석이며 새 독립 검증이 아닙니다. 생존·선택 편향이 남습니다.',
               '신호일 종가 이후 다음 거래일 시가 진입. 장중 진입·순서를 분봉으로 검증한 결과가 아닙니다.',
               '필요한 보유·대기 종목의 일봉 누락 시 비교를 중단하며 결과를 확정하지 않습니다.',
               '비용2배 재시뮬레이션은 거래 수가 바뀔 수 있습니다. 같은 거래 비용 진단과 구분합니다.',
               '낙폭은 종가 평가 기준이며 손실 상한 보장이 아닙니다.',
               '선택 표본 확산도는 개별 종목 집계이며 실제 시장지수가 아닙니다.',
               '제외 이력 미적용: 과거 거래정지·관리종목 등의 완전한 제외를 확인할 수 없습니다.' if not eid else '사용자 제공 제외 이력 적용. 진위·완전성 인증은 아닙니다.']}
        store.write(comparison._path(r['id']),r)
        summary={k:v for k,v in r.items() if k!='variants'}
        summary['variants']=[{k:v for k,v in x.items() if k!='result'}|{'metrics':x['result']['metrics']} for x in variants]
        store.write(store.ROOT/'comparison_summaries'/(r['id']+'.json'),summary)
        return {'comparison_id':r['id']}
    finally:con.close()
