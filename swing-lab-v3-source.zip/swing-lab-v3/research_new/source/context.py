"""Shared data preparation for bounded, explicitly retrospective research."""
from pathlib import Path
from collections import defaultdict
import gzip, json, math, zipfile, hashlib
import numpy as np
import pandas as pd
import engine

ROOT=Path(__file__).resolve().parents[1]
DATASET='eb4890a8f523e69c7f4b6cda8769b07d7c7559ecd21d3bfacab217e91fb737e8'
RUN='ec7841382c1b4772e80e9d96'

def wilder(values,n=14):
    x=np.asarray(values,dtype=float);out=np.full(len(x),np.nan);seed=[];previous=None
    for i,value in enumerate(x):
        if not np.isfinite(value):continue
        if previous is None:
            seed.append(value)
            if len(seed)<n:continue
            previous=float(np.mean(seed))
        else:previous=((n-1)*previous+value)/n
        out[i]=previous
    return out

def indicators(df):
    c=df.close;prev=c.shift(1)
    tr=pd.concat([df.high-df.low,(df.high-prev).abs(),(df.low-prev).abs()],axis=1).max(axis=1)
    df['atr']=tr.rolling(14).mean()
    for n in (20,60,120):df[f'ma{n}']=c.rolling(n).mean()
    df['ma60_old5']=df.ma60.shift(5);df['ma60_old20']=df.ma60.shift(20)
    df['prev_close']=prev;df['prev_high']=df.high.shift(1)
    df['bb_lower']=df.ma20-2*c.rolling(20).std(ddof=0)
    df['prev_bb_lower']=df.bb_lower.shift(1)
    df['vmean']=df.volume.rolling(20).mean().shift(1)
    df['prev_vratio']=(df.volume/df.vmean).shift(1)
    df['volume_ratio']=df.volume/df.vmean
    df['turnover']=(c*df.volume).rolling(20).mean()
    df['close_location']=np.where(df.high>df.low,(c-df.low)/(df.high-df.low),0.)
    up=df.high.diff().to_numpy();down=(-df.low.diff()).to_numpy()
    plus=np.where((up>down)&(up>0),up,0.);minus=np.where((down>up)&(down>0),down,0.)
    a_tr=tr.to_numpy(copy=True);a_tr[0]=np.nan;plus[0]=np.nan;minus[0]=np.nan
    a=wilder(a_tr);p=wilder(plus);m=wilder(minus)
    pdi=np.divide(100*p,a,out=np.full(len(a),np.nan),where=a>0)
    mdi=np.divide(100*m,a,out=np.full(len(a),np.nan),where=a>0)
    den=pdi+mdi;dx=np.divide(100*np.abs(pdi-mdi),den,out=np.zeros(len(a)),where=den>0)
    dx[~np.isfinite(den)]=np.nan
    df['adx14']=wilder(dx)
    dif=c.diff().to_numpy();gain=wilder(np.maximum(dif,0),2);loss=wilder(np.maximum(-dif,0),2)
    df['rsi2']=np.divide(100*gain,gain+loss,out=np.full(len(gain),50.),where=gain+loss>0)
    df.loc[~np.isfinite(gain+loss),'rsi2']=np.nan
    df['prev_rsi2']=df.rsi2.shift(1)
    return df

def load(input_zip):
    with zipfile.ZipFile(input_zip) as z:
        run=json.loads(z.read(f'data/runs/{RUN}.json'))
        rows=json.loads(gzip.decompress(z.read(f'data/prices/{DATASET}.json.gz')))
    cfg=engine.config(run['config']);prepared=engine.prepare(rows,cfg)
    grouped=defaultdict(list)
    for r in rows:grouped[r['code']].append(r)
    features={};base_signals=defaultdict(list);all_signals=defaultdict(list)
    for code,rs in grouped.items():
        df=indicators(pd.DataFrame(sorted(rs,key=lambda r:r['date'])))
        for r in df.to_dict('records'):
            clean={k:None if isinstance(v,float) and not math.isfinite(v) else v for k,v in r.items()}
            features[(code,r['date'])]=clean
            if not all(math.isfinite(r[k]) for k in ('atr','ma120','vmean','turnover')):continue
            if r['atr']<=0 or r['vmean']<=0 or r['close']<cfg['min_price'] or r['turnover']<cfg['min_turnover'] or r['volume']<=0:continue
            broad=prepared['breadth'].get(r['date'],{})
            sig={'code':code,'name':r['name'],'date':r['date'],'close':r['close'],'atr':r['atr'],
                 'volume_limit':r['vmean']*cfg['max_participation_pct']/100,'score':r['turnover'],
                 'stock_trend':bool(r['close']>r['ma60'] and r['ma20']>r['ma60'] and r['ma60']>r['ma60_old5']),
                 'atr_pct':100*r['atr']/r['close'],'volume_ratio':r['volume_ratio'],
                 'close_location':r['close_location'],'breadth_count':len(broad),
                 'breadth_pct':100*sum(broad.values())/len(broad) if broad else 0.,'reason':'analysis'}
            all_signals[r['date']].append(sig)
            if r['close']>r['ma120'] and r['prev_close']<r['prev_bb_lower'] and r['close']>=r['bb_lower'] and math.isfinite(r['adx14']) and r['adx14']<25:
                base_signals[r['date']].append({**sig,'reason':'bb_adx'})
    for maps in (base_signals,all_signals):
        for signals in maps.values():signals.sort(key=lambda s:(-s['score'],s['code']))
    full=prepared['dates'][119:]
    recent=[d for d in full if run['split']['holdout_start']<=d<=run['split']['holdout_end']]
    return {'run':run,'rows':rows,'cfg':cfg,'prepared':prepared,'features':features,'base_signals':dict(base_signals),
            'all_signals':dict(all_signals),'full':full,'recent':recent}

def dump(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
