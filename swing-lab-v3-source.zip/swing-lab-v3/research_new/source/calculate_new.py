from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib,sys
import engine
from context import load,dump,sha,DATASET
from research_base import build_maps,simulate,annual_continuous
ROOT=Path(__file__).resolve().parents[1]
input_path=Path(sys.argv[1]);c=load(input_path);cfg=c['cfg'];maps=build_maps(c)
new=defaultdict(list)
for day,signals in c['all_signals'].items():
 for s in signals:
  f=c['features'][(s['code'],day)]
  if f['prev_rsi2'] is not None and f['ma60_old5'] is not None and f['close']>f['ma60']>f['ma120'] and f['ma60']>f['ma60_old5'] and f['prev_rsi2']<=10 and f['rsi2']>10 and f['close']>f['open']:
   new[day].append({**s,'reason':'추세 지속 RSI2 회복'})
smaps={'focused_040':maps['bb_low60_flush'],'trend_rsi_040':dict(new)}
spec={'strategy':'recovery','filter':'risk_cap','hold':15,'reward':.4,'exit_policy':'timeout'}
codes=sorted({r['code'] for r in c['rows']});groups={str(i):{x for x in codes if int(hashlib.sha256(x.encode()).hexdigest(),16)%2==i} for i in (0,1)}
report={'dataset_id':DATASET,'input_sha256':sha(input_path),'protocol_sha256':sha(ROOT/'PROTOCOL.md'),'engine_sha256':sha(Path(engine.__file__)),'config':cfg,'spec':spec,'symbols':len(codes),'data_start':c['prepared']['dates'][0],'full_start':c['full'][0],'recent_start':c['recent'][0],'end':c['full'][-1],'variants':[]}
for key,smap in smaps.items():
 v={'id':key,'full':simulate(c,smap,c['full'],spec,cfg),'recent':simulate(c,smap,c['recent'],spec,cfg),'thirds':[],'symbols':{}}
 for i in range(3):
  ds=c['recent'][len(c['recent'])*i//3:len(c['recent'])*(i+1)//3];r=simulate(c,smap,ds,spec,cfg)
  v['thirds'].append({'start':ds[0],'end':ds[-1],'metrics':r['metrics']})
 stress={**cfg,'fee_pct':2*cfg['fee_pct'],'slippage_pct':2*cfg['slippage_pct']}
 v['stress2']={p:simulate(c,smap,c[p],spec,stress)['metrics'] for p in ('full','recent')}
 v['fixed_cost']=engine.fixed_cost_diagnostic(v['full'],cfg)
 v['years']=annual_continuous(v['full'],cfg['capital'])
 for g,group in groups.items():
  v['symbols'][g]={'codes':sorted(group),'metrics':simulate(c,{d:[s for s in ss if s['code'] in group] for d,ss in smap.items()},c['full'],spec,cfg)['metrics']}
 v['capital100m']={p:simulate(c,smap,c[p],spec,{**cfg,'capital':100000000.})['metrics'] for p in ('full','recent')}
 ts=v['full']['trades'];v['unique_stocks']=len({t['code'] for t in ts});v['exit_reasons']=dict(Counter(t['exit_reason'] for t in ts));v['worst']=min(ts,key=lambda t:t['return_pct']) if ts else None
 by=defaultdict(lambda:{'trades':0,'pnl':0.,'wins':0})
 for t in ts:
  b=by[t['code']];b.update(name=t['name']);b['trades']+=1;b['pnl']+=t['pnl'];b['wins']+=t['pnl']>0
 v['stock_results']=dict(by);fails=[]
 for p in ('full','recent'):
  m=v[p]['metrics']
  if m['trades']<(100 if p=='full' else 30):fails.append(p+' 표본 부족')
  if (m['win_rate'] or 0)<80:fails.append(p+' 승률80% 미달')
  if m['total_return_pct']<=0 or (m['avg_trade_pct'] or 0)<=0:fails.append(p+' 순손익 미달')
  if m['max_drawdown_pct']<-5:fails.append(p+' 낙폭5% 초과')
  if v['stress2'][p]['total_return_pct']<=0:fails.append(p+' 비용2배 손실')
 v['goal_pass']=not fails;v['fail_reasons']=fails;report['variants'].append(v)
 dump(ROOT/'results'/'comparison.json',report)
 print(json.dumps({'id':key,'full':v['full']['metrics'],'recent':v['recent']['metrics'],'stress2':{p:v['stress2'][p]['total_return_pct'] for p in ('full','recent')},'unique_stocks':v['unique_stocks'],'fails':fails},ensure_ascii=False),flush=True)
a,b=report['variants'];ca=set(a['stock_results']);cb=set(b['stock_results']);sa={(d,s['code']) for d,ss in smaps['focused_040'].items() for s in ss};sb={(d,s['code']) for d,ss in new.items() for s in ss}
report['overlap']={'signal_same_day':len(sa&sb),'stock_common':sorted(ca&cb),'new_strategy_only_stocks':sorted(cb-ca),'old_only_stocks':sorted(ca-cb)}
dump(ROOT/'results'/'comparison.json',report)
print('DONE',json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report['overlap'].items()}),flush=True)
