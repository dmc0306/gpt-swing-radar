"""Shared deterministic end-of-day signal and portfolio engine."""
import copy, math
from collections import defaultdict
import pandas as pd

FILTERS={'baseline':'기준 조건','stock_trend':'개별 종목 추세 강화','confirmation':'회복 강도 확인','risk_cap':'손절 위험 폭 8% 이하','sample_breadth':'선택 표본 확산도 50% 이상','reference_trend':'지정 참조 가격 추세','confirmation_breadth':'회복 확인 + 표본 확산','confirmation_risk':'회복 확인 + 위험 폭 제한'}
EXIT_POLICIES={'timeout':'고정 보유 만기','stall5':'5일 정체 확인 후 다음 시가 청산','trail':'전량 추적 청산','partial_trail':'절반 익절 후 추적 청산'}
DYNAMIC_EXITS={'trail','partial_trail'}

STRATEGIES={'pullback':'추세 눌림','breakout':'거래량 돌파','recovery':'단기 과매도 회복'}
DEFAULT={'capital':10000000.,'fee_pct':.20,'slippage_pct':.05,'max_positions':4,'position_pct':20.,'risk_pct':.5,
         'min_turnover':1000000000.,'min_price':1000.,'max_participation_pct':.1,'max_gap_atr':1.,'max_drawdown':10.}

def config(raw):
    out={**DEFAULT,**{k:v for k,v in raw.items() if k in DEFAULT}}
    bounds={'capital':(100000,1e11),'fee_pct':(0,3),'slippage_pct':(0,1),'max_positions':(1,20),'position_pct':(1,100),
            'risk_pct':(.05,5),'min_turnover':(0,1e13),'min_price':(0,1e6),'max_participation_pct':(.001,5),'max_gap_atr':(0,5),'max_drawdown':(1,100)}
    for k,(lo,hi) in bounds.items():
        out[k]=float(out[k])
        if not math.isfinite(out[k]) or not lo<=out[k]<=hi:raise ValueError(f'{k}: {lo}~{hi} 범위 필요')
    out['max_positions']=int(out['max_positions']);return out

def prepare(rows,cfg):
    grouped=defaultdict(list);bars=defaultdict(dict);breadth=defaultdict(dict);signals={k:defaultdict(list) for k in STRATEGIES}
    for r in rows:grouped[r['code']].append(r);bars[r['date']][r['code']]=dict(r)
    for code,rs in grouped.items():
        df=pd.DataFrame(sorted(rs,key=lambda r:r['date']));close=df.close;prev=close.shift(1)
        tr=pd.concat([df.high-df.low,(df.high-prev).abs(),(df.low-prev).abs()],axis=1).max(axis=1)
        df['atr']=tr.rolling(14).mean();df['ma20']=close.rolling(20).mean();df['ma60']=close.rolling(60).mean();df['ma120']=close.rolling(120).mean()
        df['ma60_prior']=df['ma60'].shift(5)
        df['vmean']=df.volume.rolling(20).mean().shift(1);df['turnover']=(close*df.volume).rolling(20).mean()
        df['resistance']=df.high.rolling(20).max().shift(1);df['prevhigh']=df.high.shift(1);df['change3']=close/close.shift(3)-1
        for r in df.to_dict('records'):
            bars[r['date']][code]['atr14']=float(r['atr']) if math.isfinite(r['atr']) else None
            if math.isfinite(r['ma60']):breadth[r['date']][code]=r['close']>r['ma60']
            if not all(math.isfinite(r[k]) for k in ('atr','ma120','vmean','turnover')) or r['atr']<=0 or r['vmean']<=0:continue
            if r['close']<cfg['min_price'] or r['turnover']<cfg['min_turnover'] or r['volume']<=0:continue
            tests={
             'pullback':r['ma20']>r['ma60'] and r['close']>r['ma60'] and abs(r['close']-r['ma20'])<=r['atr'] and r['close']>r['open'] and r['volume']<r['vmean'],
             'breakout':r['close']>r['resistance'] and r['volume']>=1.5*r['vmean'] and r['close']>r['ma60'],
             'recovery':r['close']>r['ma120'] and r['change3']<-.025 and r['close']>r['open'] and r['close']>r['prevhigh']}
            for strategy,passed in tests.items():
                if passed:signals[strategy][r['date']].append({'code':code,'name':r['name'],'date':r['date'],'close':r['close'],'atr':r['atr'],'volume_limit':r['vmean']*cfg['max_participation_pct']/100,'score':r['turnover'],'reason':STRATEGIES[strategy],
                    'stock_trend':bool(r['close']>r['ma60'] and r['ma20']>r['ma60'] and r['ma60']>r['ma60_prior']),
                    'atr_pct':100*r['atr']/r['close'],'volume_ratio':r['volume']/r['vmean'],
                    'close_location':(r['close']-r['low'])/(r['high']-r['low']) if r['high']>r['low'] else 0})
    for smap in signals.values():
        for day in smap:
            smap[day].sort(key=lambda r:(-r['score'],r['code']))
            for sig in smap[day]:
                sample=breadth.get(day,[])
                sig.update(breadth_count=len(sample),breadth_pct=100*sum(sample.values())/len(sample) if sample else 0)
    return {'bars':dict(bars),'signals':{k:dict(v) for k,v in signals.items()},'dates':sorted(bars),'breadth':dict(breadth)}

def validate_spec(spec):
    if spec.get('strategy') not in STRATEGIES or spec.get('filter','baseline') not in FILTERS:raise ValueError('알 수 없는 전략/필터')
    if not 1<=float(spec['hold'])<=15 or float(spec['hold'])!=int(spec['hold']) or not 0<float(spec['reward'])<=5:raise ValueError('보유/익절 조건 오류')
    if spec.get('exit_policy','timeout') not in EXIT_POLICIES:raise ValueError('알 수 없는 청산 규칙')
    if spec.get('exit_policy')=='stall5' and spec['hold']<=5:raise ValueError('5일 정체 청산은 최대 보유일이 5일보다 길어야 합니다.')
    return spec


def select_signals(prepared,day,spec):
    validate_spec(spec);kind=spec.get('filter','baseline');out=[]
    for sig in prepared['signals'][spec['strategy']].get(day,[]):
        if kind=='stock_trend' and not sig.get('stock_trend'):continue
        if kind in ('confirmation','confirmation_breadth','confirmation_risk') and not (sig.get('volume_ratio',0)>=1 and sig.get('close_location',0)>=.65):continue
        if kind in ('risk_cap','confirmation_risk') and sig['atr']/sig['close']*150>8:continue
        if kind in ('sample_breadth','confirmation_breadth') and not (sig.get('breadth_count',0)>=50 and sig.get('breadth_pct',0)>=50):continue
        if kind=='reference_trend':
            ref=prepared.get('reference_trend',{}).get(day)
            if not ref:continue
        if 'eligibility' in prepared and not prepared['eligibility'].get(day,{}).get(sig['code'],{}).get('allowed',False):continue
        item=copy.deepcopy(sig)
        if kind!='baseline':item['reason']+=' · '+FILTERS[kind]
        out.append(item)
    return out


def attach_reference(prepared,rows,code):
    rs=sorted((r for r in rows if r['code']==code),key=lambda r:r['date'])
    if len(rs)<65:raise ValueError('참조 가격에 최소 65개 일봉이 필요합니다.')
    close=pd.Series([r['close'] for r in rs]);ma=close.rolling(60).mean();old=ma.shift(5)
    prepared['reference_trend']={r['date']:bool(close.iloc[i]>ma.iloc[i] and ma.iloc[i]>old.iloc[i]) for i,r in enumerate(rs)}


def fresh(cfg):return {'initial':cfg['capital'],'cash':cfg['capital'],'positions':[],'pending':[],'trades':[],'events':[],'curve':[],'last_date':None}
def event(book,day,code,reason):book['events'].append({'date':day,'code':code,'reason':reason})
def equity(book):return book['cash']+sum(p['qty']*p['mark'] for p in book['positions'])

def sale_legs(pos):
    if 'exit_legs' in pos:return pos['exit_legs']
    if 'exit_date' not in pos:return []
    return [{'date':pos['exit_date'],'qty':pos['qty'],'raw_price':pos.get('exit_raw',pos['exit_price']),
             'fill_price':pos['exit_price'],'fee':pos.get('exit_fee',0),'pnl':pos['pnl'],'reason':pos['exit_reason']}]

def sell(book,pos,price,day,why,cfg,qty=None):
    """Credit every fill; count one completed trade only after the final share."""
    amount=pos['qty'] if qty is None else int(qty)
    if not 0<amount<=pos['qty']:raise ValueError('매도 수량 오류')
    pos.setdefault('initial_qty',pos['qty']);pos.setdefault('initial_invested',pos['invested'])
    pos.setdefault('initial_entry_fee',pos['entry_fee']);pos.setdefault('initial_stop',pos['stop'])
    legs=pos.setdefault('exit_legs',[])
    fill=price*(1-cfg['slippage_pct']/100);gross=fill*amount;fee=gross*cfg['fee_pct']/200
    basis=pos['invested'] if amount==pos['qty'] else pos['initial_invested']*amount/pos['initial_qty']
    leg={'number':len(legs)+1,'date':day,'qty':amount,'raw_price':price,'fill_price':fill,'fee':fee,
         'allocated_cost':basis,'net_proceeds':gross-fee,'pnl':gross-fee-basis,'reason':why}
    book['cash']+=gross-fee;legs.append(leg)
    pos['qty']-=amount;pos['invested']-=basis
    pos['entry_fee']=pos['initial_entry_fee']*pos['qty']/pos['initial_qty']
    if pos['qty']:return False
    pnl=sum(x['pnl'] for x in legs);original_qty=pos['initial_qty'];original_cost=pos['initial_invested']
    book['trades'].append({**copy.deepcopy(pos),'qty':original_qty,'invested':original_cost,'entry_fee':pos['initial_entry_fee'],
        'exit_date':day,'exit_price':sum(x['fill_price']*x['qty'] for x in legs)/original_qty,
        'exit_raw':sum(x['raw_price']*x['qty'] for x in legs)/original_qty,'exit_reason':why,
        'pnl':pnl,'return_pct':pnl/original_cost*100,'exit_fee':sum(x['fee'] for x in legs)})
    return True

def target_action(book,pos,price,day,cfg,gap=False):
    policy=pos.get('exit_policy','timeout')
    if policy not in DYNAMIC_EXITS:return sell(book,pos,price,day,'갭 익절' if gap else '익절',cfg)
    if pos.get('target_seen'):return False
    pos['target_seen']=True;pos['trail_active']=True
    pos['trail_activation']={'observed_date':day,'threshold':pos['target'],'touch_price':price,'phase':'open' if gap else 'intraday'}
    event(book,day,pos['code'],'0.75R 도달: 종가 계산 후 다음 거래일부터 추적선 적용')
    if policy=='partial_trail':
        half=pos['initial_qty']//2
        if half:
            sell(book,pos,price,day,'절반 익절 · 시가' if gap else '절반 익절',cfg,half)
            pos['partial_sold_qty']=half
        else:
            pos['partial_unavailable']=True
            event(book,day,pos['code'],'최초 1주: 부분 익절 없이 전량 추적 전환')
    return False

def update_trail(pos,bar,day):
    if pos.get('exit_policy') not in DYNAMIC_EXITS:return
    pos['highest_close']=max(pos.get('highest_close') or bar['close'],bar['close'])
    if not pos.get('trail_active'):return
    stop=max(pos['stop'],pos['highest_close']-2*bar['atr14'])
    if stop>pos['stop']:
        pos.setdefault('stop_history',[]).append({'observed_date':day,'effective':'next_session','previous_stop':pos['stop'],
            'new_stop':stop,'highest_close':pos['highest_close'],'atr14':bar['atr14']})
        pos['stop']=stop

def stop_reason(pos,gap=False):
    if pos.get('trail_active') and pos['stop']>pos.get('initial_stop',pos['stop']):return '추적 갭 청산' if gap else '추적 청산'
    return '갭 손절' if gap else '손절(동시 도달 포함)'

def schedule_exit(book,pos,bar,day,spec):
    if spec.get('exit_policy')=='stall5' and pos['held']==5 and bar['close']<=pos['entry_price'] and not pos.get('exit_next_open'):
        pos['exit_next_open']={'observed_date':day,'observed_close':bar['close'],'entry_price':pos['entry_price']}
        event(book,day,pos['code'],'5일 종가 회복 없음: 다음 체결 가능 시가 청산 예약')

def advance(book,day,bars,signals,spec,cfg):
    validate_spec(spec)
    if book['last_date'] and day<=book['last_date']:return
    required={p['code'] for p in book['positions']+book['pending']}
    missing=sorted(required-set(bars))
    if missing:raise ValueError(day+' 필요한 일봉 누락: '+', '.join(missing))
    if spec.get('exit_policy') in DYNAMIC_EXITS:
        invalid=[c for c in required if not isinstance(bars[c].get('atr14'),(int,float)) or not math.isfinite(bars[c]['atr14']) or bars[c]['atr14']<0]
        if invalid:raise ValueError(day+' 추적 청산용 ATR14 이력 누락: '+', '.join(sorted(invalid)))
    keep=[]
    for p in book['positions']:
        p['held']+=1;b=bars.get(p['code'])
        if b and b['volume']>0 and b['high']!=b['low']:
            if b['open']<=p['stop']:sell(book,p,b['open'],day,stop_reason(p,True),cfg);continue
            if b['open']>=p['target'] and target_action(book,p,b['open'],day,cfg,True):continue
            if p.get('exit_next_open'):
                sell(book,p,b['open'],day,'5일 정체 · 다음 시가',cfg);continue
        keep.append(p)
    book['positions']=keep
    for sig in book['pending']:
        b=bars.get(sig['code']);why=None
        if not b or b['volume']<=0 or b['high']==b['low']:why='자료 없음·거래 없음·단일가격 봉: 매수 미체결'
        elif 'buy_eligibility' in b and not b['buy_eligibility']['allowed']:why=b['buy_eligibility']['reason']+' · 신규 매수 미체결'
        elif any(p['code']==sig['code'] for p in book['positions']):why='이미 보유'
        elif len(book['positions'])>=cfg['max_positions']:why='보유 한도'
        elif abs(b['open']-sig['close'])>cfg['max_gap_atr']*sig['atr']:why='허용 갭 초과'
        if why:event(book,day,sig['code'],why);continue
        fill=b['open']*(1+cfg['slippage_pct']/100);risk=1.5*sig['atr'];net=equity(book)
        if spec.get('filter') in ('risk_cap','confirmation_risk') and risk/fill*100>8:
            event(book,day,sig['code'],'진입 시 손절 위험 폭 8% 초과');continue
        if fill<=risk:event(book,day,sig['code'],'손절 가격이 0 이하');continue
        limits={'cash':book['cash']/(fill*(1+cfg['fee_pct']/200)),'position':net*cfg['position_pct']/100/fill,'risk':net*cfg['risk_pct']/100/risk,'volume':sig['volume_limit']}
        qty=int(min(limits.values()))
        if qty<=0:event(book,day,sig['code'],'현금·위험·거래량 한도');continue
        fee=fill*qty*cfg['fee_pct']/200;spent=fill*qty+fee;book['cash']-=spent
        book['positions'].append({'code':sig['code'],'name':sig['name'],'signal_date':sig['date'],'entry_date':day,'entry_price':fill,'entry_raw':b['open'],'qty':qty,'entry_fee':fee,'invested':spent,'stop':fill-risk,'target':fill+risk*spec['reward'],'mark':fill,'held':1,'max_hold':spec['hold'],'exit_policy':spec.get('exit_policy','timeout'),'sizing_limit':min(limits,key=limits.get),'initial_risk_pct':risk/fill*100,'reason':sig['reason'],'signal_features':{k:sig[k] for k in ('stock_trend','atr_pct','volume_ratio','close_location','breadth_count','breadth_pct') if k in sig}})
        book['positions'][-1].update(initial_qty=qty,initial_invested=spent,initial_entry_fee=fee,initial_stop=fill-risk,exit_legs=[],stop_history=[])
    book['pending']=[];keep=[]
    for p in book['positions']:
        b=bars.get(p['code'])
        if not b or b['volume']<=0 or b['high']==b['low']:
            if b:
                p['mark']=b['close'];schedule_exit(book,p,b,day,spec);update_trail(p,b,day)
            event(book,day,p['code'],'매도 불가: 거래 없음·단일가격 봉 (종가 평가는 반영)');keep.append(p);continue
        p['mark']=b['close']
        if b['low']<=p['stop']:
            target_is_sale=p.get('exit_policy') not in DYNAMIC_EXITS or (p.get('exit_policy')=='partial_trail' and not p.get('target_seen') and p['initial_qty']>=2)
            p['both_barriers_hit']=bool(target_is_sale and b['high']>=p['target'])
            sell(book,p,p['stop'],day,stop_reason(p),cfg);continue
        if b['high']>=p['target'] and target_action(book,p,p['target'],day,cfg):continue
        if p['held']>=spec['hold']:sell(book,p,b['close'],day,'보유기간 만료',cfg)
        else:
            schedule_exit(book,p,b,day,spec);update_trail(p,b,day)
            keep.append(p)
    book['positions']=keep
    book['pending']=copy.deepcopy(signals)
    book['last_date']=day
    book['curve'].append({'date':day,'equity':equity(book),'cash':book['cash']})

def metrics(book):
    trades=book['trades'];n=len(trades);wins=sum(t['pnl']>0 for t in trades);losses=[t for t in trades if t['pnl']<0];profits=[t for t in trades if t['pnl']>0]
    peak=book['initial'];dd=0;streak=worst=0
    for point in book['curve']:peak=max(peak,point['equity']);dd=min(dd,(point['equity']/peak-1)*100)
    for t in trades:streak=streak+1 if t['pnl']<0 else 0;worst=max(worst,streak)
    gains=sum(t['pnl'] for t in profits);loss=-sum(t['pnl'] for t in losses)
    z=1.959963984540054;p=wins/n if n else 0;den=1+z*z/n if n else 1
    centre=(p+z*z/(2*n))/den if n else 0;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den if n else 0
    months={}
    for pt in book['curve']:months[pt['date'][:7]]=pt['equity']
    monthly=[];prior=book['initial']
    for month,value in months.items():monthly.append({'month':month,'return_pct':(value/prior-1)*100});prior=value
    points=book['curve'];exposure=[max(0,(p['equity']-p['cash'])/p['equity']*100) for p in points if p['equity']>0]
    all_entries=trades+book['positions'];limits=defaultdict(int)
    for t in all_entries:limits[t.get('sizing_limit','unknown')]+=1
    legs=[leg for t in all_entries for leg in sale_legs(t)]
    fees=sum(t.get('initial_entry_fee',t.get('entry_fee',0)) for t in all_entries)+sum(x['fee'] for x in legs)
    turnover=sum(t['entry_price']*t.get('initial_qty',t['qty']) for t in all_entries)+sum(x['fill_price']*x['qty'] for x in legs)
    partial_open=sum(x['pnl'] for p in book['positions'] for x in sale_legs(p))
    return {'trades':n,'wins':wins,'win_rate':100*p if n else None,'ci95':[max(0,centre-half)*100,min(1,centre+half)*100] if n else [None,None],
      'equity':equity(book),'total_return_pct':(equity(book)/book['initial']-1)*100,'max_drawdown_pct':dd,
      'avg_trade_pct':sum(t['return_pct'] for t in trades)/n if n else None,'profit_factor':gains/loss if loss else None,
      'avg_win_pct':sum(t['return_pct'] for t in profits)/len(profits) if profits else None,'avg_loss_pct':sum(t['return_pct'] for t in losses)/len(losses) if losses else None,
      'max_consecutive_losses':worst,'avg_hold':sum(t['held'] for t in trades)/n if n else None,'unrealized':sum(p['mark']*p['qty']-p['invested'] for p in book['positions']),
      'overdue':sum(p['held']>=p['max_hold'] for p in book['positions']),'monthly':monthly,
      'avg_eod_exposure_pct':sum(exposure)/len(exposure) if exposure else 0,'invested_days':sum(x>1e-8 for x in exposure),'observed_days':len(points),
      'realized_pnl':gains-loss+partial_open,'closed_pnl':gains-loss,'partial_realized_open':partial_open,'avg_trade_pnl':(gains-loss)/n if n else None,'open_positions':len(book['positions']),
      'turnover_multiple':turnover/book['initial'],'paid_fees':fees,'sizing_limits':dict(limits),
      'scheduled_exits':sum(bool(p.get('exit_next_open')) for p in book['positions']),
      'sell_fills':len(legs),'partial_positions':sum(t.get('partial_sold_qty',0)>0 for t in all_entries),
      'partial_unavailable':sum(bool(t.get('partial_unavailable')) for t in all_entries),'trailing_positions':sum(bool(t.get('trail_active')) for t in all_entries),
      'without_top5_pnl':sum(t['pnl'] for t in sorted(trades,key=lambda x:x['pnl'])[:-5]) if n>5 else None}

def simulate(prepared,dates,spec,cfg):
    book=fresh(cfg)
    for day in dates:advance(book,day,prepared['bars'].get(day,{}),select_signals(prepared,day,spec),spec,cfg)
    return {'metrics':metrics(book),'curve':book['curve'],'trades':book['trades'],'open':book['positions'],'pending':book['pending'],'events':book['events']}


def fixed_cost_diagnostic(result,cfg,multiplier=2):
    """Same executed trades, quantities and raw fills; no portfolio reallocation."""
    values=[]
    for t in result['trades']:
        raw_buy=t.get('entry_raw',t['entry_price']/(1+cfg['slippage_pct']/100))
        buy=raw_buy*(1+cfg['slippage_pct']*multiplier/100)*t['qty']
        # A completed position may contain several sells on different days.
        raw_legs=t.get('exit_legs') or [{'raw_price':t.get('exit_raw',t['exit_price']/(1-cfg['slippage_pct']/100)),'qty':t['qty']}]
        sell_value=sum(x['raw_price']*(1-cfg['slippage_pct']*multiplier/100)*x['qty'] for x in raw_legs)
        invested=buy*(1+cfg['fee_pct']*multiplier/200)
        pnl=sell_value*(1-cfg['fee_pct']*multiplier/200)-invested
        values.append({'pnl':pnl,'return_pct':pnl/invested*100})
    n=len(values)
    return {'mode':'fixed_trades','trades':n,'win_rate':100*sum(x['pnl']>0 for x in values)/n if n else None,
            'avg_trade_pct':sum(x['return_pct'] for x in values)/n if n else None,
            'realized_pnl':sum(x['pnl'] for x in values),
            'note':'기존 매매일·수량·비용 전 체결가 고정, 완료 거래 비용만 2배. 계좌수익률/낙폭 재계산이 아닙니다.'}
