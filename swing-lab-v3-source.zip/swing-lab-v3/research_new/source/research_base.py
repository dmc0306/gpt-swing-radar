"""Eight declared hypotheses, seven comparable account scenarios each."""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime,timezone
import argparse,json,math
import engine
from context import load,dump,sha,ROOT,DATASET,RUN

DEFINITIONS=[
 ('bb_low60','볼린저·ADX + 60일선 이하',.75,'timeout'),
 ('bb_flush','볼린저·ADX + 직전 거래량 증가',.75,'timeout'),
 ('bb_low60_flush','볼린저·ADX + 60일선 이하 + 직전 거래량 증가',.75,'timeout'),
 ('bb_adx_half','볼린저·ADX + 0.50R 익절',.5,'timeout'),
 ('bb_low60_flush_half','60일선 이하·거래량 증가 + 0.50R 익절',.5,'timeout'),
 ('rsi_rebound_adx','RSI2 과매도 회복 + ADX',.75,'timeout'),
 ('bb_adx_stall5','볼린저·ADX + 5일 정체 청산',.75,'stall5'),
 ('recovery_breadth_adx','과매도 회복 + 표본 확산 + ADX',.75,'timeout'),
]

def build_maps(c,adx_limit=25.,volume_limit=1.):
    maps={key:defaultdict(list) for key,_,_,_ in DEFINITIONS}
    maps['bb_adx']=defaultdict(list);maps['bb_reentry']=defaultdict(list)
    rec={(s['code'],d) for d,ss in c['prepared']['signals']['recovery'].items() for s in ss}
    for day,signals in c['all_signals'].items():
        for s in signals:
            f=c['features'][(s['code'],day)]
            low_adx=f['adx14'] is not None and f['adx14']<adx_limit
            bb=f['close']>f['ma120'] and f['prev_close']<f['prev_bb_lower'] and f['close']>=f['bb_lower']
            parent=bb and low_adx
            low60=f['close']<=f['ma60']
            flush=f['prev_vratio'] is not None and f['prev_vratio']>volume_limit
            broad=s['breadth_count']>=50 and s['breadth_pct']>=50
            rsi=f['prev_rsi2'] is not None and f['prev_rsi2']<=10 and f['rsi2']>10 and f['close']>f['open'] and f['close']>f['ma120'] and low_adx
            passes={'bb_reentry':bb,'bb_adx':parent,'bb_low60':parent and low60,'bb_flush':parent and flush,
                    'bb_low60_flush':parent and low60 and flush,'bb_adx_half':parent,
                    'bb_low60_flush_half':parent and low60 and flush,'rsi_rebound_adx':rsi,
                    'bb_adx_stall5':parent,'recovery_breadth_adx':(s['code'],day) in rec and broad and low_adx}
            for key,passed in passes.items():
                if passed:maps[key][day].append({**s,'reason':key})
    return {k:dict(v) for k,v in maps.items()}

def prepared_for(c,smap,codes=None):
    if codes is not None:smap={d:[s for s in ss if s['code'] in codes] for d,ss in smap.items()}
    return {**c['prepared'],'signals':{**c['prepared']['signals'],'recovery':smap}}

def simulate(c,smap,ds,spec,cfg):
    result=engine.simulate(prepared_for(c,smap),ds,spec,cfg)
    for t in result['trades']+result['open']:
        f=c['features'].get((t['code'],t['signal_date']),{})
        t['observed_signal_indicators']={k:f.get(k) for k in ('ma20','ma60','ma120','bb_lower','adx14','rsi2','prev_rsi2','prev_vratio','volume_ratio','close_location','atr')}
    m=result['metrics'];result['pnl_reconciliation_residual_krw']=m['equity']-cfg['capital']-m['realized_pnl']-m['unrealized']
    return result

def annual_continuous(result,capital):
    years={};previous=capital
    for point in result['curve']:
        y=point['date'][:4]
        if y not in years:years[y]={'initial_equity':previous,'peak':previous,'max_drawdown_pct':0,'start':point['date']}
        q=years[y];q['peak']=max(q['peak'],point['equity']);q['end']=point['date']
        q['max_drawdown_pct']=min(q['max_drawdown_pct'],100*(point['equity']/q['peak']-1))
        q['total_return_pct']=100*(point['equity']/q['initial_equity']-1);previous=point['equity']
    for y,q in years.items():
        ts=[t for t in result['trades'] if t['exit_date'].startswith(y)]
        q.update(trades=len(ts),wins=sum(t['pnl']>0 for t in ts),closed_pnl=sum(t['pnl'] for t in ts))
        q['win_rate']=100*q['wins']/len(ts) if ts else None
    return years

def qualification(v):
    m=v['recent']['metrics'];f=v['result']['metrics'];reasons=[];observational=[]
    if m['trades']<100:reasons.append('최근100거래미만')
    if m['total_return_pct']<=0 or (m['avg_trade_pct'] or 0)<=0:reasons.append('최근수익/평균손익미충족')
    if abs(m['max_drawdown_pct'])>10:reasons.append('최근낙폭10%초과')
    if any(x['metrics']['trades']<20 for x in v['thirds']):reasons.append('부분기간20거래미만')
    if any(x['metrics']['total_return_pct']<=0 or (x['metrics']['avg_trade_pct'] or 0)<=0 for x in v['thirds']):reasons.append('부분기간수익/평균손익미충족')
    if v['stress2']['recent']['total_return_pct']<=0:reasons.append('최근비용2배손실')
    if f['trades']<100:observational.append('전체100거래미만')
    if m['trades']<30:observational.append('최근30거래미만')
    if any(x['total_return_pct']<=0 or (x['avg_trade_pct'] or 0)<=0 for x in (f,m)):observational.append('전체/최근순수익미충족')
    if any(v['stress2'][k]['total_return_pct']<=0 for k in ('full','recent')):observational.append('전체/최근비용2배손실')
    if abs(f['max_drawdown_pct'])>10:observational.append('전체낙폭10%초과')
    if (f.get('without_top5_pnl') or 0)<=0:observational.append('상위5이익제외실현손익미충족')
    return {'eligible':not reasons,'ineligible_reasons':reasons,'observation_gate':not observational,'observation_gate_reasons':observational}

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--previous',required=True);a=p.parse_args()
    c=load(a.input);maps=build_maps(c);old=json.loads(Path(a.previous).read_text());cfg=c['cfg']
    if old['dataset_id']!=DATASET or old['engine_sha256']!=sha(Path(engine.__file__)) or old['config']!=cfg:raise ValueError('대조군 원자료/엔진/비용이 다릅니다.')
    spec0={'strategy':'recovery','filter':'risk_cap','hold':15,'reward':.75,'exit_policy':'timeout'}
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'dataset_id':DATASET,'run_id':RUN,'config':cfg,
            'engine_sha256':sha(Path(engine.__file__)),'protocol_sha256':sha(ROOT/'PROTOCOL.md'),'input_zip_sha256':sha(a.input),
            'full_start':c['full'][0],'recent_start':c['recent'][0],'end':c['full'][-1],'full_days':len(c['full']),'recent_days':len(c['recent']),
            'simulation_count':0,'variants':[],'comparators':[]}
    for v in old['variants']+old['comparators']:
        if v['id'] in ('bb_adx','bb_reentry','risk_breadth','risk_partial','breadth_partial','bb_half_r'):
            item=dict(v);item.update(qualification(item));report['comparators'].append(item)
    for key,name,reward,policy in DEFINITIONS:
        spec={**spec0,'reward':reward,'exit_policy':policy}
        v={'id':key,'name':name,'execution_spec':spec,'signal_counts':{lab:sum(len(engine.select_signals(prepared_for(c,maps[key]),d,spec)) for d in ds) for lab,ds in [('full',c['full']),('recent',c['recent'])]}}
        v['result']=simulate(c,maps[key],c['full'],spec,cfg);v['recent']=simulate(c,maps[key],c['recent'],spec,cfg)
        v['thirds']=[]
        for j in range(3):
            ds=c['recent'][len(c['recent'])*j//3:len(c['recent'])*(j+1)//3]
            x=simulate(c,maps[key],ds,spec,cfg)
            v['thirds'].append({'start':ds[0],'end':ds[-1],'metrics':x['metrics'],'pnl_reconciliation_residual_krw':x['pnl_reconciliation_residual_krw']})
        stress_cfg={**cfg,'fee_pct':cfg['fee_pct']*2,'slippage_pct':cfg['slippage_pct']*2}
        v['stress2']={lab:simulate(c,maps[key],ds,spec,stress_cfg)['metrics'] for lab,ds in [('full',c['full']),('recent',c['recent'])]}
        v['fixed_cost']=engine.fixed_cost_diagnostic(v['result'],cfg)
        v['years']=annual_continuous(v['result'],cfg['capital'])
        v['exit_reasons']=dict(Counter(t['exit_reason'] for t in v['result']['trades']))
        bystock=defaultdict(lambda:{'pnl':0.,'trades':0})
        for t in v['result']['trades']:
            b=bystock[t['code']];b['name']=t['name'];b['pnl']+=t['pnl'];b['trades']+=1
        v['top_stocks']=sorted(bystock.items(),key=lambda x:x[1]['pnl'],reverse=True)[:10]
        v['concentration']={'unique_stocks':len(bystock),'without_top5_trade_pnl':v['result']['metrics']['without_top5_pnl']}
        v.update(qualification(v));report['simulation_count']+=7;report['variants'].append(v)
        dump(ROOT/'results'/'comparison.json',report)
        metric_keys=('trades','win_rate','total_return_pct','max_drawdown_pct','avg_trade_pct','profit_factor')
        print(json.dumps({'id':key,'full':{k:v['result']['metrics'][k] for k in metric_keys},'recent':{k:v['recent']['metrics'][k] for k in metric_keys},
            'stress2_full':v['stress2']['full']['total_return_pct'],'stress2_recent':v['stress2']['recent']['total_return_pct'],
            'observation_gate':v['observation_gate'],'reasons':v['observation_gate_reasons'],'eligible':v['eligible']},ensure_ascii=False),flush=True)
    print('DONE',report['simulation_count'],flush=True)

if __name__=='__main__':main()
