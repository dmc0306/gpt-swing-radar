"""Versioned, user-supplied point-in-time membership. Endpoints inclusive."""
import csv, io, json, re
from collections import defaultdict
from datetime import date
import store

def import_csv(text):
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not {'code','start','end','known_at'}<=set(reader.fieldnames or []):raise ValueError('필수 열: code,start,end,known_at. 종료 없는 end는 비워두세요.')
    rows=[]
    for number,r in enumerate(reader,2):
        try:
            code=r['code'].strip().zfill(6);start=date.fromisoformat(r['start'].strip()).isoformat();end=date.fromisoformat(r['end'].strip()).isoformat() if r['end'].strip() else '9999-12-31';known=date.fromisoformat(r['known_at'].strip()).isoformat()
            if not re.fullmatch(r'[0-9A-Z]{6}',code) or end<start or known>start:raise ValueError('코드/기간 오류 또는 known_at이 시작일보다 늦음')
            rows.append({'code':code,'start':start,'end':end,'known_at':known})
        except Exception as e:raise ValueError(f'{number}행: {e}')
        if len(rows)>100000:raise ValueError('최대 10만 행')
    if not rows:raise ValueError('구성종목 자료가 비었습니다.')
    rows=sorted(rows,key=lambda r:(r['code'],r['start']));previous={}
    for r in rows:
        if previous.get(r['code'],'')>=r['start']:raise ValueError(r['code']+' 구성 기간 중복')
        previous[r['code']]=r['end']
    ident=store.digest(rows);record={'id':ident,'created':store.now(),'rows':rows,'symbols':len(previous),'start':min(r['start'] for r in rows),'end':max(r['end'] for r in rows)}
    store.write(store.ROOT/'membership'/(ident+'.json'),record);return {'membership_id':ident}

def load(ident):
    store.check_id(ident)
    return json.loads((store.ROOT/'membership'/(ident+'.json')).read_text())

def catalog():
    root=store.ROOT/'membership'
    return sorted([{k:v for k,v in json.loads(p.read_text()).items() if k!='rows'} for p in root.glob('*.json')],key=lambda x:x['created'],reverse=True)[:30]

def apply(prepared,ident):
    if not ident:return {'mode':'current','note':'당시 구성 자료 없음: 현재 선택 종목의 생존·선택 편향이 남습니다.'}
    record=load(ident);spans=defaultdict(list)
    for r in record['rows']:spans[r['code']].append(r)
    def allowed(code,day):return any(r['known_at']<=day and r['start']<=day<=r['end'] for r in spans[code])
    for mapping in prepared['signals'].values():
        for day,ss in mapping.items():
            mapping[day]=[s for s in ss if allowed(s['code'],day)]
            sample=[v for code,v in prepared.get('breadth',{}).get(day,{}).items() if allowed(code,day)]
            for sig in mapping[day]:sig.update(breadth_count=len(sample),breadth_pct=100*sum(sample)/len(sample) if sample else 0)
    available={code for bars in prepared['bars'].values() for code in bars}
    first,last=prepared['dates'][0],prepared['dates'][-1]
    needed={r['code'] for r in record['rows'] if r['start']<=last and r['end']>=first}
    missing=sorted(needed-available)
    return {'mode':'uploaded','id':ident,'missing_codes':missing,'note':'사용자 입력 기간으로 신호일 편입 여부를 적용했습니다. 상장폐지 포함 여부·당시 공시 진위·가격 이력 완전성은 인증하지 않습니다. 편출은 기존 보유분 강제청산을 의미하지 않습니다.'}
