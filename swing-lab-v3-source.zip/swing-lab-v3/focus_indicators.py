import numpy as np

def _wilder(values,n=14):
    out=np.full(len(values),np.nan);seed=[];last=None
    for i,x in enumerate(values):
        if not np.isfinite(x):continue
        if last is None:
            seed.append(x)
            if len(seed)<n:continue
            last=float(np.mean(seed))
        else:last=((n-1)*last+x)/n
        out[i]=last
    return out

def _adx(df,tr):
    up=df.high.diff().to_numpy();down=(-df.low.diff()).to_numpy()
    plus=np.where((up>down)&(up>0),up,0.);minus=np.where((down>up)&(down>0),down,0.)
    raw=tr.to_numpy(copy=True);raw[0]=np.nan;plus[0]=np.nan;minus[0]=np.nan
    a=_wilder(raw);p=_wilder(plus);m=_wilder(minus)
    pdm=np.divide(100*p,a,out=np.full(len(a),np.nan),where=a>0)
    mdm=np.divide(100*m,a,out=np.full(len(a),np.nan),where=a>0)
    den=pdm+mdm;dx=np.divide(100*np.abs(pdm-mdm),den,out=np.zeros(len(a)),where=den>0)
    dx[~np.isfinite(den)]=np.nan
    return _wilder(dx)

