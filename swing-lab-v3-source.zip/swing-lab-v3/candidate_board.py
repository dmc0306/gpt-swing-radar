"""Read-only, asynchronous all-strategy candidate board and on-demand price checks."""
import hashlib, json, math, re, secrets, threading
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from fastapi import HTTPException
import pattern_rank
import stock_names
import candidate_pool, engine, eligibility, reward_candidates, session_calendar, store, strategies

QUOTE_LOCK=threading.Lock()

def version():
    return hashlib.sha256(candidate_pool.version().encode()+Path(__file__).read_bytes()+Path(reward_candidates.__file__).read_bytes()).hexdigest()

def read(ident):
    if not re.fullmatch('[0-9a-f]{24}',str(ident)):raise ValueError('후보 조회 번호 오류')
    path=store.ROOT/'candidate_boards'/(ident+'.json')
    if not path.exists():raise ValueError('후보 조회 기록이 없습니다. 다시 찾아 주세요.')
    return stock_names.hydrate(json.loads(path.read_text()))

def search(payload,progress=lambda **kw:None):
    ident=payload.get('dataset_id') or strategies.latest_dataset()
    store.check_id(ident)
    cfg=engine.config({'max_positions':10,**(payload.get('config') or {})})
    budget=float(payload['budget'] if payload.get('budget') is not None else cfg['capital']*cfg['position_pct']/100)
    if not math.isfinite(budget) or not 0<budget<=cfg['capital']:raise ValueError('한 종목에 쓸 돈은 0보다 크고 원금 이하여야 합니다.')
    mode=payload.get('strategy_id')
    defs=[strategies.get(mode)] if mode else list(strategies.DEFS.values())
    exclusion_refresh=None
    if payload.get('refresh_exclusions',False):
        try:exclusion_refresh=eligibility.capture(progress)
        except InterruptedError:raise
        except Exception:exclusion_refresh={'error':'오늘 제외할 종목을 새로 확인하지 못했습니다. 확인되지 않은 후보는 보류합니다.'}
    now=datetime.fromisoformat(store.now()).astimezone(ZoneInfo('Asia/Seoul'));today=now.date().isoformat()
    pool,hit=candidate_pool.load(ident,cfg,today,now.hour*60+now.minute>=940,progress)
    # Capture the gate after the new exclusions have been saved; all methods share it.
    gate=eligibility.Gate(live=True,days=[today]);scans=[]
    for i,s in enumerate(defs):
        progress(stage='후보 결과 정리 · '+s['name'],done=i,total=len(defs))
        snapshot=candidate_pool.project(pool,s['spec'])
        result=reward_candidates._scan(ident,{'mode':s['id'],'config':cfg,'budget':budget},(snapshot,hit),now,gate,watch_limit=None)
        result.update(strategy=s,fixed_reward=s['spec']['reward'],exit_rule=s['exit'],price_basis='확정 일봉 종가 가정')
        scans.append(result)
    counts={'allowed':0,'excluded':0,'unknown':0}
    for code in pool['codes']:
        d=gate.decision(code,today,now.isoformat(timespec='seconds'))
        counts['allowed' if d['allowed'] else 'excluded' if d['reason'].startswith('제외:') else 'unknown']+=1
    key=secrets.token_hex(12)
    board={'schema':1,'id':key,'kind':'candidate_board','dataset_id':ident,'generated_at':now.isoformat(timespec='seconds'),
           'finished_at':store.now(),'date':pool['latest'],'expected_date':scans[0]['expected_date'],
           'scanned_symbols':pool['symbols'],'config':cfg,'budget':budget,'mode':mode or 'all',
           'calculation_version':version(),'scans':scans,'exclusion_counts':counts,'exclusion_refresh':exclusion_refresh,
           'note':'5개 중 하나라도 충족하는 종목을 모아 봅니다. 통합 전략의 승률을 계산한 것은 아닙니다. 같은 종목의 중복 신호를 새 거래로 세지 않습니다.',
           'pattern_ranking':pattern_rank.build(pool,gate,now,scans[0]['expected_date'],cfg,budget),
           'entry_note':'기존 전략은 확정 일봉의 신호 다음 거래일 시가 진입입니다. 장중 가격 확인은 가격 점검이며, 장중 진입 승률을 검증한 결과가 아닙니다.'}
    store.write(store.ROOT/'candidate_boards'/(key+'.json'),board)
    # Keep one last result for convenient diagnostic exports; never replace past boards.
    store.write(store.ROOT/'candidate_snapshots'/'all-latest.json',board)
    return {'candidate_board_id':key,'warning':exclusion_refresh.get('error') if exclusion_refresh else None}

def _price(code):
    # Official read-only stock information endpoint. No account/order APIs.
    import kiwoom
    if not kiwoom.APPKEY or not kiwoom.SECRET:raise ValueError('서버에 연결된 키움 API 설정이 없습니다. 설정 후 다시 확인하세요.')
    try:_,raw=kiwoom._post('/api/dostk/stkinfo','ka10001',{'stk_cd':code},timeout=8)
    except Exception:raise ValueError('현재 가격을 받지 못했습니다. 키움 연결 상태를 확인하고 다시 누르세요.') from None
    returned=str(raw.get('stk_cd','')).strip()
    if returned!=code:raise ValueError('요청 종목과 응답 종목이 달라 현재 가격 확인을 보류했습니다.')
    def number(key):
        try:v=abs(float(str(raw.get(key,'')).replace(',','').strip()))
        except (ValueError,TypeError):return None
        return v if math.isfinite(v) and v>0 else None
    price=number('cur_prc')
    if price is None:raise ValueError('현재 가격이 비어 있거나 0입니다. 매수 가능한 가격으로 표시하지 않습니다.')
    return {'code':code,'price':price,'base_price':number('base_pric'),'received_at':store.now(),
            'source':'키움 ka10001 · KRX 현재가','mock':'mockapi.' in kiwoom.BASE,
            'exchange_time':None,'note':'API 응답을 받은 시각입니다. 거래소 체결 시각과 매수 호가·잔량은 이 응답으로 확인하지 못합니다.'}

def price_check(ident,payload):
    board=read(ident)
    if board.get('calculation_version')!=version():raise ValueError('후보 계산 코드가 바뀌었습니다. 종목을 다시 찾아 주세요.')
    code=str(payload.get('code',''))
    if not re.fullmatch('[0-9A-Z]{6}',code):raise ValueError('종목코드 오류')
    matches=[(s,r) for s in board['scans'] for r in s['rows'] if r['code']==code]
    ranked=next((r for r in board.get('pattern_ranking',{}).get('rows',[]) if r['code']==code),None)
    if ranked and ranked.get('win_score'):
        cfg={**board['config'],'fee_pct':.2,'slippage_pct':.05}
        row={**ranked,'volume_limit':ranked['volume_limit']*cfg['max_participation_pct']/100}
        spec={'reward':.4,'filter':'risk_cap','exit_policy':'timeout','hold_days':15}
        matches.append(({'mode':'pattern_win','mode_name':'데이터 패턴 · 0.4R 가격 점검','strategy':{'spec':spec},'config':cfg,'budget':board['budget']},row))
    if not matches:raise ValueError('일봉 진입 조건을 충족한 후보만 현재 가격으로 확인할 수 있습니다.')
    now=datetime.fromisoformat(store.now()).astimezone(ZoneInfo('Asia/Seoul'))
    if board['generated_at'][:10]!=now.date().isoformat():raise ValueError('지난 날짜에 찾은 목록입니다. 종목을 다시 찾아 주세요.')
    if not QUOTE_LOCK.acquire(blocking=False):raise HTTPException(409,'다른 가격을 확인 중입니다. 잠시 뒤 다시 누르세요.')
    try:current=_price(code)
    finally:QUOTE_LOCK.release()
    now=datetime.fromisoformat(store.now()).astimezone(ZoneInfo('Asia/Seoul'));today=now.date().isoformat()
    expected,_=reward_candidates._expected(now,{board['date']})
    gate=eligibility.Gate(live=True,days=[today]);decision=gate.decision(code,today,now.isoformat(timespec='seconds'))
    common=[]
    if board['generated_at'][:10]!=today:common.append('조회 중 날짜가 바뀌었습니다. 종목을 다시 찾아 주세요.')
    if board['date']!=expected:common.append('필요한 일봉 날짜가 바뀌었습니다. 자료를 새로 받고 종목을 다시 찾으세요.')
    if not decision['allowed']:common.append(decision['reason'])
    if current['mock']:common.append('키움 모의 API 가격입니다. 실제 시장 진입 판단에 사용할 수 없습니다.')
    opened=session_calendar.get()['days'].get(today);minute=now.hour*60+now.minute
    regular=opened!=0 and (opened==1 or now.weekday()<5) and 540<=minute<920
    if not regular:common.append('정규장 가격 확인 시간 밖입니다. 다음 정규장에서 다시 확인하세요.')
    configs=[]
    for scan,row in matches:
        spec=scan['strategy']['spec'];cfg=scan['config']
        q=reward_candidates.quote(row,current['price'],cfg,scan['budget'],spec['reward'],spec['filter']=='risk_cap')
        reasons=list(dict.fromkeys(common+[r for r in row['data_reasons'] if r!=row.get('eligibility',{}).get('reason')]+q['reasons']))
        if scan['mode']=='pattern_win':
            if not row['win_score']['gate_pass']:reasons.append('데이터 패턴의 매매 채택 기준 미달 · 관찰용 가격 계획')
            if row['win_score']['out_of_range']:reasons.append('지표가 모델 학습 범위 밖입니다. 매수 판단 보류')
        # Comparing an adjusted daily signal with an unadjusted current quote can be invalid.
        # Only compare the prior session when that is the model's expected signal date.
        if expected<today:
            base=current['base_price']
            if base is None:reasons.append('당일 기준가가 없어 과거 일봉과 가격 기준을 대조하지 못했습니다.')
            elif abs(base-row['close'])>max(1,row['close']*.01):reasons.append('당일 기준가와 신호 종가가 1% 넘게 다릅니다. 권리락·조정주가·날짜를 확인하세요.')
        configs.append({'strategy_id':scan['mode'],'name':scan['mode_name'],'spec':spec,'level':q,
                        'price_conditions_pass':not reasons,'reasons':reasons})
    record={'id':secrets.token_hex(12),'board_id':ident,'code':code,'name':matches[0][1]['name'],
            'quote':current,'generated_at':store.now(),'levels':configs,'eligibility':decision,
            'entry_timing_verified':False,'trade_allowed':False,
            'entry_note':'가격 조건 통과는 장중 매수 신호가 아닙니다. 검증한 진입은 다음 거래일 시가이며, 장중 진입의 승률은 아직 계산하지 않았습니다.'}
    store.write(store.ROOT/'candidate_price_checks'/(record['id']+'.json'),record)
    return record
