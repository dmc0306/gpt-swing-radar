"""Explicit session dates. Unknown weekday gaps are never skipped."""
import csv, io, json
from datetime import date, timedelta
import store
PATH=store.ROOT/'session_calendar.json'
def get():return json.loads(PATH.read_text()) if PATH.exists() else {'days':{},'source':'휴장일 자료 미등록'}
def import_csv(text):
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not {'date','is_open'}<=set(reader.fieldnames or []):raise ValueError('달력 필수 열: date,is_open (1=거래일, 0=휴장일)')
    current=get();days=dict(current['days']);incoming={}
    for n,r in enumerate(reader,2):
        try:
            d=date.fromisoformat(r['date'].strip()).isoformat();v=r['is_open'].strip()
            if v not in ('0','1'):raise ValueError('is_open은 0 또는 1')
            if d in incoming and incoming[d]!=int(v):raise ValueError('중복 날짜 충돌')
            if d in days and days[d]!=int(v):raise ValueError('기존 달력과 충돌. 확정 날짜는 변경하지 않습니다.')
            incoming[d]=int(v)
        except Exception as e:raise ValueError(f'{n}행: {e}')
    if not incoming or len(incoming)>20000:raise ValueError('달력은 1~20000행')
    days.update(incoming)
    if PATH.exists():store.write(store.ROOT/'calendar_archive'/(store.digest(current)+'.json'),current)
    store.write(PATH,{'days':days,'updated':store.now(),'source':'사용자 제공 달력 CSV · 공식성 자동 인증 안 함'})
    return {'calendar_dates':len(days)}
def decisions(last,through,observed):
    explicit=get()['days'];d=date.fromisoformat(last)+timedelta(days=1);end=date.fromisoformat(through)
    while d<=end:
        day=d.isoformat();known=explicit.get(day)
        if day in observed:yield day,'conflict' if known==0 else 'open'
        elif known==1:yield day,'missing'
        elif known==0 or d.weekday()>4:yield day,'closed'
        else:yield day,'unknown'
        d+=timedelta(days=1)
