"""Read-only explanations. Never feeds engine signals, orders or notifications."""
import math
import pandas as pd
from focus_indicators import _adx

def distance_score(passed, value, target, width, direction=1):
    """Condition closeness, not a calibrated probability; hard rules stay separate."""
    if value is None or target is None or not all(math.isfinite(x) for x in (value,target,width)) or width<=0:return None
    if passed:return 100.0
    gap=max(0.0,(target-value)*direction)
    return round(min(99.9,max(0.0,100*(1-gap/width))),1)

def inspect(rows, cfg, strategy, day):
    if not rows or rows[-1]['date'] != day:return None
    d=pd.DataFrame(sorted(rows,key=lambda r:r['date']));c=d.close;p=c.shift(1)
    tr=pd.concat([d.high-d.low,(d.high-p).abs(),(d.low-p).abs()],axis=1).max(axis=1)
    atr=tr.rolling(14).mean();m120=c.rolling(120).mean();m60=c.rolling(60).mean()
    vm=d.volume.rolling(20).mean().shift(1);turn=(c*d.volume).rolling(20).mean()
    def last(x):
        v=float(x.iloc[-1]);return v if math.isfinite(v) else None
    a=last(atr);ma=last(m120);v=last(vm);t=last(turn);r=rows[-1]
    base=all(x is not None for x in (a,ma,v,t)) and a>0 and v>0 and r['close']>=cfg['min_price'] and t>=cfg['min_turnover'] and r['volume']>0
    basic_score=None if any(x is None for x in (a,ma,v,t)) else (0.0 if a<=0 or v<=0 or r['volume']<=0 else round(100*min(1,r['close']/max(cfg['min_price'],1),t/max(cfg['min_turnover'],1)),1))
    if basic_score is not None and not base:basic_score=min(99.9,basic_score)
    checks=[{'label':'기본 이력·가격·거래대금','passed':bool(base),'value':t,'unit':'원 (20일 평균 거래대금)',
             'score':basic_score,'score_note':'가격·거래대금의 기준 대비 비율 중 낮은 값. 이력 부족은 점수 없음, ATR·거래량이 0 이하면 0점.'}]
    def scored(label,passed,value,target,width,direction=1,unit='원',note=''):
        add(label,passed,value,unit)
        checks[-1].update(score=distance_score(passed,value,target,width,direction),score_note=note,score_target=target)
    def add(label,passed,value=None,unit='원'):checks.append({'label':label,'passed':bool(passed),'value':value,'unit':unit})
    scored('종가 > 120일선',ma is not None and r['close']>ma,r['close'],ma,(ma or 0)*.05,note='종가가 120일선에 가까울수록 높음. 선보다 5% 낮으면 0점.')
    if strategy=='recovery':
        change=last((c/c.shift(3)-1)*100);ph=last(d.high.shift(1))
        scored('3거래일 수익률 < -2.5%',change is not None and change < -2.5,change,-2.5,2.5,-1,'%', '3일 수익률이 -2.5%에 가까울수록 높음. 0% 이상은 0점.')
        scored('종가 > 당일 시가',r['close']>r['open'],r['close'],r['open'],r['open']*.05,note='종가가 시가보다 5% 낮으면 0점.')
        scored('종가 > 전일 고가',ph is not None and r['close']>ph,r['close'],ph,(ph or 0)*.05,note='종가가 전일 고가보다 5% 낮으면 0점.')
    else:
        lower=c.rolling(20).mean()-2*c.rolling(20).std(ddof=0)
        ad=float(_adx(d,tr)[-1]);ad=ad if math.isfinite(ad) else None
        m=last(m60);pr=last(p);lbp=last(lower.shift(1));lb=last(lower)
        ratio=last(d.volume.shift(1)/vm.shift(1))
        scored('종가 ≤ 60일선',m is not None and r['close']<=m,r['close'],m,(m or 0)*.05,-1,note='종가가 60일선보다 5% 높으면 0점.')
        scored('ADX14 < 25',ad is not None and ad<25,ad,25,10,-1,'','ADX가 25에 가까울수록 높음. 35 이상은 0점.')
        scored('전일 종가 < 전일 볼린저 하단',pr is not None and lbp is not None and pr<lbp,pr,lbp,(lbp or 0)*.05,-1,note='전일 종가가 전일 볼린저 하단보다 5% 높으면 0점.')
        scored('종가 ≥ 볼린저 하단',lb is not None and r['close']>=lb,r['close'],lb,(lb or 0)*.05,note='종가가 볼린저 하단보다 5% 낮으면 0점.')
        scored('전일 거래량 / 그 이전 20일 평균 > 1',ratio is not None and ratio>1,ratio,1,1,1,'배','평균 거래량 대비 비율 × 100. 1배 초과면 100점.')
    return {'code':r['code'],'name':r['name'],'date':day,'close':r['close'],'turnover':t or 0,'risk_pct':150*a/r['close'] if a is not None else None,'checks':checks}

def summarize(items,spec,breadth):
    pct=100*sum(breadth.values())/len(breadth) if breadth else 0
    for r in items:
        risk=r['risk_pct']
        ck={'label':'초기 손절 거리 ≤ 8%','passed':risk is not None and risk<=8,'value':risk,'unit':'%'} if spec['filter']=='risk_cap' else {'label':'표본 50종목 이상·60일선 위 비율 ≥ 50%','passed':len(breadth)>=50 and pct>=50,'value':pct,'unit':'% / '+str(len(breadth))+'종목'}
        if spec['filter']=='risk_cap':
            ck.update(score=distance_score(ck['passed'],risk,8,8,-1),score_note='손절 거리가 8% 이하면 100점, 16% 이상이면 0점. 실제 손실 상한 보장이 아님.')
        else:
            ck.update(score=round(100*min(1,len(breadth)/50,pct/50),1),score_note='표본 수/50과 60일선 위 비율/50 중 낮은 비율. 시장 지수가 아닌 선택 표본의 상태.')
        r['checks'].append(ck)
        scores=[c.get('score') for c in r['checks']]
        r['condition_score']=round(sum(scores)/len(scores),1) if all(v is not None for v in scores) else None
        r['failed_conditions']=[c['label'] for c in r['checks'] if not c['passed']]
        if r['condition_score'] is not None and r['failed_conditions']:r['condition_score']=min(99.9,r['condition_score'])
    funnel=[]
    if items:
        for i,c in enumerate(items[0]['checks']):
            remaining=[r for r in items if all(x['passed'] for x in r['checks'][:i+1])]
            remaining.sort(key=lambda r:(-(r['condition_score'] if r['condition_score'] is not None else -1),-r['turnover'],r['code']))
            funnel.append({'label':c['label'],'count':len(remaining),'stocks':[
                {'code':r['code'],'name':r['name'],'date':r['date'],'close':r['close'],
                 'condition_score':r['condition_score'],'remaining_conditions':[x['label'] for x in r['checks'][i+1:] if not x['passed']]}
                for r in remaining]})
    near=[r for r in items if r['checks'][0]['passed'] and 1<=len(r['failed_conditions'])<=2]
    near.sort(key=lambda r:(-(r['condition_score'] if r['condition_score'] is not None else -1),-r['turnover'],r['code']))
    return funnel,near
