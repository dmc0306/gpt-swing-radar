# v3.14.5 — 빠른 앱 업데이트

- 기본 설치는 필요한 기본 Python 도구가 모두 있으면 apt-get update 및 apt 설치를 건너뜁니다.
- 기존 가상환경을 재사용합니다. 설치된 Python 패키지가 requirements.txt의 버전 범위를 만족하면 pip 설치/다운로드도 건너뜁니다.
- bash install.sh --update: 앱 파일만 업데이트. apt/pip 다운로드 없음. 기존 앱과 필수 패키지는 서비스 중지 전에 확인하며 부족하면 기존 서비스를 중지하지 않고 종료합니다.
- bash install.sh --deps: 필요할 때 기본 도구/필수 패키지 설치를 명시적으로 다시 요청하는 옵션. 전체 운영체제 업그레이드를 실행하는 옵션은 아닙니다.
- 기본 설치와 업데이트 모두 기존 data/ 및 외부 인증 유지, 소스 백업, 서비스 설정/재시작, 포트8000 유지.
- 전략·가격·분석·모의계좌 계산 코드는 변경하지 않았습니다. 이전817종목 분석 보고서와 전체 종목 비교 기능 유지.

## 업데이트
새 ZIP을 서버 홈에 swing-lab-v3.zip으로 올린 뒤 실행:
```bash
mkdir -p ~/swing-lab-v3145-update
unzip -o ~/swing-lab-v3.zip -d ~/swing-lab-v3145-update
cd ~/swing-lab-v3145-update/swing-lab-v3
bash install.sh --update
```
처음 설치하거나 필수 패키지가 부족할 때는 bash install.sh를 사용하세요. 이미 실행 중인 이전 설치 스크립트의 동작을 소급 변경하지는 않습니다. 진행 중 수집/계산은 먼저 완료하거나 일시정지하세요.

## 확인 범위
기존 install.sh의 매번 apt-get update 및 pip 설치 실행을 실제 소스에서 확인하고 수정했습니다. 소스 검토 및 ZIP 작성만 수행했습니다. 설치 실행·앱/브라우저·구문/회귀 테스트·서버 배포는 사용자 요청에 따라 생략했습니다.
