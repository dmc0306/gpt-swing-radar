"""Opt-in daily planning notices, with a durable expiring Telegram outbox.

No intraday feed, brokerage orders, or actual-entry confirmations are provided.
"""
import json,math,threading,time
from datetime import datetime,timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import httpx
from fastapi import HTTPException
import store,engine,alerts,reward_candidates,session_calendar,strategies,operations

LOCK=threading.RLock()
PATH=store.ROOT/'phone_alert_settings.json'
SECRET=Path.home()/'.config/swing-lab-v3/telegram.json'
LAST_ATTEMPT=0.

def now():return datetime.now(ZoneInfo('Asia/Seoul'))

def get_settings():
    return json.loads(PATH.read_text()) if PATH.exists() else {'enabled':False,'telegram':False,'mode':'focused','reward':.4,'config':dict(engine.DEFAULT),'budget':2000000.,'revision':'initial'}

def init():
    with store.db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS phone_outbox(id TEXT PRIMARY KEY,created TEXT,expires TEXT,revision TEXT,title TEXT,body TEXT,status TEXT,attempts INTEGER,next_try REAL,message_id TEXT,error TEXT)')

def credential():
    if not SECRET.exists():return None
    value=json.loads(SECRET.read_text())
    if not value.get('token') or not str(value.get('chat_id','')).isdigit() or value.get('private_verified') is not True:return None
    return value

def view():
    with LOCK:
        init()
        with store.db() as c:
            cols=('id','created','title','status','attempts','error')
            recent=[dict(zip(cols,r)) for r in c.execute('SELECT id,created,title,status,attempts,error FROM phone_outbox ORDER BY created DESC LIMIT 10')]
        state_path=store.ROOT/'phone_alert_state.json'
        try:configured=bool(credential())
        except Exception:configured=False
        return {'settings':get_settings(),'configured':configured,'state':json.loads(state_path.read_text()) if state_path.exists() else {},'deliveries':recent,
                'scope':'장 마감 후·장전의 일봉 계획 알림입니다. 장중 가격 도달 감시·자동 주문·ChatGPT 푸시는 제공하지 않습니다.'}

def save(payload):
    with LOCK:
        s=get_settings();mode=str(payload.get('mode','focused'))
        spec=strategies.get(mode)['spec'];reward=spec['reward']
        cfg=engine.config(payload.get('config') or {})
        budget=float(payload.get('budget',cfg['capital']*cfg['position_pct']/100))
        if not math.isfinite(budget) or not 0<budget<=cfg['capital']:raise ValueError('주문금액은 0 초과·원금 이하')
        telegram=payload.get('telegram') is True
        if telegram and payload.get('enabled') is True and not credential():raise ValueError('설정 화면에서 본인 텔레그램 연결을 먼저 저장하세요.')
        cred=credential() if telegram else None
        s={'enabled':payload.get('enabled') is True,'telegram':telegram,'mode':mode,'reward':reward,'config':cfg,'budget':budget,'revision':store.digest([store.now(),time.time_ns()]),'enabled_at':store.now(),
           'recipient':store.digest([cred['token'].split(':',1)[0],cred['chat_id']]) if cred else None}
        init()
        with store.db() as c:c.execute("UPDATE phone_outbox SET status='cancelled',error='알림 설정 변경' WHERE status IN ('pending','retry')")
        store.write(PATH,s)
    return view()

def enqueue(key,title,body,expires,s):
    ident=store.digest(key);alerts.add(['phone',ident],'plan',title,body)
    if s['telegram']:
        with store.db() as c:c.execute('INSERT OR IGNORE INTO phone_outbox VALUES(?,?,?,?,?,?,?,?,?,?,?)',
            (ident,store.now(),expires.isoformat(timespec='seconds'),s['revision'],title,body,'pending',0,0.,None,None))

def scan(phase):
    s=get_settings()
    if not s['enabled']:return
    chosen=strategies.get(s['mode'])
    if s['reward']!=chosen['spec']['reward']:raise ValueError('이전 알림 설정입니다. 5개 고정 전략 중 선택해 다시 저장하세요.')
    moment=now();day=moment.date().isoformat();datasets=store.datasets()
    if not datasets:raise ValueError('가격 자료 없음')
    latest=max(datasets,key=lambda d:(d['end'],d['created']))
    d=reward_candidates.scan(latest['id'],{'mode':s['mode'],'config':s['config'],'budget':s['budget']})
    if now().date()!=moment.date():return
    rows=[]
    for r in d['rows']:
        q=next(q for q in r['levels'] if q['reward']==s['reward'])
        if r['screen_pass'] and q['price_conditions_pass']:rows.append((r,q))
    # Immutable evidence snapshot; keeps the exact signal/gates/price assumptions.
    evidence={'generated_at':d['generated_at'],'dataset_id':d['dataset_id'],'phase':phase,'settings':s,'result':d}
    with LOCK:
        if get_settings()['revision']!=s['revision'] or not get_settings()['enabled']:return
        init();store.write(store.ROOT/'phone_evidence'/(store.digest([d['generated_at'],phase,d['dataset_id'],s['revision']])+'.json'),evidence)
        # Morning plans expire at the open; no delayed buy notices after the open.
        expires=moment.replace(hour=9,minute=0,second=0,microsecond=0) if phase=='preopen' else (moment+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
        timing='오늘 개장일/실제 시가 확인 후 판단' if phase=='preopen' else '다음 거래일 시가 검토 · 당일 제외 상태 재확인'
        valid_ids=[store.digest([day,phase,d['dataset_id'],r['code'],s['revision']]) for r,q in rows[:10]]
        reasons=d['data_blocks'] or sorted({x for r in d['rows'] for x in r['data_reasons']}) or ['진입 조건/비용 후 목표손익 통과 후보 없음']
        if not rows:valid_ids.append(store.digest([day,phase,'blocked',d['dataset_id'],s['revision'],reasons]))
        with store.db() as c:
            pending=c.execute("SELECT id,title FROM phone_outbox WHERE revision=? AND status IN ('pending','retry')",(s['revision'],)).fetchall()
            for ident,title in pending:
                if title!='스윙 검증실 연결 확인' and ident not in valid_ids:c.execute("UPDATE phone_outbox SET status='cancelled',error='최신 조회에서 계획 보류/갱신' WHERE id=?",(ident,))
        for r,q in rows[:10]:
            title=('장전 계획 확인' if phase=='preopen' else '다음 거래일 진입 계획')+' · '+r['name']
            body=(f"{r['name']} ({r['code']}) | {reward_candidates.MODES[s['mode']]}\n"
                  f"신호일 {d['date']} / 확인 {d['generated_at']} / 자료 {d['dataset_id'][:8]}\n"
                  f"진입 시점: {timing}\n"
                  f"허용 가격: {r['reference_entry_range'][0]:,.2f}~{r['reference_entry_range'][1]:,.2f}원\n"
                  f"종가 {r['close']:,.2f}원 진입 가정 → 익절 {q['target']:,.2f} / 손절 {q['stop']:,.2f}원\n"
                  f"예상 {q['qty']:,}주 / 목표 {s['reward']}R / 전량 목표가 청산 가정 순손익 {q['target_net_pct']:.2f}%\n"
                  f"실제 체결가 E 기준: 첫 익절 E+{s['reward']*1.5*r['atr']:,.2f}, 손절 E-{1.5*r['atr']:,.2f}원.\n"
                  f"청산 규칙: {chosen['exit']}\n"
                  '계획 알림이며 지금 매수 지시/체결 확인이 아닙니다. 장중 도달 감시 없음. 가격 범위 밖은 진입 보류. 호가·시가·현금 확인 필요. 갭 손실은 손절폭보다 클 수 있습니다.')
            enqueue([day,phase,d['dataset_id'],r['code'],s['revision']],title,body,expires,s)
        if not rows:
            body=' / '.join(reasons)[:1300]+' · 신호일 '+d['date']+' · 후보가 없으면 매수 계획을 보내지 않습니다.'
            enqueue([day,phase,'blocked',d['dataset_id'],s['revision'],reasons],'진입 계획 없음/보류',body,expires,s)
        store.write(store.ROOT/'phone_alert_state.json',{'checked_at':store.now(),'phase':phase,'dataset_id':d['dataset_id'],'signal_date':d['date'],'pass_count':len(rows),'notified_count':min(len(rows),10),'note':'거래대금순 최대 10개. 각 수량은 독립 견적이며 동시 매수 수량이 아닙니다.','blocks':d['data_blocks']})

def flush():
    with LOCK:
        s=get_settings()
        if not s['enabled'] or not s['telegram']:return
        cred=credential()
        if not cred:return
        if s.get('recipient')!=store.digest([cred['token'].split(':',1)[0],cred['chat_id']]):return
        init();stamp=store.now()
        with store.db() as c:
            c.execute("UPDATE phone_outbox SET status='expired',error='알림 유효시간 경과' WHERE status IN ('pending','retry') AND expires<=?",(stamp,))
            rows=c.execute("SELECT id,title,body,attempts,expires FROM phone_outbox WHERE revision=? AND status IN ('pending','retry') AND next_try<=? AND expires>? ORDER BY created LIMIT 10",(s['revision'],time.time(),stamp)).fetchall()
        for ident,title,body,attempts,expires in rows:
            if store.now()>=expires:
                with store.db() as c:c.execute("UPDATE phone_outbox SET status='expired',error='알림 유효시간 경과' WHERE id=?",(ident,))
                continue
            status='retry';error=None;message_id=None;retry_after=300
            try:
                response=httpx.post('https://api.telegram.org/bot'+cred['token']+'/sendMessage',json={'chat_id':cred['chat_id'],'text':(title+'\n'+body)[:4000]},timeout=12,follow_redirects=False)
                value=response.json()
                if response.is_success and value.get('ok'):
                    status='sent';message_id=str(value['result']['message_id'])
                else:
                    error='Telegram 응답 '+str(response.status_code)
                    retry_after=max(60,min(3600,int(value.get('parameters',{}).get('retry_after',300))))
                    if response.status_code in (400,401,403):status='failed'
            except Exception as e:error=type(e).__name__+' · 응답 불확실, 재시도 시 중복 수신 가능'
            with store.db() as c:c.execute('UPDATE phone_outbox SET status=?,attempts=?,next_try=?,message_id=?,error=? WHERE id=?',(status,attempts+1,time.time()+retry_after,message_id,error,ident))

def test_message():
    with LOCK:
        s=get_settings()
        if not s['enabled'] or not s['telegram']:raise ValueError('계획 알림 및 텔레그램 전송을 먼저 켜세요.')
        init();enqueue(['test',time.time_ns()],'스윙 검증실 연결 확인','본인이 설정한 개인 채팅으로 보내는 시험 알림입니다. 현재 매수 신호가 아닙니다.',now()+timedelta(minutes=5),s)
    flush();return view()

def loop(stop):
    global LAST_ATTEMPT
    while not stop.wait(30):
        try:
            with operations.access():
                s=get_settings()
                if not s['enabled']:continue
                chosen=strategies.get(s['mode'])
                if s.get('reward')!=chosen['spec']['reward']:raise ValueError('이전 알림 조건: 5개 고정 전략으로 다시 저장 필요')
                dt=now();minute=dt.hour*60+dt.minute;closed=session_calendar.get()['days'].get(dt.date().isoformat())==0
                phase='preopen' if 530<=minute<540 else 'close' if 940<=minute<=1290 else None
                if phase and dt.weekday()<5 and not closed and time.monotonic()-LAST_ATTEMPT>=300:
                    scan(phase);LAST_ATTEMPT=time.monotonic()
                flush()
        except HTTPException:
            # Resource is busy/resetting; retry next tick without reporting a false data failure.
            continue
        except Exception as e:
            try:
                with operations.access():
                    store.write(store.ROOT/'phone_alert_state.json',{'checked_at':store.now(),'error':type(e).__name__,'note':'계획 알림 처리 실패. 고정5개 전략 설정과 자료/연결 상태를 확인하세요. 자동 매수는 실행되지 않습니다.'})
            except HTTPException:continue
