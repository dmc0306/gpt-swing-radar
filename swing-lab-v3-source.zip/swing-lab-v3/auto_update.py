"""Protocol-1 GitHub release updater. Run as the app user, never as root."""
import argparse
import ast
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

MAX_ZIP = 50 * 1024 * 1024
MAX_EXPANDED = 200 * 1024 * 1024


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    os.replace(temporary, path)


def version(value):
    if not re.fullmatch(r'\d+\.\d+\.\d+', str(value)):
        raise ValueError('정식 버전 번호가 필요합니다.')
    return tuple(map(int, value.split('.')))


def managed(name):
    path = PurePosixPath(name)
    if str(path) != name or '\\' in name or path.is_absolute() or '..' in path.parts:
        return False
    if len(path.parts) == 1:
        return name.endswith(('.py', '.md')) or name in ('requirements.txt', 'BUILD_MANIFEST.json', 'install.sh', 'enable-auto-update.sh')
    return path.parts[0] in ('web', 'reports') and path.suffix in ('.js', '.css', '.html', '.json', '.md', '.csv')


def download(url, limit):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname not in ('api.github.com', 'github.com'):
        raise ValueError('GitHub HTTPS 다운로드만 허용됩니다.')
    request = urllib.request.Request(url, headers={'User-Agent': 'Swing-Lab-Updater', 'Accept': 'application/vnd.github+json' if parsed.hostname == 'api.github.com' else 'application/octet-stream'})
    with urllib.request.urlopen(request, timeout=30) as response:
        value = response.read(limit + 1)
    if len(value) > limit:
        raise ValueError('업데이트 다운로드 크기 제한 초과')
    return value


def verify_package(blob, manifest, target):
    if manifest.get('protocol') != 1:
        raise ValueError('지원하지 않는 업데이트 형식')
    version(manifest['version'])
    if hashlib.sha256(blob).hexdigest() != manifest.get('sha256'):
        raise ValueError('업데이트 ZIP 검증 실패')
    expected = manifest.get('files')
    if not isinstance(expected, dict) or not expected or len(expected) > 2000:
        raise ValueError('업데이트 파일 목록 오류')
    required = {'app.py', 'requirements.txt', 'web/index.html', 'BUILD_MANIFEST.json'}
    if not required <= expected.keys() or not all(managed(n) for n in expected):
        raise ValueError('필수 파일 누락 또는 금지 경로')
    import io
    contents = {}
    with zipfile.ZipFile(io.BytesIO(blob)) as package:
        if len(package.infolist()) > 2000 or sum(i.file_size for i in package.infolist()) > MAX_EXPANDED:
            raise ValueError('압축 해제 크기 제한 초과')
        for info in package.infolist():
            if info.is_dir():
                continue
            if not info.filename.startswith('swing-lab-v3/'):
                raise ValueError('패키지 경로 오류')
            name = info.filename[len('swing-lab-v3/'):]
            if name in contents or name not in expected or not managed(name):
                raise ValueError('중복·허용되지 않은 파일')
            if stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError('심볼릭 링크 패키지 차단')
            value = package.read(info)
            if hashlib.sha256(value).hexdigest() != expected[name]:
                raise ValueError('업데이트 파일 검증 실패: ' + name)
            if name.endswith('.py'):
                ast.parse(value, filename=name)
            contents[name] = value
    if contents.keys() != expected.keys():
        raise ValueError('업데이트 파일 누락')
    if contents['requirements.txt'] != (target/'requirements.txt').read_bytes():
        raise ValueError('패키지 의존성이 바뀌었습니다. 수동 업그레이드 필요')
    if json.loads(contents['BUILD_MANIFEST.json']).get('version') != manifest['version']:
        raise ValueError('패키지 버전 불일치')
    return contents


def safe_target(target, name):
    if not managed(name):
        raise ValueError('금지 경로')
    path = target/name
    for part in (path, *path.parents):
        if part == target.parent:
            break
        if part.is_symlink():
            raise ValueError('설치 경로 심볼릭 링크 차단')
    return path


def stage(target, folder, repo):
    job_path = target/'data'/'job.json'
    if job_path.exists():
        job = json.loads(job_path.read_text())
        if job.get('running'):
            write(folder/'status.json', {'state': 'busy', 'message': '수집·계산 작업 중입니다. 다음 자동 확인 때 다시 시도합니다.'})
            return 10
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('저장소는 owner/repository 형식이어야 합니다.')
    try:
        release = json.loads(download('https://api.github.com/repos/'+repo+'/releases/latest', 2*1024*1024))
    except urllib.error.HTTPError as error:
        if error.code == 404:
            write(folder/'status.json', {'state': 'no_release', 'message': '공개된 정식 릴리스가 없거나 저장소에 접근할 수 없습니다.'})
            return 10
        raise
    if release.get('draft') or release.get('prerelease'):
        raise ValueError('정식 공개 릴리스만 설치합니다.')
    assets = {a['name']: a['browser_download_url'] for a in release.get('assets', [])}
    if 'release.json' not in assets or 'swing-lab-v3-update.zip' not in assets:
        write(folder/'status.json', {'state': 'not_ready', 'message': '릴리스에 자동 업데이트 파일이 없습니다.'})
        return 10
    prefix = 'https://github.com/'+repo+'/releases/download/'
    if not all(assets[n].startswith(prefix) for n in ('release.json','swing-lab-v3-update.zip')):
        raise ValueError('설정한 저장소와 다운로드 출처가 다릅니다.')
    manifest = json.loads(download(assets['release.json'], 1024*1024))
    current = json.loads((target/'BUILD_MANIFEST.json').read_text())['version']
    if version(manifest['version']) <= version(current):
        write(folder/'status.json', {'state': 'current', 'version': current, 'message': '최신 버전입니다.'})
        return 10
    contents = verify_package(download(assets['swing-lab-v3-update.zip'], MAX_ZIP), manifest, target)
    staged = folder/'staged'
    if staged.exists():
        shutil.rmtree(staged)
    staged.mkdir()
    for name, value in contents.items():
        safe_target(target, name)
        path = staged/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    write(folder/'pending.json', manifest)
    write(folder/'status.json', {'state': 'ready', 'version': manifest['version'], 'message': '검증된 업데이트 설치 준비 완료'})
    return 0


def install(target, folder):
    manifest = json.loads((folder/'pending.json').read_text())
    names = list(manifest['files'])
    for name in names:
        safe_target(target, name)
        value = (folder/'staged'/name).read_bytes()
        if hashlib.sha256(value).hexdigest() != manifest['files'][name]:
            raise ValueError('설치 준비 파일 검증 실패')
    backup = folder/'backup'
    if backup.exists():
        shutil.rmtree(backup)
    backup.mkdir()
    existed = []
    for name in names:
        source = safe_target(target, name)
        if source.exists():
            destination = backup/name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            existed.append(name)
    write(folder/'rollback.json', {'names': names, 'existed': existed})
    try:
        for name in names:
            path = safe_target(target, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
            with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
                stream.write((folder/'staged'/name).read_bytes())
                temporary = Path(stream.name)
            temporary.chmod(mode)
            os.replace(temporary, path)
    except Exception:
        rollback(target, folder)
        raise
    write(folder/'status.json', {'state': 'installed', 'version': manifest['version'], 'message': '설치 완료 · 서버 시작 확인 중'})


def rollback(target, folder):
    record = json.loads((folder/'rollback.json').read_text())
    for name in record['names']:
        path = safe_target(target, name)
        if name in record['existed']:
            shutil.copy2(folder/'backup'/name, path)
        elif path.exists():
            path.unlink()
    write(folder/'status.json', {'state': 'rolled_back', 'message': '업데이트 실패 · 이전 코드로 복구했습니다.'})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('stage', 'install', 'rollback', 'complete'))
    parser.add_argument('--target', required=True)
    parser.add_argument('--state', required=True)
    parser.add_argument('--repo', default='dmc0306/gpt-swing-radar')
    args = parser.parse_args()
    if os.geteuid() == 0:
        raise ValueError('앱 사용자로 실행해야 합니다.')
    target, folder = Path(args.target).resolve(), Path(args.state).resolve()
    if folder == target or target in folder.parents:
        raise ValueError('업데이트 작업 폴더는 앱 폴더 밖이어야 합니다.')
    folder.mkdir(parents=True, exist_ok=True)
    with (folder/'update.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            if args.action == 'stage':
                return stage(target, folder, args.repo)
            if args.action == 'install':
                install(target, folder)
            elif args.action == 'rollback':
                rollback(target, folder)
            else:
                status = json.loads((folder/'status.json').read_text())
                status.update(state='updated', message='자동 업데이트 완료')
                write(folder/'status.json', status)
        except Exception as error:
            write(folder/'status.json', {'state': 'error', 'message': str(error)[:300]})
            raise
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
