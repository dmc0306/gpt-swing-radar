"""Two independent virtual books, shared immutable input, atomic daily commit."""
import copy, json, math, secrets, threading
from collections import defaultdict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import price_store
import engine, store, alerts, membership, comparison, quality, session_calendar, eligibility
PATH=store.ROOT/'paper.json'
GROUP=store.ROOT/'paper_group.json'
LOCK=threading.RLock()
def _read(path):return json.loads(path.read_text()) if path.exists() else None
def get():return _read(GROUP) or _read(PATH)
def archive(s):store.write(store.ROOT/'paper_archive'/(s['id']+'.json'),s)
def evidence_path(g,day):return store.ROOT/'paper_shared_evidence'/(g['id']+'-'+day+'.json')
def _save(g):
    store.write(GROUP,g)  # Authoritative atomic commit for BOTH books.
    archive(g)
def _price_digest(rows):
    return store.digest([[r[k] for k in ('date','open','high','low','close','volume')] for r in rows])
def _anchor(rows,through):
    if isinstance(rows,price_store.Dataset):
        anchors=[]
        for code,rs in rows.items():
            recent=[r for r in rs if r['date']<=through][-125:]
            if recent:anchors.append({'code':code,'start':recent[0]['date'],'end':recent[-1]['date'],'count':len(recent),'hash':_price_digest(recent)})
        return anchors
    by=defaultdict(list)
    for r in rows:
        if r['date']<=through:by[r['code']].append(r)
    anchors=[]
    for c in sorted(by):
        recent=sorted(by[c],key=lambda x:x['date'])[-125:]
        anchors.append({'code':c,'start':recent[0]['date'],'end':recent[-1]['date'],'count':len(recent),'hash':_price_digest(recent)})
    return anchors

def start(run_id):raise ValueError('조건 비교에서 서로 다른 두 조건을 선택하세요. 기존 실험/계좌는 보존됩니다.')
def start_pair(comparison_id,variant_ids):
    with LOCK:
        if not isinstance(variant_ids,list) or len(variant_ids)!=2 or len(set(variant_ids))!=2:raise ValueError('서로 다른 조건 두 개를 선택하세요.')
        previous=get()
        if previous and previous.get('active'):
            if previous.get('schema')==2 or previous.get('code_hash')==store.code_hash():raise ValueError('진행 중인 계좌를 먼저 종료하세요.')
            archive(previous)
        r=comparison.get(comparison_id)
        if r['code_hash']!=store.code_hash():raise ValueError('계산 코드가 바뀌었습니다. 조건 비교를 다시 계산하세요.')
        variants={x['id']:x for x in r['variants']}
        if any(x not in variants for x in variant_ids):raise ValueError('비교에 없는 조건입니다.')
        rows=price_store.Dataset(r['dataset_id']);cfg=engine.config(r['config']);started=store.now();day=started[:10]
        g={'schema':2,'id':secrets.token_hex(12),'active':True,'started':started,'observation_start':day,
           'comparison_id':r['id'],'source_dataset_id':r['dataset_id'],'dataset_id':r['dataset_id'],
           'code_hash':store.code_hash(),'config':cfg,'membership_id':r.get('membership_id'),
           'codes':rows.codes(),'last_date':day,'accounts':[],
           'exclusion_policy':'strict_v36','snapshots':[],'warnings':[],'blocked':None,'calendar_note':session_calendar.get()['source']}
        for i,key in enumerate(variant_ids):
            x=variants[key];b=engine.fresh(cfg);b['last_date']=day
            g['accounts'].append({'id':secrets.token_hex(12),'label':chr(65+i),'name':x['name'],'active':True,
                'variant_id':key,'spec':copy.deepcopy(x['spec']),'config':copy.deepcopy(cfg),'started':started,
                'eligible_at_start':x['eligible'],'ineligible_reasons':x['ineligible_reasons'],
                'book':b,'snapshots':[],'warnings':[],'blocked':None})
        store.write(evidence_path(g,'start'),{'day':day,'anchors':_anchor(rows,day),'dataset_id':r['dataset_id']})
        g['anchor_file']='start';_save(g);return view()
def stop(account_id=None):
    with LOCK:
        g=get()
        if not g:return None
        if g.get('schema')!=2:
            g.update(active=False,stopped=store.now());store.write(PATH,g);archive(g);return view()
        found=False
        for a in g['accounts']:
            if account_id is None or a['id']==account_id:
                a.update(active=False,stopped=store.now(),status='관찰 종료 · 잔여 보유는 강제청산하지 않음');found=True
        if not found:raise ValueError('해당 계좌가 없습니다.')
        g['active']=any(a['active'] for a in g['accounts'])
        if not g['active']:g['stopped']=store.now()
        _save(g);return view()
def block(reason,missing=None,day=None):
    with LOCK:
        g=get()
        if not g or g.get('schema')!=2:return
        d={'reason':reason,'date':day,'missing_codes':missing or [],'observed_at':store.now()};g['blocked']=d
        for a in g['accounts']:
            if a['active']:a['blocked']=copy.deepcopy(d)
        _save(g)
        alerts.add([g['id'],day,reason,missing],'data','두 모의계좌 정산 보류',reason+(' · '+', '.join((missing or [])[:10]) if missing else ''))
def _basis_change(g,rows):
    anchor=_read(evidence_path(g,g['anchor_file']))
    if not anchor:return '이전 확정 가격 증거가 없습니다.'
    if g['snapshots'] and store.digest(anchor)!=g['snapshots'][-1]['hash']:return '이전 확정 증거의 해시가 달라졌습니다.'
    by=rows if isinstance(rows,price_store.Dataset) else defaultdict(list)
    if not isinstance(rows,price_store.Dataset):
        for row in rows:by[row['code']].append(row)
    for old in anchor['anchors']:
        current=sorted((r for r in by[old['code']] if old['start']<=r['date']<=old['end']),key=lambda x:x['date'])
        if len(current)!=old['count']:return old['code']+' 이전 신호 계산용 이력 누락'
        if _price_digest(current)!=old['hash']:return old['code']+' 가격/거래량 기준 변경: 수정주가·기업행사 또는 자료 정정 확인 필요'
    return None

def update(dataset_id):
    with LOCK:
        g=get()
        if not g or not g.get('active'):raise ValueError('진행 중인 모의계좌가 없습니다.')
        if g.get('schema')!=2:raise ValueError('이전 코드 계좌는 보존·열람만 가능합니다. 두 계좌 비교를 새로 시작하세요.')
        if g['code_hash']!=store.code_hash():raise ValueError('계산 코드가 바뀌어 고정 계좌 갱신을 중단합니다.')
        q=quality.get(dataset_id)
        if q.get('errors') or q.get('absent'):
            block('수집 실패 또는 누락 종목으로 일별 정산을 확정하지 않았습니다.',q.get('absent'));return view()
        rows=price_store.Subset(dataset_id,g['codes'])
        changed=_basis_change(g,rows)
        if changed:block(changed);return view()
        now=datetime.now(ZoneInfo('Asia/Seoul'));today=now.date().isoformat()
        through=(now.date() if now.hour*60+now.minute>=940 else now.date()-timedelta(days=1)).isoformat()
        prepared=price_store.prepared_since(dataset_id,g['config'],g['last_date'],g['codes'],through)
        if not prepared['dates']:
            for day,status in session_calendar.decisions(g['last_date'],through,set()):
                if status!='closed':block('필요한 확정 일봉 또는 거래일 달력이 없어 정산을 보류했습니다.',day=day);break
            return view()
        member=membership.apply(prepared,g.get('membership_id'))
        if member.get('missing_codes'):block('과거 구성종목 자료 누락',member['missing_codes']);return view()
        eligibility.Gate(live=True,days=prepared['dates']).apply(prepared,now.isoformat(timespec='seconds'))
        g['warnings']=[eligibility.NOTE];g['blocked']=None
        for a in g['accounts']:
            if a['active']:a['warnings']=[];a['blocked']=None
        advanced=False
        for day,status in session_calendar.decisions(g['last_date'],through,set(prepared['dates'])):
            if status=='closed':continue
            if status!='open':
                _save(g)
                block('전체 일봉이 없거나 휴장 여부가 미확인입니다. 일봉 또는 date,is_open 달력 CSV가 필요합니다.' if status in ('missing','unknown') else '휴장일 CSV와 일봉 날짜가 충돌합니다.',day=day)
                return view()
            bars=prepared['bars'][day];missing=sorted(set(g['codes'])-set(bars))
            if missing:
                _save(g);block('고정 관찰 종목의 일봉이 불완전하여 두 계좌 모두 날짜를 진행하지 않았습니다.',missing,day);return view()
            dynamic_required={p['code'] for a in g['accounts'] if a['active'] and a['spec'].get('exit_policy') in engine.DYNAMIC_EXITS for p in a['book']['positions']+a['book']['pending']}
            invalid_atr=sorted(c for c in dynamic_required if not isinstance(bars[c].get('atr14'),(int,float)) or not math.isfinite(bars[c]['atr14']) or bars[c]['atr14']<0)
            if invalid_atr:
                _save(g);block('추적 청산용 ATR14 이력이 불완전하여 일별 증거와 정산을 확정하지 않았습니다.',invalid_atr,day);return view()
            path=evidence_path(g,day);e=_read(path)
            if e is None:
                signals={a['id']:engine.select_signals(prepared,day,a['spec']) if day==today else [] for a in g['accounts'] if a['active']}
                e={'day':day,'captured':store.now(),'dataset_id':dataset_id,'code_hash':g['code_hash'],
                   'bars':bars,'signals':signals,'anchors':_anchor(rows,day),
                   'account_specs':{a['id']:a['spec'] for a in g['accounts'] if a['active']},'config':g['config'],
                   'exclusion_decisions':prepared['eligibility'][day],
                   'signal_mode':'observed_today' if day==today else 'missed_no_new_signals'}
                store.write(path,e)  # Only complete evidence. Never overwrite it on retry.
            ids={a['id'] for a in g['accounts'] if a['active']}
            if e.get('code_hash')!=g['code_hash'] or not ids<=set(e.get('signals',{})) or set(g['codes'])-set(e['bars']):raise ValueError('일별 증거가 계좌와 불일치합니다. 덮어쓰지 않고 중단합니다.')
            if any(e['account_specs'].get(a['id'])!=a['spec'] for a in g['accounts'] if a['active']) or e['config']!=g['config']:raise ValueError('증거의 고정 조건/원금/비용 불일치')
            next_group=copy.deepcopy(g);snap={'date':day,'hash':store.digest(e),'dataset_id':e['dataset_id']}
            for a in next_group['accounts']:
                if not a['active']:continue
                if e['signal_mode']=='missed_no_new_signals':a['warnings'].append(day+' 누락일 정산 · 신규 신호 소급 생성 안 함')
                rejected=sum(not d['allowed'] for d in e['exclusion_decisions'].values())
                if rejected:a['warnings'].append(day+f' 제외/미확인 {rejected}종목: 신규 매수 제한')
                engine.advance(a['book'],day,e['bars'],e['signals'][a['id']],a['spec'],a['config'])
                a['snapshots'].append(snap);a['updated']=store.now();a['blocked']=None
            next_group.update(last_date=day,dataset_id=e['dataset_id'],anchor_file=day,updated=store.now(),blocked=None)
            next_group['snapshots'].append(snap);_save(next_group);g=next_group;advanced=True
            for a in g['accounts']:alerts.paper_events(a)
        if not advanced:g['warnings'].append('새로 확정한 거래일이 없습니다. 시작일 이전 신호를 소급하지 않습니다.')
        g['calendar_note']=session_calendar.get()['source'];_save(g)
        for a in g['accounts']:alerts.paper_events(a)
        return view()
def common_metrics(group):
    day=min(a['book']['last_date'] for a in group['accounts']);out=[]
    for a in group['accounts']:
        points=[p for p in a['book']['curve'] if p['date']<=day]
        # Equity at the shared cutoff already includes marked open positions.
        diagnostic=engine.fresh(a['config']);diagnostic['curve']=points
        diagnostic['trades']=[t for t in a['book']['trades'] if t['exit_date']<=day]
        diagnostic['cash']=points[-1]['equity'] if points else a['config']['capital']
        m=engine.metrics(diagnostic)
        out.append({'id':a['id'],'label':a['label'],'name':a['name'],'metrics':{k:m[k] for k in ('trades','win_rate','avg_trade_pct','total_return_pct','max_drawdown_pct','avg_eod_exposure_pct','invested_days','observed_days')}})
    return {'date':day,'accounts':out}
def view():
    s=get()
    if not s:return None
    if s.get('schema')!=2:return {**s,'legacy':True,'read_only':s.get('code_hash')!=store.code_hash(),'metrics':engine.metrics(s['book'])}
    return {**s,'accounts':[{**a,'metrics':engine.metrics(a['book'])} for a in s['accounts']],'common':common_metrics(s),
            'read_only':s.get('code_hash')!=store.code_hash(),
            'note':'같은 원금·시작일·일별 자료·비용. 현금과 보유는 독립적이며 같은 종목 중복 보유를 허용합니다. 두 계좌 수익률은 합산하지 않습니다.'}
def account(account_id):
    s=get()
    if not s:raise ValueError('계좌가 없습니다.')
    if s.get('schema')!=2:return s,s
    for a in s['accounts']:
        if a['id']==account_id:return s,a
    raise ValueError('계좌 번호가 없습니다.')
def archives():
    out=[]
    for p in (store.ROOT/'paper_archive').glob('*.json'):
        s=_read(p);out.append({k:s.get(k) for k in ('id','schema','started','stopped','active')})
    return sorted(out,key=lambda x:x.get('started') or '',reverse=True)
def archived(ident):
    if not ident or len(ident)!=24 or any(c not in '0123456789abcdef' for c in ident):raise ValueError('계좌 번호 오류')
    s=_read(store.ROOT/'paper_archive'/(ident+'.json'))
    if not s:raise ValueError('보관 기록 없음')
    return s
