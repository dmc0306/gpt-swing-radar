"""Durable job recipes: final holdout is intentionally never opened here."""
import json
import store, data_source, paper, universe, quality, alerts, eligibility

def settings():
    path=store.ROOT/'settings.json'
    return json.loads(path.read_text()) if path.exists() else {'codes':[],'years':5,'auto':False}

def collected(s,progress,retry=False):
    codes=list(s['codes']);account=paper.get()
    if account and account['active']:codes=list(dict.fromkeys(codes+account['codes']))
    u=universe.get() or {};names={x['code']:x['name'] for x in u.get('selected',[])}
    return data_source.collect(codes,s['years'],progress,names=names,retry=retry)

def candidate_alert(result,progress=lambda **kw:None):
    alerts.add(['dataset-ready',result['dataset']['id']],'data','가격 자료 준비 완료','전략5개 화면에서 조회 버튼을 누르면 최신 확정 일봉 기준 후보를 확인합니다.')


def execute(task,progress):
    kind=task['kind'];p=task.get('payload',{});checkpoint=store.ROOT/'flows'/(task['id']+'.json')
    saved=json.loads(checkpoint.read_text()) if checkpoint.exists() else {}
    if kind=='eligibility_capture':return eligibility.capture(progress)
    if kind in ('research','compare'):raise ValueError('이전 탐색 작업은 보관 후 5개 고정 전략 비교를 사용하세요.')
    if kind not in ('prepare','collect','retry','scheduled'):raise ValueError('이어받을 수 없는 작업')
    if saved and saved.get('code_hash')!=store.code_hash():raise ValueError('이전 코드의 중단 작업입니다. 기록 보관 후 자동 자료 준비를 새로 시작하세요.')
    if not saved.get('collected'):
        try:eligibility.capture(progress)
        except InterruptedError:raise
        except Exception as e:
            alerts.add([task['id'],'eligibility'],'data','제외 상태 자동 수집 실패',str(e)[:180]+' · 미확인 신규 매수는 차단합니다.')
        if kind=='prepare':
            # Once selection is complete, hold it fixed across a long-history resume.
            u=universe.get() or {}
            if u.get('flow_id')==task['id'] and u.get('selected') and u.get('code_hash')==store.code_hash():
                chosen=u['selected'];result=data_source.collect([x['code'] for x in chosen],p.get('years',5),progress,names={x['code']:x['name'] for x in chosen},note=u.get('note'))
                u.update(status='완료',dataset_id=result['dataset']['id'],history_errors=result['errors']);store.write(universe.PATH,u)
            else:
                result=universe.discover({**p,'flow_id':task['id']},p.get('years',5),progress)
                u=universe.get()
            s=settings();s.update(codes=[x['code'] for x in u['selected']],years=p.get('years',5),auto=bool(p.get('auto',True)));store.write(store.ROOT/'settings.json',s)
        elif kind=='retry':result=collected({'codes':p['codes'],'years':p['years']},progress,retry=p)
        else:result=collected(p or settings(),progress)
        saved={'collected':result,'code_hash':store.code_hash()};store.write(checkpoint,saved)
        progress(stage='자료 준비 완료 안내',done=1,total=1)
        candidate_alert(result,progress)
    result=dict(saved['collected'])
    if kind in ('scheduled','retry','collect'):
        account=paper.get()
        if account and account['active']:
            q=quality.get(result['dataset']['id'])
            if result.get('errors') or q.get('absent'):
                paper.block('일부 수집 실패로 두 계좌 정산을 보류했습니다.',q.get('absent'))
                result['warning']='자료 수집 미완료 · 모의 정산 보류. 실패 종목 재시도 후 갱신하세요.'
            elif account.get('schema')!=2 or account.get('code_hash')!=store.code_hash():
                result['warning']='이전 계산 코드의 모의계좌는 보존됩니다. 조건 비교에서 두 계좌를 새로 시작하세요.'
            else:
                value=paper.update(result['dataset']['id'])
                if value and value.get('blocked'):result['warning']=value['blocked']['reason']
    return result
