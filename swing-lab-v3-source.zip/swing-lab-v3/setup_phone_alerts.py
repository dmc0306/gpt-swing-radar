"""Run locally on your server; never paste the bot token into a chat."""
import getpass,json,os,re,secrets,tempfile
from pathlib import Path
import httpx

def main():
    print('텔레그램 @BotFather → /newbot 으로 봇을 만든 뒤, 본인 개인 채팅에서 봇에게 /start를 보내세요.')
    token=getpass.getpass('봇 토큰 (화면에 표시하지 않음): ').strip()
    if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]+',token):raise ValueError('토큰 형식을 확인하세요.')
    code='swing-'+secrets.token_hex(4)
    print('지금 본인의 봇 개인 채팅에 아래 문장을 보내세요. 이 확인문과 일치하는 본인 채팅만 연결합니다.')
    print(code);input('전송했으면 Enter: ')
    r=httpx.post('https://api.telegram.org/bot'+token+'/getUpdates',json={'timeout':0,'limit':100,'allowed_updates':['message']},timeout=15,follow_redirects=False)
    value=r.json()
    if not r.is_success or not value.get('ok'):raise ValueError('봇 메시지를 읽지 못했습니다. 토큰·다른 봇 서비스의 사용 여부를 확인하세요.')
    matches={x['message']['chat']['id']:x['message']['chat'] for x in value['result'] if x.get('message',{}).get('text')==code and x['message']['chat'].get('type')=='private'}
    if len(matches)!=1:raise ValueError('본인 개인 채팅의 확인문 1건이 필요합니다. 다시 실행하세요.')
    chat=next(iter(matches.values()))
    print('연결 대상: '+str(chat.get('first_name',''))+' '+str(chat.get('last_name',''))+' / @'+str(chat.get('username','없음')))
    if input('본인 계정이 맞으면 YES 입력: ').strip()!='YES':print('저장 취소');return
    folder=Path.home()/'.config/swing-lab-v3';folder.mkdir(parents=True,exist_ok=True);os.chmod(folder,0o700)
    with tempfile.NamedTemporaryFile('w',dir=folder,delete=False) as f:
        os.chmod(f.name,0o600);json.dump({'token':token,'chat_id':str(chat['id']),'private_verified':True},f);f.flush();os.fsync(f.fileno());temp=f.name
    os.replace(temp,folder/'telegram.json')
    print('연결 정보를 저장했습니다. 앱 후보 → 휴대폰 계획 알림에서 켜고, 시험 알림을 눌러 수신을 확인하세요.')

if __name__=='__main__':
    try:main()
    except (ValueError,KeyboardInterrupt) as e:print(str(e) or '취소')
    except Exception as e:print(type(e).__name__+' · 연결 실패. 토큰은 출력하지 않습니다.')
