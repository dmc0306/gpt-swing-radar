"""Finite rolling indicators: at most 120 bars inside six calendar months."""
import math
import pandas as pd
FEATURES=['ret5','ret20','ret60','ret119','rsi','atr_pct','adx','vol_ratio','vol3_ratio','bb_width','bb_rank','ma20_gap','ma60_gap','ma120_gap','high20_gap','ret1']
def extract(rows,days,entry_day):
    if len(rows)<120:return None,'120개 확정 가격 이력 부족'
    rows=sorted(rows,key=lambda r:r['date'])[-120:]
    if rows[0]['date']<(pd.Timestamp(entry_day)-pd.DateOffset(months=6)).date().isoformat():return None,'120개 가격이 최대6개월 범위 밖까지 필요함'
    if set(r['date'] for r in rows)!=set(days[-120:]):return None,'최근120개 관측일 중 가격 누락'
    if any(r['volume']<=0 or min(r['open'],r['low'],r['close'])<=0 or r['high']<max(r['open'],r['close']) or r['low']>min(r['open'],r['close']) for r in rows):return None,'거래량 또는 가격 봉이 불완전함'
    d=pd.DataFrame(rows);c=d.close;v=d.volume;h=d.high;l=d.low;p=c.shift(1)
    m20=c.rolling(20).mean();m60=c.rolling(60).mean();m120=c.rolling(120).mean()
    delta=c.diff();gain=delta.clip(lower=0).rolling(14).mean();loss=(-delta.clip(upper=0)).rolling(14).mean()
    rsi=(100*gain/(gain+loss)).where((gain+loss)>0,50)
    tr=pd.concat([h-l,(h-p).abs(),(l-p).abs()],axis=1).max(axis=1);atr=tr.rolling(14).mean()
    up=h.diff();down=-l.diff();plus=up.where((up>down)&(up>0),0).rolling(14).mean();minus=down.where((down>up)&(down>0),0).rolling(14).mean()
    adx=(100*(plus-minus).abs()/(plus+minus)).where((plus+minus)>0,0).rolling(14).mean()
    width=400*c.rolling(20).std(ddof=0)/m20;rank=width.rolling(61).apply(lambda x:100*(x[:-1]<=x[-1]).mean(),raw=True)
    high20=h.rolling(20).max().shift(1)
    features={'ret5':100*(c/c.shift(5)-1),'ret20':100*(c/c.shift(20)-1),'ret60':100*(c/c.shift(60)-1),'ret119':100*(c/c.shift(119)-1),'rsi':rsi,'atr_pct':100*atr/c,'adx':adx,'vol_ratio':v/v.rolling(20).mean().shift(1),'vol3_ratio':v.rolling(3).mean()/v.rolling(20).mean().shift(3),'bb_width':width,'bb_rank':rank,'ma20_gap':100*(c/m20-1),'ma60_gap':100*(c/m60-1),'ma120_gap':100*(c/m120-1),'high20_gap':100*(c/high20-1),'ret1':100*(c/p-1)}
    out={k:float(features[k].iloc[-1]) for k in FEATURES}
    if not all(math.isfinite(x) for x in out.values()):return None,'지표 계산 이력 부족'
    r=rows[-1]
    return {'code':r['code'],'name':r['name'],'date':r['date'],'close':r['close'],'atr':float(atr.iloc[-1]),'turnover':float((c*v).rolling(20).mean().iloc[-1]),'volume_limit':float(v.rolling(20).mean().shift(1).iloc[-1]),'lookback_start':rows[0]['date'],'features':out},None
