"""User-requested data research. Fixed hypotheses; no application/test/server execution."""
import os,sys,json,sqlite3,time,hashlib
from pathlib import Path
from collections import Counter,defaultdict
BASE=Path(__file__).resolve().parent
APP=BASE/'source'
os.environ['SWING_DATA_DIR']=str(BASE.parent/'analysis-1662/data')
sys.path.insert(0,str(APP))
import engine,store
class PriceDataset:
 def __init__(self,ident):
  self.path=store.ROOT/'price_indexes'/(ident+'.sqlite')
  if not self.path.exists():raise FileNotFoundError('분석용 가격 색인이 없습니다: '+str(self.path))
 def query(self,sql,args=()):
  c=sqlite3.connect('file:'+str(self.path)+'?mode=ro',uri=True)
  try:return list(c.execute(sql,args))
  finally:c.close()
 def codes(self):return [r[0] for r in self.query('SELECT DISTINCT code FROM bars ORDER BY code')]
 def symbol(self,code):return [json.loads(r[0]) for r in self.query('SELECT payload FROM bars WHERE code=? ORDER BY date',(code,))]
plan=json.loads((BASE/'protocol.json').read_text())
original=json.loads((store.ROOT/'comparisons/55dde1a1d8b29927894f766f.json').read_text())
DEFS=plan['hypotheses']
baseline_record=json.loads((BASE.parent/'analysis-10/comparison.json').read_text())
baselines={v['id']:v for v in baseline_record['variants']}
cfg=engine.config({**original['config'],'max_positions':10})
stress={**cfg,'fee_pct':2*cfg['fee_pct'],'slippage_pct':2*cfg['slippage_pct']}
dates=[p['date'] for p in original['variants'][0]['result']['curve']]
source=store.ROOT/'research_cache/75b20475a62f55b09b3eb70894c0eeefc57e0033394253310d8235068b684ebd.sqlite'
con=sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True)
new=sqlite3.connect(BASE/'signals.sqlite')
new.executescript('CREATE TABLE IF NOT EXISTS signals(day TEXT,kind TEXT,code TEXT,payload TEXT,PRIMARY KEY(day,kind,code)); CREATE TABLE IF NOT EXISTS done(code TEXT PRIMARY KEY);')
completed={r[0] for r in new.execute('SELECT code FROM done')}
new.close()
ds=PriceDataset(plan['dataset_id']);codes=ds.codes();last=0
for i,code in enumerate(codes):
 if code in completed:continue
 p=engine.prepare(ds.symbol(code),cfg)
 new=sqlite3.connect(BASE/'signals.sqlite')
 with new:
  for kind in ['early_recovery','mild_recovery','focus_volume_free']:
   for day,signals in p['signals'][kind].items():
    if dates[0]<=day<=dates[-1]:
     for s in signals:new.execute('INSERT OR REPLACE INTO signals VALUES(?,?,?,?)',(day,kind,code,store.encode(s).decode()))
  new.execute('INSERT OR REPLACE INTO done VALUES(?)',(code,))
 new.close()
 if time.monotonic()-last>25:print('새 가설 지표',i+1,'/',len(codes),flush=True);last=time.monotonic()
 del p
new=sqlite3.connect('file:'+str(BASE/'signals.sqlite')+'?mode=ro',uri=True)
segments=[{'id':'full','start':dates[0],'end':dates[-1]}]+[{'id':'q'+str(i+1),'start':dates[i*63],'end':dates[(i+1)*63-1]} for i in range(4)]
books={(seg['id'],s['id'],cost):engine.fresh(c) for seg in segments for s in DEFS for cost,c in [('base',cfg),('stress',stress)]}
breadth={day:(n,u) for day,n,u in con.execute('SELECT day,count(*),sum(up) FROM breadth GROUP BY day')}
count=defaultdict(Counter);monthly=defaultdict(Counter);latest={}
for i,day in enumerate(dates):
 bars={code:json.loads(raw) for code,raw in con.execute('SELECT code,payload FROM bars WHERE day=?',(day,))}
 signals={kind:{day:[]} for kind in engine.STRATEGIES};n,u=breadth.get(day,(0,0))
 raw=list(new.execute('SELECT kind,payload FROM signals WHERE day=?',(day,)))
 for kind,value in raw:
  sig=json.loads(value);sig.update(breadth_count=n,breadth_pct=100*u/n if n else 0);signals[kind][day].append(sig)
 for mapping in signals.values():mapping[day].sort(key=lambda s:(-s['score'],s['code']))
 prepared={'bars':{day:bars},'signals':signals,'dates':[day]}
 for s in DEFS:
  passed=engine.select_signals(prepared,day,s['spec']);latest[s['id']]=passed;monthly[day[:7]][s['id']]+=len(passed)
  for seg in segments:
   if not seg['start']<=day<=seg['end']:continue
   count[seg['id']][s['id']]+=len(passed)
   for cost,c in [('base',cfg),('stress',stress)]:engine.advance(books[(seg['id'],s['id'],cost)],day,bars,passed,s['spec'],c)
 if time.monotonic()-last>25:print('고정 4개 완화안 비교',i+1,'/',len(dates),flush=True);last=time.monotonic()
con.close();new.close()
variants=[]
for s in DEFS:
 b=books[('full',s['id'],'base')]
 result={'metrics':engine.metrics(b),'curve':b['curve'],'trades':b['trades'],'open':b['positions'],'pending':b['pending'],'events':b['events']}
 periods=[]
 for seg in segments[1:]:
  bb=books[(seg['id'],s['id'],'base')]
  periods.append({**seg,'signals':count[seg['id']][s['id']],'metrics':engine.metrics(bb),'stress':engine.metrics(books[(seg['id'],s['id'],'stress')])})
 v={**s,'result':result,'stress':engine.metrics(books[('full',s['id'],'stress')]),'fixed_cost':engine.fixed_cost_diagnostic(result,cfg,2),'signals':count['full'][s['id']],'periods':periods}
 m=v['result']['metrics'];recent=periods[-1]['metrics'];sr=periods[-1]['stress'];bm=baselines[s['baseline']]['result']['metrics']
 v['latest_daily_signals']=latest[s['id']];v['baseline_metrics']=bm
 v['observation_gate']={'more_trades':m['trades']>bm['trades'],'win_rate_preserved':m['win_rate'] is not None and m['win_rate']>=bm['win_rate'],'recent_sample':recent['trades']>=15,'full_net_positive':m['total_return_pct']>0 and (m['avg_trade_pct'] or 0)>0,'recent_net_positive':recent['total_return_pct']>0 and (recent['avg_trade_pct'] or 0)>0,'cost_stress_positive':v['stress']['total_return_pct']>0 and sr['total_return_pct']>0,'drawdown':m['max_drawdown_pct']>=-10 and recent['max_drawdown_pct']>=-10}
 v['observation_gate_pass']=all(v['observation_gate'].values())
 v['win80_observed']=m['trades']>0 and m['win_rate']>=80
 variants.append(v)
 print(s['id'],json.dumps({k:m[k] for k in ['trades','win_rate','total_return_pct','max_drawdown_pct','avg_trade_pct']},ensure_ascii=False),'recent',json.dumps({k:recent[k] for k in ['trades','win_rate','total_return_pct','max_drawdown_pct']},ensure_ascii=False),'gate',v['observation_gate'],flush=True)
record={'created':store.now(),'label':'10종목 한도 · 후보 확대 가설4개 재분석','protocol':plan,'dataset_id':plan['dataset_id'],'source_comparison_id':original['id'],'source_engine_sha256':hashlib.sha256((APP/'engine.py').read_bytes()).hexdigest(),'config':cfg,'start':dates[0],'end':dates[-1],'scope':original['scope'],'segments':segments,'variants':variants,'monthly_signals':dict(monthly),'breadth':[{'date':d,'count':n,'above60_pct':100*u/n if n else 0} for d,(n,u) in breadth.items()],'limitations':['기존 평가기간 및 최신63거래일 모두 이미 확인한 과거자료 재사용. 독립검증 아님.','각63거래일은 원금1000만원·빈계좌에서 시작. 구간말 미청산은 종가평가하며 승률 건수에 포함하지 않음. 구간 수익의 합은 연간계좌수익이 아님.','현재 선택1662종목 편향 및 과거 거래정지 등 제외이력 부재. 표본확산도는 시장지수가 아님.','일봉 신호 후 다음 거래일 시가 진입. 동일일 장중 순서는 손절 우선 가정. 분봉검증 없음.','거래비용 왕복0.2%,편도슬리피지0.05%. 비용2배는 재시뮬레이션이며 건수가 달라질 수 있음.','최대보유10은 강제매수나 분산보장 아님. 원금·1종목20%·거래당위험0.5%·거래량제약 그대로.','현금/미실현 포함 계좌수익과 동일가중 평균거래수익은 다른 지표.','당시 조정주가와 구성종목을 독립 자료로 대조하지 못함. 가격 갭은 실제손실이 계획손절을 넘게할 수 있음.']}
store.write(BASE/'comparison.json',record)
print('DONE',BASE/'comparison.json',flush=True)
