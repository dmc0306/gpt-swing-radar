# 후보 확대 연구 원본

실제 계산 결과는 ../reports/candidate-expansion-comparison.json, 해설은 같은 폴더의 candidate-expansion-report.html입니다.

executed_calculation.py는 이 작업 환경에서 실제 실행한 계산 원본입니다. 경로와 기존 SQLite 캐시에 의존하므로 사용자 서버에서 그대로 실행하는 명령은 아닙니다. 실제 사용한 가설은 protocol.json에 결과 확인 전 고정했고, 구현은 source/engine.py에 보관합니다. 앱이 자동으로 이 연구 전략을 불러오지 않습니다.

가격은 사용자가 제공한 swing-analysis-export (1).zip의 28510fdc10f18ae0a09859c22bea1006a2e4e0f382c41a34b23e739e59a09529 스냅샷입니다. 입력 원본을 다시 제공하면 동일 기간·비용으로 재분석할 수 있습니다. 기존 기준 전략의 동일 10종목 결과는 ../reports/ten-position-comparison.json에 있습니다.

이 ZIP에는 원본 117만 행 가격 전체와 대형 캐시를 중복 포함하지 않습니다. 기존 서버의 data/와 원본 내보내기 ZIP을 보관하세요. build_report.py도 제작 환경 경로를 기록한 원본입니다. 앱/회귀 테스트는 수행하지 않았습니다.
