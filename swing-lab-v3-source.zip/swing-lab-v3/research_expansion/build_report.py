import json,html,shutil
from pathlib import Path
base=Path(__file__).resolve().parent
app=base.parent/'v316-work';out=app/'reports'
r=json.loads((base/'comparison.json').read_text())
b=json.loads((base.parent/'analysis-10/comparison.json').read_text())
bs={v['id']:v for v in b['variants']}
def pct(v,n=2):return '—' if v is None else f'{v:+.{n}f}%'
def wr(v):return '—' if v is None else f'{v:.1f}%'
def row(v,p=None):
 m=p['metrics'] if p else v['result']['metrics'];st=p['stress'] if p else v['stress']
 return [v['name'],str(m['trades']),wr(m['win_rate']),pct(m['avg_trade_pct']),pct(m['total_return_pct']),pct(m['max_drawdown_pct']),pct(st['total_return_pct'])]
headers=['조건','완료 거래','비용 후 승률','거래 평균','계좌 수익','최대 낙폭','비용 2배 계좌 수익']
def mdtable(h,rows):return '\n'.join(['| '+' | '.join(h)+' |','| '+' | '.join(['---']*len(h))+' |']+['| '+' | '.join(map(str,x))+' |' for x in rows])
def htable(h,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in h)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in rs)+'</tr>' for rs in rows)+'</tbody></table></div>'
intro='승률을 유지하면서 후보 수·순손익·최근 표본·비용 스트레스를 함께 통과한 완화안은 없었습니다. 새 전략은 실전·모의계좌에 추가하지 않았습니다. 기존 5개 규칙을 한 번에 검색하는 기능과 현재 가격 점검을 추가했습니다.'
context='자료 1,662종목, 전체 2025-09-15~2026-09-29(252거래일), 최근 2026-06-29~2026-09-29(63거래일). 원금 각 1,000만원, 최대 동시보유 10종목, 한 종목 금액 20%, 위험 예산 0.5%, 왕복 비용 0.2%, 편도 슬리피지 0.05%, 주가 1,000원 이상, 20일 평균 거래대금 10억원 이상. 진입은 신호 다음 거래일 시가입니다. 구간별 계좌는 독립적으로 초기화합니다.'
allv=[bs['focused'],bs['risk']]+r['variants']
full=[row(v) for v in allv];recent=[row(v,v['periods'][-1]) for v in allv]
fixed=[[v['name'],str(v['fixed_cost']['trades']),wr(v['fixed_cost']['win_rate']),pct(v['fixed_cost']['avg_trade_pct']),str(v['stress']['trades']),pct(v['stress']['total_return_pct'])] for v in allv]
conclusion='반등 첫날 확인 0.40R은 최근 36거래에서 승률 83.3%, 계좌 수익 +1.63%였지만, 전체 437거래에서는 승률 68.2%, 수익 −16.26%, 낙폭 −17.29%였습니다. 최근 구간만 골라 채택할 근거가 아닙니다. 거래량 조건 해제는 기존 방법 1보다 승률이 69.8%→71.4%, 거래 수가 106→185건으로 늘었지만 전체 수익 −2.38%, 비용 2배 −6.97%, 최근 표본 4건이라 보류했습니다.'
changes=['5개 방법을 한 번에 계산하고 같은 종목은 하나로 묶습니다. 통합 목록 자체의 별도 승률은 계산하지 않았습니다.','기존 일봉 진입 조건은 유지합니다. 부족한 조건 1~2개인 종목을 대기 목록에서 볼 수 있고 20개씩 더 펼칠 수 있습니다. 대기 종목은 매수 신호·계좌·알림에 넣지 않습니다.','조회 시 오늘 제외 상태를 새로 확인할 수 있습니다. 가격·제외 자료를 모르면 후보를 보류하고 이유를 표시합니다.','후보별 현재가 버튼으로 키움 읽기 전용 현재가를 받아 수량·목표가·손절가를 다시 계산합니다. 응답 수신 시각은 체결 시각이 아니며 호가·잔량·체결 가능성은 확인되지 않습니다.','다음 거래일 시가 진입의 과거 결과를 장중 진입의 성과로 전용하지 않습니다. 현재가 가격 조건 통과와 매수 허용은 구분합니다.','지표 계산은 종목별 한 번씩 처리하고 디스크 캐시를 재사용합니다. 진행 중 작업과 겹치지 않게 서버 작업으로 실행하며 조회·현재가 기록을 내보내기에 포함합니다.','엔진·고정 전략·계좌의 해시와 기존 데이터를 유지합니다. 기존 계좌 조건 변경, 지난 날짜 매수 추가, 서버 자동 배포는 하지 않았습니다.']
limits=r['limitations']+['자료 수집 대상을 고를 때 사용한 거래대금 기준과 이 비교의 거래대금 기준은 다를 수 있습니다. 비교는 저장된 1,662종목에 10억원 기준을 동일 적용했습니다.','2026-09-29 확정 일봉에서 기존 5개 방법의 신호는 0개였습니다. 완화안 일부의 신호가 나왔다는 이유만으로 손실 전략을 채택하지 않았습니다. 오늘 실행 시에는 설치 서버의 선택 데이터와 시각으로 새로 계산합니다.','기존 5개도 앞으로 승률을 유지한다고 입증된 것은 아닙니다. 설정을 바꾸지 않았다는 뜻과 성과를 보장한다는 뜻은 다릅니다.','이 보고서는 프로그램의 전략 계산을 수행한 기록입니다. 신규 조회 UI·API·설치·브라우저·구문·회귀 테스트 및 앱 실행은 사용자 요청에 따라 생략했습니다.']
fields='장중 진입을 직접 비교하려면 동일 1,662종목과 해당 시장 지수의 1분 또는 5분 OHLCV가 필요합니다. 공통 권장 기간은 현재 비교와 같은 2025-09-15~2026-09-29, 전 종목 공통 필드는 code,timestamp(+09:00),open,high,low,close,volume,turnover,bar_complete,adjustment_basis,source입니다. 체결 비용을 더 현실적으로 평가하려면 bid,ask,bid_size,ask_size와 그 관측 시각, 날짜별 거래정지·주의·경고 등 제외 상태, 수정주가/기업행사 이력도 필요합니다. 없는 기간은 공통으로 확보된 구간만 비교하고 성과를 일반화하지 않습니다.'
md=['# 후보 확대 4가설 비교 · v3.16.0',intro,context,'## 전체 기간',mdtable(headers,full),'## 최근 63거래일 · 새 빈 계좌',mdtable(headers,recent),conclusion,'## 미리 고정한 조건과 채택 기준']
ht=['<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>후보 확대 비교</title><style>body{font:16px/1.7 system-ui;margin:0;background:#f4f6f3;color:#18282c}main{max-width:1100px;margin:auto;padding:24px}section{background:white;padding:22px;border-radius:16px;margin:18px 0;border:1px solid #dbe2df}.lead{background:#e6f2ed}.scroll{overflow:auto}table{border-collapse:collapse;min-width:820px;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #dbe2df}th{color:#526467}h1{line-height:1.3;font-size:28px}a{color:#146d61}details{margin:14px 0}summary{font-weight:bold;cursor:pointer}@media(max-width:600px){main{padding:12px}section{padding:16px}}</style><main><h1>후보를 늘리면 승률도 유지될까요?</h1><section class="lead"><b>'+html.escape(intro)+'</b><p>'+html.escape(context)+'</p></section><section><h2>전체 252거래일</h2>'+htable(headers,full)+'</section><section><h2>최근 63거래일 · 새 빈 계좌</h2>'+htable(headers,recent)+'<p>'+html.escape(conclusion)+'</p></section><section><h2>미리 고정한 조건</h2>']
for v in r['variants']:
 text=v['name']+': '+v['reason'];md.append('- '+text);ht.append('<p>'+html.escape(text)+'</p>')
md.append(r['protocol']['acceptance']);ht.append('<p>'+html.escape(r['protocol']['acceptance'])+'</p></section>')
md.extend(['## 같은 거래의 비용 진단과 다시 계산한 결과',mdtable(['조건','고정 거래 수','고정 비용 승률','고정 비용 평균','재계산 거래 수','재계산 계좌 수익'],fixed),'왼쪽 고정 비용 진단은 원래 거래를 유지하고 비용만 2배로 늘립니다. 오른쪽은 실제 수량·현금·진입 기회를 다시 계산한 재시뮬레이션이므로 거래 수가 바뀔 수 있습니다.'])
ht.append('<section><details><summary>비용 2배: 거래를 고정한 진단과 재시뮬레이션</summary>'+htable(['조건','고정 거래 수','고정 비용 승률','고정 비용 평균','재계산 거래 수','재계산 계좌 수익'],fixed)+'<p>고정 진단은 원래 거래와 수량을 유지합니다. 재시뮬레이션은 현금·수량·진입을 다시 계산하므로 거래 수가 달라질 수 있습니다.</p></details></section>')
md.append('## 시간 순서 비교');ht.append('<section><h2>시간 순서로 나눈 4구간</h2><p>각 구간은 빈 계좌로 시작합니다. 구간말 미청산은 종가 평가하며 완료 거래 승률에 포함하지 않습니다.</p>')
for i,seg in enumerate(r['segments'][1:]):
 title=seg['start']+'~'+seg['end'];rr=[row(v,v['periods'][i]) for v in allv]
 md.extend(['### '+title,mdtable(headers,rr)]);ht.append('<details><summary>'+title+'</summary>'+htable(headers,rr)+'</details>')
ht.append('</section>')
for title,items in [('앱 변경점',changes),('해석의 한계와 수행 범위',limits)]:
 md.extend(['## '+title,*['- '+x for x in items]]);ht.append('<section><h2>'+title+'</h2><ul>'+''.join('<li>'+html.escape(x)+'</li>' for x in items)+'</ul></section>')
md.extend(['## 다음 분석에 필요한 자료',fields,'## 현재가 API 근거','키움 공식 예제: https://github.com/Kiwoom-Securities/Kiwoom-REST-API/blob/main/examples/국내주식/종목정보/get_domestic_stock_info.py','ka10001 /api/dostk/stkinfo, stk_cd 요청, cur_prc 및 base_pric 응답. 2026-09-30 공식 문서 확인. 현재가 시각·매수호가·잔량을 이 API에서 추측하지 않습니다.'])
ht.append('<section><h2>다음 분석에 필요한 자료</h2><p>'+html.escape(fields)+'</p><p><a href="https://github.com/Kiwoom-Securities/Kiwoom-REST-API/blob/main/examples/%EA%B5%AD%EB%82%B4%EC%A3%BC%EC%8B%9D/%EC%A2%85%EB%AA%A9%EC%A0%95%EB%B3%B4/get_domestic_stock_info.py">키움 현재가 조회 공식 예제</a> · 2026-09-30 확인. 거래 주문 API는 사용하지 않습니다.</p></section></main></html>')
(out/'candidate-expansion-report.md').write_text('\n\n'.join(md))
(out/'candidate-expansion-report.html').write_text(''.join(ht))
(out/'candidate-expansion-comparison.json').write_bytes((base/'comparison.json').read_bytes())
(out/'candidate-expansion-protocol.json').write_bytes((base/'protocol.json').read_bytes())
research=app/'research_expansion';(research/'source').mkdir(parents=True,exist_ok=True)
for n in ('engine.py','store.py','focus_indicators.py','price_store.py'):(research/'source'/n).write_bytes((base/'source'/n).read_bytes())
(research/'executed_calculation.py').write_bytes((base/'calculate.py').read_bytes())
(research/'build_report.py').write_bytes((base/'build_report.py').read_bytes())
(research/'protocol.json').write_bytes((base/'protocol.json').read_bytes())
(research/'README.md').write_text('''# 후보 확대 연구 원본

실제 계산 결과는 ../reports/candidate-expansion-comparison.json, 해설은 같은 폴더의 candidate-expansion-report.html입니다.

executed_calculation.py는 이 작업 환경에서 실제 실행한 계산 원본입니다. 경로와 기존 SQLite 캐시에 의존하므로 사용자 서버에서 그대로 실행하는 명령은 아닙니다. 실제 사용한 가설은 protocol.json에 결과 확인 전 고정했고, 구현은 source/engine.py에 보관합니다. 앱이 자동으로 이 연구 전략을 불러오지 않습니다.

가격은 사용자가 제공한 swing-analysis-export (1).zip의 28510fdc10f18ae0a09859c22bea1006a2e4e0f382c41a34b23e739e59a09529 스냅샷입니다. 입력 원본을 다시 제공하면 동일 기간·비용으로 재분석할 수 있습니다. 기존 기준 전략의 동일 10종목 결과는 ../reports/ten-position-comparison.json에 있습니다.

이 ZIP에는 원본 117만 행 가격 전체와 대형 캐시를 중복 포함하지 않습니다. 기존 서버의 data/와 원본 내보내기 ZIP을 보관하세요. build_report.py도 제작 환경 경로를 기록한 원본입니다. 앱/회귀 테스트는 수행하지 않았습니다.
''')
print('reports and research saved')
