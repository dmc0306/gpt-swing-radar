# v3.20.2

/assets/{name} 제공 목록에 modern-ui.css와 ui-shell.js를 등록했습니다. 새 금융 UI와 공통 설정 연동 스크립트가 404로 차단되던 문제를 수정했습니다.

HTML에서 참조하는 모든 로컬 CSS·JavaScript의 HTTP 응답을 검증하며, 미등록 파일과 경로 탐색은 계속 차단합니다.
