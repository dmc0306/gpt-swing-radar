"""Point-in-time buy eligibility. Unknown is never a live permission to buy."""
import csv, io, json, re, time
import ijson
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import store

TZ=ZoneInfo('Asia/Seoul')
FLAGS={'halt':'거래정지','management':'관리종목','spac':'스팩','preferred':'우선주',
       'liquidation':'정리매매','warning':'투자경고','risk':'투자위험','caution':'투자주의',
       'hwangi':'환기종목','etf':'ETF','etn':'ETN','reit':'리츠(기존 제외 유지)'}
FIELDS=['date','code','known_at','source',*FLAGS]
ROOT=store.ROOT/'eligibility'
NOTE='확인된 제외 대상과 상태 미확인 종목은 신규 매수 금지. 기존 보유는 삭제하거나 강제청산하지 않습니다.'

def instant(value):
    dt=datetime.fromisoformat(value)
    if dt.tzinfo is None:raise ValueError('known_at에 +09:00 등 시간대를 포함하세요.')
    return dt.astimezone(TZ)

def load(ident):
    store.check_id(ident)
    p=ROOT/'imports'/(ident+'.json')
    if not p.exists():raise ValueError('제외 이력 자료가 없습니다.')
    return json.loads(p.read_text())

def import_csv(text):
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not set(FIELDS)<=set(reader.fieldnames or []):raise ValueError('제외 양식의 모든 열이 필요합니다. 미확인은 빈칸으로 남기세요.')
    now=instant(store.now());rows=[];seen=set()
    for number,r in enumerate(reader,2):
        day=datetime.strptime(r['date'],'%Y-%m-%d').date().isoformat();code=r['code'].strip();known=instant(r['known_at'])
        if not re.fullmatch(r'[0-9A-Z]{6}',code) or known.date().isoformat()!=day or known>now:raise ValueError(f'{number}행: 코드/관측 날짜/미래 시각 오류')
        key=(day,code,known.isoformat())
        if key in seen:raise ValueError(f'{number}행: 같은 종목·시각 중복')
        seen.add(key);flags={}
        for k in FLAGS:
            v=r[k].strip()
            if v not in ('','0','1'):raise ValueError(f'{number}행 {k}: 0/1/빈칸만 허용')
            flags[k]=None if v=='' else v=='1'
        if not r['source'].strip():raise ValueError(f'{number}행: 근거 출처(source) 필요')
        rows.append({'date':day,'code':code,'known_at':known.isoformat(),'source':r['source'].strip()[:500],'flags':flags})
        if len(rows)>500000:raise ValueError('최대 50만 행')
    if not rows:raise ValueError('자료 행이 없습니다.')
    rows.sort(key=lambda r:(r['date'],r['code'],r['known_at']));ident=store.digest(rows);path=ROOT/'imports'/(ident+'.json')
    # A re-upload cannot alter the original receipt timestamp or an existing artifact.
    if not path.exists():store.write(path,{'id':ident,'received_at':store.now(),'rows':rows})
    return {'eligibility_id':ident,'rows':len(rows),'note':'사용자 제공 이력의 진위/완전성을 자동 인증하지 않습니다. 과거 업로드는 과거 모의계좌 매수를 소급 허용하지 않습니다.'}

def catalog():
    out=[]
    for p in (ROOT/'imports').glob('*.json'):
        v=json.loads(p.read_text());rs=v['rows']
        out.append({'id':v['id'],'created':v['received_at'],'rows':len(rs),'start':rs[0]['date'],'end':rs[-1]['date']})
    return sorted(out,key=lambda r:r['created'],reverse=True)

def api_row(r,captured):
    # API screen is an operational rule, NOT verified False for every flag.
    keys=('code','name','state','marketCode','auditInfo','orderWarning','companyClassName')
    raw={k:str(r.get(k) or '').strip() for k in keys}
    flags={k:None for k in FLAGS};blocked=[];unknown=[]
    state=set(raw['state'].split('|'));audit=raw['auditInfo'];name=raw['name'];mc=raw['marketCode']
    for k,label in FLAGS.items():
        if label in state or audit==label:flags[k]=True
    if '환기' in audit or any('환기' in t for t in state):flags['hwangi']=True
    if raw['companyClassName']=='스팩' or '스팩' in name:flags['spac']=True
    if re.search(r'우(?:[A-Z])?(?:\(전환\))?$',name,re.I):flags['preferred']=True
    if mc=='6':flags['reit']=True
    if mc=='8':flags['etf']=True
    if mc in ('60','70','90'):flags['etn']=True
    if mc not in ('0','10'):blocked.append('대상 시장 아님: '+(mc or '누락'))
    # Nonzero warning values are vetoed without guessing their enum meanings.
    if raw['orderWarning'] and raw['orderWarning']!='0':blocked.append('투자유의 코드 '+raw['orderWarning'])
    if not raw['orderWarning']:unknown.append('투자유의 코드 누락')
    if audit!='정상':
        if audit in ('거래정지','관리종목','투자주의','투자경고','투자위험','투자주의환기종목','정리매매','단기과열'):blocked.append(audit)
        else:unknown.append('미확인 감리구분: '+(audit or '누락'))
    ordinary={'담보대출','신용가능'}|{'증거금'+str(n)+'%' for n in (20,30,40,50,60,100)}
    adverse={'거래정지','관리종목','정리매매','투자주의','투자경고','투자위험','투자주의환기종목'}
    if not raw['state'] or state-ordinary-adverse:unknown.append('종목상태 누락/새 값')
    blocked.extend(FLAGS[k] for k,v in flags.items() if v is True)
    if mc=='10' and raw['companyClassName'] not in ('중견기업','우량기업','벤처기업','신성장기업','외국기업','스팩'):unknown.append('회사분류 미확인')
    # Conservative code/name screen; no claim of an authoritative share-class master.
    if not re.fullmatch(r'[0-9A-Z]{6}',raw['code']) or not name:unknown.append('코드/명칭 형식 오류')
    elif not raw['code'].endswith('0') and not flags['preferred']:unknown.append('주권 종류 확인 필요')
    screen={'policy':'api_screen_v37','allowed':not blocked and not unknown,
            'blocked':sorted(set(blocked)),'unknown':unknown,
            'limitation':'우선주/스팩 명칭·코드 보조 선별이며 공식 주권종류 전체 인증이 아닙니다. 비정상 감리 및 0 이외 유의코드는 모두 차단합니다.'}
    return {'date':captured[:10],'code':raw['code'],'known_at':captured,'source':'키움 ka10099 복합 선별',
            'flags':flags,'raw':raw,'screen':screen}

def _capture(progress=lambda **kw:None):
    from kiwoom import _post
    rows=[]
    for market in ('0','10'):
        cont=key=None;seen=set()
        for page in range(30):
            progress(stage='제외 상태 목록 수집 · '+market,done=page,total=30)
            response,data=_post('/api/dostk/stkinfo','ka10099',{'mrkt_tp':market},cont_yn=cont,next_key=key)
            if not isinstance(data.get('list'),list) or (page==0 and not data['list']):raise ValueError('상태 목록 응답 누락/빈 시장 목록')
            captured=store.now()
            rows.extend(api_row(r,captured) for r in data['list'] if re.fullmatch(r'[0-9A-Z]{6}',str(r.get('code',''))))
            cont=response.headers.get('cont-yn');key=response.headers.get('next-key')
            if cont!='Y':break
            if not key or key in seen:raise ValueError('상태 목록 연속조회 키 누락/반복')
            seen.add(key);time.sleep(.3)
        else:raise ValueError('상태 목록 페이지 상한 초과')
    if not rows:raise ValueError('상태 목록이 비었습니다.')
    value={'received_at':store.now(),'rows':rows,'policy':'api_screen_v37'};value['id']=store.digest(value)
    store.write(ROOT/'observations'/(value['id']+'.json'),value)
    return {'eligibility_snapshot':value['id'],'rows':len(rows),'note':'자동 복합 선별 완료. CSV는 선택 사항입니다. 전체 주권종류 인증이 아닌 API·명칭·코드 기반 정책입니다.'}

def capture(progress=lambda **kw:None):
    try:return _capture(progress)
    except Exception:
        failure={'observed_at':store.now(),'reason':'상태 수집 실패 또는 중단'}
        store.write(ROOT/'failures'/(store.digest(failure)+'.json'),failure)
        raise

class Gate:
    def __init__(self,ident=None,live=False,days=None):
        self.live=live;self.index=defaultdict(list);self.failures=[];self.api_batches=[]
        wanted=set(days) if days is not None else ({store.now()[:10]} if live else None)
        paths=[]
        if ident:
            store.check_id(ident);paths=[ROOT/'imports'/(ident+'.json')]
        if live:paths=[p for folder in ('imports','observations') for p in (ROOT/folder).glob('*.json')]
        if live:
            for p in (ROOT/'failures').glob('*.json'):
                stamp=json.loads(p.read_text())['observed_at']
                if wanted is None or stamp[:10] in wanted:self.failures.append(stamp)
        for path in paths:
            # Artifacts use canonical sorted keys: id/policy/received_at precede rows.
            # Stream rows so years of status history cannot be loaded all at once.
            meta={}
            with path.open('rb') as f:
                for prefix,event,value in ijson.parse(f):
                    if prefix=='rows' and event=='start_array':break
                    if prefix in ('id','policy','received_at') and event=='string':meta[prefix]=value
            if not meta.get('id') or not meta.get('received_at'):raise ValueError('제외 상태 기록의 메타데이터가 없습니다.')
            if meta.get('policy')=='api_screen_v37':
                if wanted is not None and meta['received_at'][:10] not in wanted:continue
                self.api_batches.append((meta['received_at'],meta['id']))
            with path.open('rb') as f:
                for r in ijson.items(f,'rows.item',use_float=True):
                    if wanted is not None and r['date'] not in wanted:continue
                    self.index[(r['date'],r['code'])].append({**r,'received_at':meta['received_at'],'artifact_id':meta['id']})
    def decision(self,code,day,cutoff):
        stop=instant(cutoff);records=[r for r in self.index.get((day,code),[]) if instant(r['known_at'])<=stop and (not self.live or instant(r['received_at'])<=stop)]
        positive={FLAGS[k] for r in records for k,v in r['flags'].items() if v is True}
        for r in records:positive.update(r.get('screen',{}).get('blocked',[]))
        complete=[r for r in records if all(r['flags'].get(k) is not None for k in FLAGS)]
        api=[r for r in records if r.get('screen',{}).get('policy')=='api_screen_v37']
        latest=max(api,key=lambda r:instant(r['known_at'])) if api else None
        failures=[t for t in self.failures if instant(t).date().isoformat()==day and instant(t)<=stop]
        failed=bool(failures and (not latest or max(map(instant,failures))>=instant(latest['received_at'])))
        batches=[(t,ident) for t,ident in self.api_batches if instant(t).date().isoformat()==day and instant(t)<=stop]
        newest=max(batches,key=lambda x:instant(x[0]))[1] if batches else None
        auto=bool(latest and latest['artifact_id']==newest and latest['screen']['allowed'] and not failed)
        ok=bool(complete or auto) and not positive
        return {'allowed':ok,'reason':('CSV 전체 상태 확인' if complete else 'API 복합 선별 통과') if ok else '제외: '+', '.join(sorted(positive)) if positive else '제외 상태 미확인'+(' · 최근 자동 수집 실패' if failed else ''),
                'basis':'csv' if complete else 'api_screen_v37' if auto else 'blocked_or_unknown',
                'sources':sorted({r['artifact_id'] for r in records}),'cutoff':cutoff}

    def apply(self,prepared,observed_at=None):
        counts={'allowed':0,'excluded':0,'unknown':0};prepared['eligibility']={}
        for day,bars in prepared['bars'].items():
            close_cutoff=day+'T15:40:00+09:00'
            if self.live and observed_at and day==observed_at[:10]:close_cutoff=observed_at
            decisions={c:self.decision(c,day,close_cutoff) for c in bars}
            prepared['eligibility'][day]=decisions
            for c,b in bars.items():
                b['buy_eligibility']=self.decision(c,day,day+'T09:00:00+09:00')
                d=decisions[c];counts['allowed' if d['allowed'] else 'excluded' if d['reason'].startswith('제외:') else 'unknown']+=1
        return counts

def summary():
    day=store.now()[:10];gate=Gate(live=True);codes=sorted({c for d,c in gate.index if d==day});counts={'allowed':0,'excluded':0,'unknown':0}
    for code in codes:
        d=gate.decision(code,day,store.now());counts['allowed' if d['allowed'] else 'excluded' if d['reason'].startswith('제외:') else 'unknown']+=1
    return {'date':day,'counts':counts,'catalog':catalog(),'note':NOTE,'limitation':'CSV 없이 API 복합 선별을 사용합니다. 우선주·스팩의 명칭/코드 보조 선별에는 한계가 있으며 전체 분류 인증이 아닙니다. 누락·새 상태값·최근 수집 실패는 차단합니다.'}


def current_candidates(prepared):
    """Current screening of latest bars, never used to backfill paper signals."""
    observed=store.now();day=observed[:10];latest=prepared['dates'][-1];gate=Gate(live=True)
    prepared['eligibility']={latest:{c:gate.decision(c,day,observed) for c in prepared['bars'][latest]}}
    return day
