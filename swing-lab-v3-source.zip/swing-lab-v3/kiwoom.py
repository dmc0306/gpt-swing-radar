import os
import time
import threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import httpx
from dotenv import load_dotenv

load_dotenv(os.path.expanduser("~/.config/swing-radar/kiwoom.env"))

BASE = os.getenv("KIWOOM_BASE_URL", "https://api.kiwoom.com")
APPKEY = os.getenv("KIWOOM_APPKEY")
SECRET = os.getenv("KIWOOM_SECRETKEY")

_TOKEN = None
_TOKEN_EXPIRES_AT = 0.0
_TOKEN_LOCK = threading.Lock()
KST = ZoneInfo("Asia/Seoul")


def _now_kst():
    return datetime.now(KST)


# TLS 연결을 API 호출마다 새로 만들지 않고 keep-alive로 재사용한다.
_KIWOOM_HTTP = httpx.Client(
    base_url=BASE,
    timeout=httpx.Timeout(20.0, connect=6.0),
    limits=httpx.Limits(
        max_connections=12,
        max_keepalive_connections=6,
        keepalive_expiry=30.0,
    ),
)


def _headers(token, api_id, cont_yn=None, next_key=None):
    h = {
        "Content-Type": "application/json;charset=UTF-8",
        "authorization": f"Bearer {token}",
        "api-id": api_id,
    }
    if cont_yn:
        h["cont-yn"] = cont_yn
    if next_key:
        h["next-key"] = next_key
    return h


def get_token(force=False):
    global _TOKEN, _TOKEN_EXPIRES_AT
    if not force and _TOKEN and time.time() < _TOKEN_EXPIRES_AT - 300:
        return _TOKEN
    # 자동수집 worker들이 동시에 첫 호출을 해도 토큰 재발급은 한 번만 수행한다.
    with _TOKEN_LOCK:
        if not force and _TOKEN and time.time() < _TOKEN_EXPIRES_AT - 300:
            return _TOKEN
        if not APPKEY or not SECRET:
            raise RuntimeError("KIWOOM_APPKEY 또는 KIWOOM_SECRETKEY가 없습니다.")
        r = _KIWOOM_HTTP.post(
            "/oauth2/token",
            headers={"Content-Type": "application/json;charset=UTF-8"},
            json={
                "grant_type": "client_credentials",
                "appkey": APPKEY,
                "secretkey": SECRET,
            },
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
        if data.get("return_code") != 0:
            raise RuntimeError(data)
        _TOKEN = data["token"]
        _TOKEN_EXPIRES_AT = time.time() + 23 * 3600
        return _TOKEN


def _post(path, api_id, body, token=None, timeout=20, cont_yn=None, next_key=None):
    token = token or get_token()
    last_error = None
    for attempt in range(3):
        try:
            r = _KIWOOM_HTTP.post(
                path,
                headers=_headers(token, api_id, cont_yn, next_key),
                json=body,
                timeout=timeout,
            )
        except httpx.TransportError as e:
            last_error = e
            if attempt >= 2:
                raise
            time.sleep(0.35 * (2 ** attempt))
            continue

        if r.status_code == 401:
            # 만료 토큰은 한 번 갱신하고 같은 읽기 요청을 재시도한다.
            token = get_token(force=True)
            if attempt < 2:
                continue
        if r.status_code == 429 or 500 <= r.status_code < 600:
            if attempt < 2:
                retry_after = r.headers.get("retry-after", "")
                try:
                    wait = min(3.0, max(0.2, float(retry_after)))
                except Exception:
                    wait = 0.4 * (2 ** attempt)
                time.sleep(wait)
                continue
        r.raise_for_status()
        data = r.json()
        if data.get("return_code") not in (None, 0):
            raise RuntimeError(data)
        return r, data
    if last_error:
        raise last_error
    raise RuntimeError(f"Kiwoom request failed after retries: {api_id}")

