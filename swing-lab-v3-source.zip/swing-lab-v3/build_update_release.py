"""Create protocol-1 assets for a reviewed, published GitHub release."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
from auto_update import managed, version


def build(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    manifest = json.loads((root/'BUILD_MANIFEST.json').read_text())
    version(manifest['version'])
    output.mkdir(parents=True, exist_ok=True)
    files = {}
    for path in sorted(root.rglob('*')):
        name = path.relative_to(root).as_posix()
        if managed(name) and path.is_file() and not path.is_symlink():
            files[name] = path.read_bytes()
    archive = output/'swing-lab-v3-update.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as package:
        for name, value in files.items():
            package.writestr('swing-lab-v3/'+name, value)
    release = {'protocol': 1, 'version': manifest['version'],
               'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
               'files': {name: hashlib.sha256(value).hexdigest() for name, value in files.items()}}
    (output/'release.json').write_text(json.dumps(release, ensure_ascii=False, indent=2))
    return release


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', default=str(Path(__file__).parent))
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = build(args.source, args.output)
    print('release.json / swing-lab-v3-update.zip · '+result['version'])
