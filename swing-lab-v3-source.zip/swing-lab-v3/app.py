import full_compare
import price_store, strategies, operations, data_admin, telegram_web
from starlette.background import BackgroundTask
import base64, csv, hmac, io, json, os, threading, time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo
from fastapi import FastAPI, Request, Body, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.middleware.gzip import GZipMiddleware
import data_source, engine, paper, store, universe, quality, membership, alerts, jobs, workflows, comparison, session_calendar, eligibility
import reward_candidates, candidate_board
import phone_alerts

WEB=Path(__file__).parent/'web';LOCK=jobs.LOCK;JOB=jobs.JOB;STOP=threading.Event()
progress=jobs.progress
submit=jobs.submit

def settings():
    f=store.ROOT/'settings.json'
    return json.loads(f.read_text()) if f.exists() else {'codes':[],'years':5,'auto':False}

def scheduled():
    last=None;preopen=None
    while not STOP.wait(60):
        try:
            with operations.access():
                now=datetime.now(ZoneInfo('Asia/Seoul'));s=settings();day=now.date().isoformat()
                if s['auto'] and s['codes'] and now.weekday()<5 and 530<=now.hour*60+now.minute<540 and preopen!=day and not jobs.snapshot().get('paused') and not jobs.snapshot().get('error'):
                    try:submit(task={'kind':'eligibility_capture','payload':{}});preopen=day
                    except HTTPException:pass
                if not s['auto'] or not s['codes'] or now.weekday()>4 or now.hour*60+now.minute<940 or day==last:continue
                if jobs.snapshot().get('paused') or (jobs.snapshot().get('error') and jobs.snapshot().get('task')):continue
                try:
                    submit(task={'kind':'scheduled','payload':s});last=day
                except HTTPException:pass
        
        except HTTPException:continue

@asynccontextmanager
async def lifespan(app):
    thread=threading.Thread(target=scheduled,daemon=True);thread.start()
    threading.Thread(target=phone_alerts.loop,args=(STOP,),daemon=True).start()
    yield
    STOP.set();jobs.pause()

app=FastAPI(title='스윙 검증실 v3',lifespan=lifespan)
app.add_middleware(GZipMiddleware,minimum_size=1200)

@app.middleware('http')
async def guard(req,call_next):
    password=os.getenv('SWING_PASSWORD','')
    if password:
        try:
            raw=req.headers.get('authorization','');u,p=base64.b64decode(raw.split(' ',1)[1]).decode().split(':',1)
            valid=raw.startswith('Basic ') and hmac.compare_digest(u,os.getenv('SWING_USER','radar')) and hmac.compare_digest(p,password)
        except Exception:valid=False
        if not valid:return Response(status_code=401,headers={'WWW-Authenticate':'Basic realm="Swing Lab"'})
    if req.method not in ('GET','HEAD','OPTIONS'):
        origin=req.headers.get('origin')
        if origin and urlparse(origin).netloc!=req.headers.get('host'):return Response('Origin mismatch',status_code=403)
    try:
        with operations.access(reset=req.url.path in ('/api/data/reset','/api/data/restore')):
            return await call_next(req)
    except HTTPException as exc:
        return Response(json.dumps({'detail':exc.detail},ensure_ascii=False),status_code=exc.status_code,media_type='application/json')

@app.exception_handler(ValueError)
async def invalid(req,exc):return Response(json.dumps({'detail':str(exc)},ensure_ascii=False),status_code=400,media_type='application/json')

@app.get('/')
def home():return FileResponse(WEB/'index.html',headers={'Cache-Control':'no-cache'})
@app.get('/assets/{name}')
def asset(name):
    if name not in ('dashboard.js','easy-ui.js','candidate-ui.js','pattern-ui.js','style.css'):raise HTTPException(404)
    return FileResponse(WEB/name,headers={'Cache-Control':'no-cache'})
@app.get('/api/status')
def status():
    with LOCK:job=dict(JOB)
    return {'job':job,'datasets':store.datasets(),'runs':store.runs(),'paper':paper.view(),'settings':settings(),'time':store.now(),'universe':universe.get(),'memberships':membership.catalog(),'alerts':alerts.inbox(),'comparisons':comparison.catalog(),'paper_archives':paper.archives(),'calendar':session_calendar.get()['source'],'eligibility':eligibility.summary()}
@app.post('/api/reward-candidates/{ident}')
def reward_scan(ident,p:dict=Body(...)):
    return strategies.scan({**p,'strategy_id':p.get('mode','focused'),'dataset_id':ident})
@app.get('/api/strategy-review')
def strategy_review():return json.loads((WEB.parent/'reports'/'strategy-review-summary.json').read_text())
@app.get('/api/phone-alerts')
def phone_status():return phone_alerts.view()
@app.post('/api/phone-alerts/settings')
def phone_settings(p:dict=Body(...)):return phone_alerts.save(p)
@app.post('/api/phone-alerts/test')
def phone_test():return phone_alerts.test_message()
@app.get('/api/job')
def job_status():
    with LOCK:return dict(JOB)
@app.get('/api/app-update/status')
def app_update_status():
    path=Path.home()/'.config'/'swing-lab-v3'/'updater'/'status.json'
    if not path.exists():return {'state':'not_checked','message':'자동 업데이트를 설정한 뒤 첫 확인 결과가 표시됩니다.'}
    value=json.loads(path.read_text())
    return {k:value[k] for k in ('state','message','version') if k in value}
@app.post('/api/settings')
def save_settings(p:dict=Body(...)):
    with LOCK:
        if JOB['running']:raise HTTPException(409,'작업 완료 후 설정을 저장하세요.')
        codes=list(dict.fromkeys(str(c).strip() for c in p.get('codes',[])))
        import re
        if len(codes)>3000 or any(not re.fullmatch(r'[0-9A-Z]{6}',c) for c in codes):raise ValueError('영문 대문자·숫자 6자리 코드 최대 3000개')
        years=int(p.get('years',5))
        if not 1<=years<=10:raise ValueError('수집 기간은 1~10년')
        value={'codes':codes,'years':years,'auto':bool(p.get('auto',False))};store.write(store.ROOT/'settings.json',value)
    return value
@app.post('/api/collect')
def collect():
    s=settings();return submit(task={'kind':'collect','payload':s})
@app.post('/api/import')
async def csv_import(req:Request):
    data=bytearray()
    async for chunk in req.stream():
        data.extend(chunk)
        if len(data)>50*1024*1024:raise HTTPException(413,'CSV는 50MB 이하만 업로드하세요.')
    try:text=data.decode('utf-8-sig')
    except UnicodeDecodeError:raise ValueError('CSV를 UTF-8로 저장하세요.')
    return submit(lambda:data_source.import_csv(text))
@app.get('/api/template.csv')
def template():return Response('date,code,name,open,high,low,close,volume\n',media_type='text/csv',headers={'Content-Disposition':'attachment; filename="prices-template.csv"'})
@app.post('/api/research')
def start_research(p:dict=Body(...)):raise ValueError('다중 탐색은 정리했습니다. 5개 고정 전략 비교를 사용하세요.')
@app.get('/api/runs/{ident}')
def run(ident):return store.get_run(ident)
@app.post('/api/runs/{ident}/final')
def finalize(ident):raise ValueError('이전 다중 탐색은 보관 전용입니다. 고정5개 비교를 사용하세요.')
@app.post('/api/paper/start')
def paper_start(p:dict=Body(...)):return submit(lambda:paper.start(p['run_id']))
@app.post('/api/paper/stop')
def paper_stop(p:dict=Body(default={})):return submit(lambda:paper.stop(p.get('account_id')))
@app.post('/api/paper/update')
def paper_update(p:dict=Body(...)):return submit(lambda:paper.update(p['dataset_id']))
@app.get('/api/candidates/{ident}')
def candidates(ident,strategy:str=''):
    raise ValueError('전략5개 화면의 지금 기준 후보 보기 버튼을 사용하세요.')
@app.get('/api/runs/{ident}/trades.csv')
def export(ident):
    run=store.get_run(ident);stream=io.StringIO();w=csv.writer(stream);w.writerow(['구간','종목','신호일','매수일','매도일','수량','매수가','매도가','손익','수익률','사유'])
    blocks=[(f"평가{f['number']}",f['result']) for f in run['folds'] if f['result']]
    if run['final']:blocks.append(('최종',run['final']['result']))
    for label,r in blocks:
        for t in r['trades']:
            values=[label,t['code'],t['signal_date'],t['entry_date'],t['exit_date'],t['qty'],t['entry_price'],t['exit_price'],t['pnl'],t['return_pct'],t['exit_reason']]
            w.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in values])
    return Response('\ufeff'+stream.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="trades-{ident}.csv"'})

@app.get('/api/chart/{ident}/{code}')
def chart(ident,code):
    rows=price_store.Dataset(ident).symbol(code)
    if not rows:raise HTTPException(404,'종목 자료 없음')
    return {'rows':sorted(rows,key=lambda r:r['date'])[-80:]}


@app.post('/api/prepare')
def prepare_data(p:dict=Body(...)):
    if int(p.get('years',5)) not in (3,5,10):raise ValueError('기간은 3, 5, 10년')
    p['auto_research']=False
    return submit(task={'kind':'prepare','payload':p})

@app.post('/api/job/pause')
def pause_job():return jobs.pause()
@app.post('/api/job/resume')
def resume_job():return jobs.resume()
@app.get('/api/quality/{ident}')
def data_quality(ident):
    with operations.compute():return quality.get(ident)
@app.post('/api/collect/retry')
def retry_collection():
    path=store.ROOT/'collection.json'
    if not path.exists():raise ValueError('수집 기록 없음')
    record=json.loads(path.read_text())
    if not record.get('errors'):raise ValueError('실패한 종목이 없습니다.')
    return submit(task={'kind':'retry','payload':record})
@app.get('/api/alerts')
def notifications():return alerts.inbox()
@app.post('/api/alerts/read')
def seen_notifications():return alerts.read_all()
@app.get('/api/membership/template.csv')
def membership_template():return Response('code,start,end,known_at\n',media_type='text/csv',headers={'Content-Disposition':'attachment; filename="membership-template.csv"'})
@app.post('/api/membership')
async def import_membership(req:Request):
    data=bytearray()
    async for chunk in req.stream():
        data.extend(chunk)
        if len(data)>10*1024*1024:raise HTTPException(413,'구성종목 CSV는 10MB 이하')
    try:text=data.decode('utf-8-sig')
    except UnicodeDecodeError:raise ValueError('UTF-8 CSV 필요')
    return submit(lambda:membership.import_csv(text))

def trade_chart(rows,trade,end):
    rows=sorted([r for r in rows if r['code']==trade['code'] and r['date']<=end],key=lambda r:r['date'])
    indices=[i for i,r in enumerate(rows) if trade['entry_date']<=r['date']<=trade.get('exit_date',end)]
    if not indices:raise ValueError('해당 거래 기간의 차트 자료 없음')
    rows=rows[max(0,indices[0]-20):indices[-1]+11]
    return {'rows':rows,'trade':trade}
@app.get('/api/runs/{ident}/trade-chart')
def run_trade_chart(ident,scope:str='final',index:int=0):
    run=store.get_run(ident)
    if scope=='final':
        if not run['final']:raise ValueError('최종 기간은 아직 잠겨 있습니다.')
        result=run['final']['result'];end=run['split']['holdout_end']
    else:
        try:fold=next(f for f in run['folds'] if str(f['number'])==scope)
        except StopIteration:raise ValueError('평가 구간 없음')
        result=fold['result'];end=fold['test_end']
    if not result or not 0<=index<len(result['trades']):raise ValueError('거래 기록 없음')
    return trade_chart(price_store.Dataset(run['dataset_id']).symbol(result['trades'][index]['code']),result['trades'][index],end)
@app.get('/api/paper/trade-chart')
def paper_trade_chart(index:int=0,opened:bool=False,account_id:str=''):
    group,state=paper.account(account_id)
    entries=state['book']['positions'] if opened else state['book']['trades']
    if not 0<=index<len(entries):raise ValueError('거래 기록 없음')
    rows=price_store.Dataset(group.get('dataset_id') or store.get_run(state['run_id'])['dataset_id']).symbol(entries[index]['code'])
    # Overlay the actual frozen bars used by the account on those dates.
    merged={(r['date'],r['code']):r for r in rows}
    for snap in state['snapshots']:
        path=paper.evidence_path(group,snap['date']) if group.get('schema')==2 else store.ROOT/'paper_evidence'/(state['id']+'-'+snap['date']+'.json')
        if path.exists():
            for bar in json.loads(path.read_text()).get('bars',{}).values():
                if bar['code']==entries[index]['code']:merged[(bar['date'],bar['code'])]=bar
    return trade_chart(list(merged.values()),entries[index],state['book']['last_date'])

@app.post('/api/compare')
def compare_conditions(p:dict=Body(...)):raise ValueError('5개 고정 전략 비교를 사용하세요. 과거 결과는 보관됩니다.')
@app.get('/api/comparisons/{ident}')
def comparison_record(ident):return comparison.get(ident)
@app.post('/api/paper/start-pair')
def start_pair(p:dict=Body(...)):raise ValueError('고정5개 전략의 새 두 계좌 시작을 사용하세요.')
@app.get('/api/paper/archive/{ident}')
def paper_archive(ident):return paper.archived(ident)
@app.post('/api/job/archive')
def archive_job():return jobs.archive_interrupted()
@app.get('/api/calendar/template.csv')
def calendar_template():return Response('date,is_open\n',media_type='text/csv',headers={'Content-Disposition':'attachment; filename="session-calendar.csv"'})
@app.post('/api/calendar')
async def import_calendar(req:Request):
    data=bytearray()
    async for chunk in req.stream():
        data.extend(chunk)
        if len(data)>1024*1024:raise HTTPException(413,'달력 CSV는 1MB 이하')
    try:text=data.decode('utf-8-sig')
    except UnicodeDecodeError:raise ValueError('UTF-8 CSV가 필요합니다.')
    return submit(lambda:session_calendar.import_csv(text))
@app.get('/api/comparisons/{ident}/trade-chart')
def compare_trade_chart(ident,variant:str='baseline',index:int=0):
    r=comparison.get(ident);v=next((v for v in r['variants'] if v['id']==variant),None)
    if not v or not v.get('result') or not 0<=index<len(v['result']['trades']):raise ValueError('비교 거래 없음')
    return trade_chart(price_store.Dataset(r['dataset_id']).symbol(v['result']['trades'][index]['code']),v['result']['trades'][index],r['end'])
@app.get('/api/comparisons/{ident}/trades.csv')
def comparison_csv(ident):
    r=comparison.get(ident);buf=io.StringIO();w=csv.writer(buf)
    w.writerow(['조건','종목','신호일','매수일','최종 매도일','최초 수량','전체 순손익','순수익률','마지막 청산 사유'])
    for v in r['variants']:
        for t in v.get('result',{}).get('trades',[]):w.writerow([v['name'],t['code'],t['signal_date'],t['entry_date'],t['exit_date'],t['qty'],t['pnl'],t['return_pct'],t['exit_reason']])
    return Response('\ufeff'+buf.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="comparison-{ident}.csv"'})
@app.get('/api/report')
def analysis_report():return FileResponse(Path(__file__).parent/'reports'/'comparison-report.html')

@app.get('/api/comparisons/{ident}/fills.csv')
def comparison_fills_csv(ident):
    r=comparison.get(ident);buf=io.StringIO();w=csv.writer(buf)
    w.writerow(['조건','종목','진입일','완료 상태','최초 수량','매도 순번','매도일','매도 수량','원가격','체결가','매도비용','배분 매수원가','체결 순손익','사유'])
    for v in r['variants']:
        for status,positions in [('완료',v.get('result',{}).get('trades',[])),('미청산',v.get('result',{}).get('open',[]))]:
            for p in positions:
                for i,leg in enumerate(engine.sale_legs(p),1):
                    w.writerow([v['name'],p['code'],p['entry_date'],status,p.get('initial_qty',p['qty']),i,leg['date'],leg['qty'],leg['raw_price'],leg['fill_price'],leg['fee'],leg.get('allocated_cost',''),leg['pnl'],leg['reason']])
    return Response('\ufeff'+buf.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="fills-{ident}.csv"'})

@app.get('/api/eligibility/template.csv')
def eligibility_template():
    return Response(','.join(eligibility.FIELDS)+'\n',media_type='text/csv',headers={'Content-Disposition':'attachment; filename="exclusions-template.csv"'})
@app.post('/api/eligibility/capture')
def eligibility_capture():return submit(task={'kind':'eligibility_capture','payload':{}})
@app.post('/api/eligibility/import')
async def eligibility_import(req:Request):
    data=bytearray()
    async for chunk in req.stream():
        data.extend(chunk)
        if len(data)>50*1024*1024:raise HTTPException(413,'상태 CSV는 50MB 이하')
    try:text=data.decode('utf-8-sig')
    except UnicodeDecodeError:raise ValueError('UTF-8 CSV를 사용하세요.')
    return submit(lambda:eligibility.import_csv(text))

@app.get("/api/robustness-report")
def robustness_report():
    return FileResponse(Path(__file__).parent/"reports"/"robustness-report.html",media_type="text/html")


@app.get('/api/dashboard')
def dashboard():
    info={}
    try:
        info={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:'))}
    except (OSError,ValueError):pass
    d=store.datasets();u=universe.get();collection=store.ROOT/'collection.json'
    return {'version':'3.19.0','time':store.now(),'datasets':d,'settings':settings(),'job':jobs.snapshot(),
        'collection':json.loads(collection.read_text()) if collection.exists() else None,
        'universe':{k:u.get(k) for k in ('status','listed','checked','eligible','asof','limited_out','cache_summary')} if u else None,
        'memory_kib':info,'paper':paper.view(),'paper_archives':paper.archives(),
        'catalog':strategies.catalog(),'all_comparisons':full_compare.summaries(),'comparisons':comparison.catalog(),'runs':store.runs(),
        'backups':data_admin.backups(),'alerts':alerts.inbox(),'memberships':membership.catalog(),'exclusions':eligibility.catalog(),'calendar':session_calendar.get()['source']}
def _new_capacity(payload):
    # Defaults apply only to a new calculation/account; frozen existing accounts keep their config.
    return {**payload,'config':{'max_positions':10,**(payload.get('config') or {})}}

@app.get('/api/strategies')
def strategies_catalog():return strategies.catalog()
@app.post('/api/strategies/candidates')
def strategy_candidates(p:dict=Body(...)):return strategies.scan(_new_capacity(p))
@app.post('/api/strategies/candidates-all')
def strategy_candidates_all(p:dict=Body(...)):return submit(lambda:candidate_board.search(_new_capacity(p),progress))
@app.get('/api/strategies/candidate-board/{ident}')
def strategy_candidate_board(ident):return candidate_board.read(ident)
@app.post('/api/strategies/candidate-board/{ident}/price')
def strategy_candidate_price(ident,p:dict=Body(...)):return candidate_board.price_check(ident,p)
@app.get('/api/pattern-report')
def pattern_report():return FileResponse(Path(__file__).parent/'reports'/'pattern-report.html',media_type='text/html')
@app.get('/api/candidate-expansion-report')
def candidate_expansion_report():return FileResponse(Path(__file__).parent/'reports'/'candidate-expansion-report.html',media_type='text/html')
@app.post('/api/strategies/start-pair')
def strategy_pair(p:dict=Body(...)):return submit(lambda:strategies.start_pair(_new_capacity(p)))
@app.post('/api/strategies/compare')
def strategy_compare(p:dict=Body(...)):return submit(lambda:full_compare.compare(_new_capacity(p),progress))
@app.get('/api/data/reset-preview')
def reset_preview(scope:str='cache'):return data_admin.preview(scope)
@app.post('/api/data/reset')
def reset_data(p:dict=Body(...)):return data_admin.reset(p)
@app.post('/api/data/restore')
def restore_data(p:dict=Body(...)):return data_admin.restore(p)
@app.post('/api/data/export')
def export_data(p:dict=Body(default={})):
    with operations.compute():path=data_admin.export(p)
    return FileResponse(path,media_type='application/zip',filename='swing-analysis-export.zip',background=BackgroundTask(path.unlink,missing_ok=True))
@app.post('/api/settings/auto')
def automatic(p:dict=Body(...)):
    with jobs.LOCK:
        if jobs.JOB.get('running'):raise ValueError('작업 완료 후 변경하세요.')
        s=settings();s['auto']=p.get('enabled') is True;store.write(store.ROOT/'settings.json',s)
    return s
@app.post('/api/telegram/begin')
def telegram_begin(req:Request,p:dict=Body(...)):return telegram_web.begin(req,p)
@app.post('/api/telegram/verify')
def telegram_verify(req:Request,p:dict=Body(...)):return telegram_web.verify(req,p)
@app.post('/api/telegram/commit')
def telegram_commit(req:Request,p:dict=Body(...)):return telegram_web.commit(req,p)
@app.post('/api/telegram/disconnect')
def telegram_disconnect(p:dict=Body(...)):
    if p.get('confirm')!='연결 해제':raise ValueError('연결 해제를 확인하세요.')
    return telegram_web.disconnect()


@app.get('/api/ten-position-report')
def ten_position_report():
    return FileResponse(Path(__file__).parent/'reports'/'ten-position-report.html',media_type='text/html')
