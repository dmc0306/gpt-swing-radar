# Swing Lab v3.19.0 자동 업데이트

기능 구현 완료. 사용자 서버 설치, GitHub 저장소 변경 및 릴리스 게시를 실행하지 않았습니다. 지정 저장소의 공개 여부도 현재 확인하지 못했습니다. 공개된 정식 GitHub 릴리스에 아래 두 파일이 있어야 실제 업데이트를 받습니다. ChatGPT에서 ZIP을 만든 것만으로 GitHub에 자동 게시되지는 않습니다.

## 최초 설치 (한 번)
이 ZIP을 서버 홈 폴더에 swing-lab-auto-update-3.19.0.zip 이름으로 올린 뒤 실행합니다.

```bash
unzip -o ~/swing-lab-auto-update-3.19.0.zip -d ~/swing-auto-3190
bash ~/swing-auto-3190/swing-lab-v3/install.sh --update
bash ~/swing-lab-v3/enable-auto-update.sh dmc0306/gpt-swing-radar
```

기존 앱 설치 사용자가 실행해야 합니다. sudo 비밀번호가 필요할 수 있습니다. 기본 설치 경로 ~/swing-lab-v3, 포트8000 기준입니다. 변경한 경로/포트가 있으면 SWING_INSTALL_DIR, SWING_PORT를 지정하세요. 처음에만 관리자 권한으로 타이머를 등록하고 이후 5분마다 자동 실행됩니다.

## 릴리스 배포 경로 설정

업데이트 대상: https://github.com/dmc0306/gpt-swing-radar. 수정본은 이 저장소를 기본값으로 사용합니다. 기존 타이머를 설정했다면 아래 명령을 한 번 실행하여 저장소를 전환합니다.

```bash
bash ~/swing-lab-v3/enable-auto-update.sh dmc0306/gpt-swing-radar
```

앱 소스를 GitHub 저장소에 반영하고, 이 ZIP의 publish-kit/.github/workflows/swing-release.yml을 저장소 루트 .github/workflows/swing-release.yml로 배치합니다. 앱 소스 디렉터리는 저장소 안에서 한 개여야 하며 app.py, BUILD_MANIFEST.json, build_update_release.py가 함께 있어야 합니다. 일반 계좌/가격 data, 인증 .env, 토큰은 저장소에 올리지 않습니다.

공개 저장소의 코드 변경을 검토한 뒤 BUILD_MANIFEST.json의 버전을 올리고 같은 이름의 정식 태그를 push하면 GitHub Actions가 release.json 및 swing-lab-v3-update.zip을 생성·게시합니다. 예시는 v3.19.0 태그입니다. GitHub 쓰기권한과 Actions 사용 권한이 필요하며, 현재 이 대화에서는 권한이 없어 수행하지 못했습니다. 비공개 저장소는 이 구현에서 지원하지 않습니다. 저장소 소스만 바꿔서는 업데이트되지 않으며 정식 릴리스 게시가 필요합니다.

이미 빌드한 release-assets/release.json 및 release-assets/swing-lab-v3-update.zip도 포함되어 있으므로 v3.19.0 공개 정식 릴리스에 그대로 게시할 수 있습니다. 무인 다운로드는 이 두 파일을 사용하는 공개 릴리스가 게시된 뒤 작동합니다. GitHub 로그인/토큰을 서버에 저장하지 않습니다.

## 동작
설정 저장소 최신 공개 정식 릴리스만 확인 → 더 높은 x.y.z 버전만 허용 → ZIP 및 모든 파일 SHA256 검증 → 경로/심볼릭 링크/압축 크기/Python 구문/동일 requirements 검증 → 앱 종료 → 코드 백업·교체 → 재시작 → 로컬 HTTP 응답 확인. 시작 실패 시 이전 코드 복구 후 재시작합니다. 업데이트 코드 실행은 앱 사용자 권한이며 root는 서비스 시작·종료만 담당합니다. 게시자를 신뢰하는 구조로 SHA256은 게시자 진위 확인용 전자서명이 아닙니다.

가격·계좌 data/, 가상환경 .venv 및 로그인 설정은 교체 목록에서 제외합니다. 기본 data/job.json에서 수집·계산 진행 중이면 이번 업데이트를 미룹니다. 사용자 지정 SWING_DATA_DIR를 사용하는 경우 진행 작업 확인은 별도 연결이 필요하므로 이 초기 버전 타이머를 활성화하지 마세요. 라이브 API 요청은 재시작 시 잠시 끊어질 수 있습니다. 자동 업데이트는 앱 코드의 최신 버전 설치이며 가격 자료 자동 수집 설정과 별개입니다.

의존성 변경이 있는 릴리스는 자동 설치하지 않습니다. 데이터 스키마 변경, 설치 방식 변경, updater 프로토콜 변경이 필요한 버전은 별도 수동 전환이 필요합니다. updater 에이전트는 최초 설정시 별도로 복사되므로 에이전트 자체 변경은 enable-auto-update.sh 재실행이 필요합니다.

실행 상태: 앱 설정의 앱 자동 업데이트 항목. 첫 조회까지 결과가 없을 수 있습니다.
즉시 확인: sudo systemctl start swing-lab-auto-update.service
로그: sudo journalctl -u swing-lab-auto-update.service -n 50 --no-pager
자동 업데이트 중단: sudo systemctl disable --now swing-lab-auto-update.timer

## 검증
임시 폴더에서 정상 패키지 설치, 이전 코드 복구 및 신규 파일 제거, 사용자 데이터 보존, SHA 오류·경로 탈출·설치 심볼릭 링크 차단, 모의 GitHub 다운로드, 동일 버전/낮은 버전 건너뛰기, 기본 경로 실행 작업 연기 검사 통과. Python/JavaScript/Bash 구문 확인 완료. 실제 GitHub Actions·인터넷 파일 다운로드·systemd 서비스 등록·사용자 서버 재시작·실제 HTTP 실패 복구는 환경 접근이 없어 수행하지 않았습니다. 정전/강제 종료 전체 복구 및 데이터 마이그레이션 기능은 없습니다.
