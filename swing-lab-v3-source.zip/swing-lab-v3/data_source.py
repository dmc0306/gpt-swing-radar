import csv, io, math, re, time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
import store
import market_cache, price_store

FIELDS=('date','code','name','open','high','low','close','volume')

def normalize(rows,allow_empty=False):
    found={};errors=[];now=datetime.now(ZoneInfo('Asia/Seoul'));today=now.date().isoformat();unfinished=now.hour*60+now.minute<940
    excluded=0
    for i,r in enumerate(rows,2):
        try:
            raw=str(r['date']).strip().split('T')[0]
            d=datetime.strptime(raw,'%Y%m%d').date().isoformat() if re.fullmatch(r'\d{8}',raw) else date.fromisoformat(raw).isoformat()
            if d>today or (unfinished and d==today):excluded+=1;continue
            code=str(r['code']).strip().zfill(6)
            if not re.fullmatch(r'[0-9A-Z]{6}',code):raise ValueError('영문 대문자·숫자 6자리 종목코드 필요')
            v={k:float(str(r[k]).replace(',','')) for k in ('open','high','low','close','volume')}
            if not all(math.isfinite(x) for x in v.values()):raise ValueError('숫자 오류')
            if min(v[k] for k in ('open','high','low','close'))<=0 or v['volume']<0:raise ValueError('가격/거래량 범위 오류')
            if v['high']<max(v['open'],v['close'],v['low']) or v['low']>min(v['open'],v['close']):raise ValueError('고가/저가 불일치')
            row={'date':d,'code':code,'name':str(r.get('name') or code),**v};key=(d,code)
            if key in found and found[key]!=row:raise ValueError('같은 날짜·종목의 중복 값 불일치')
            found[key]=row
        except Exception as e:
            errors.append(f'{i}행: {e}')
            if len(errors)>=10:break
    if errors:raise ValueError('가져오기 중단: '+' / '.join(errors))
    if not found and not allow_empty:raise ValueError('완성된 유효 일봉이 없습니다.')
    return list(found.values()),excluded

def import_csv(text):
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not set(FIELDS)-{'name'}<=set(reader.fieldnames or []):raise ValueError('CSV 필수 열: date,code,open,high,low,close,volume (name 선택)')
    builder=price_store.Builder();excluded=0;total=0;batch=[]
    try:
        for raw in reader:
            total+=1
            if total>500000:raise ValueError('CSV 한 번에 50만 행 이하로 나눠주세요.')
            batch.append(raw)
            if len(batch)>=1000:
                rows,n=normalize(batch,allow_empty=True);builder.add(rows);excluded+=n;batch=[];del rows
        if batch:
            rows,n=normalize(batch,allow_empty=True);builder.add(rows);excluded+=n
        meta=builder.finish('CSV','사용자가 지정한 종목. 당시 전체 상장종목 여부 미확인')
        return {'dataset':meta,'excluded_unfinished':excluded}
    finally:builder.close()


def map_bars(raw,code,name=None):
    return [{'date':x['dt'],'code':code,'name':name or code,'open':abs(float(x['open_pric'])),'high':abs(float(x['high_pric'])),'low':abs(float(x['low_pric'])),'close':abs(float(x['cur_prc'])),'volume':abs(float(x['trde_qty']))} for x in raw]

def collect(codes,years=5,progress=lambda **kw:None,names=None,note=None,retry=False):
    import json
    import series,quality
    codes=list(dict.fromkeys(codes))
    if not codes or len(codes)>6000 or any(not re.fullmatch(r'[0-9A-Z]{6}',c) for c in codes):raise ValueError('수집 종목은 최대 6000개(기존 모의계좌 보존 종목 포함)입니다.')
    cache_before=market_cache.snapshot()
    path=store.ROOT/'collection.json'
    previous=retry if isinstance(retry,dict) else json.loads(path.read_text()) if retry and path.exists() else None
    if retry:
        if not previous:raise ValueError('재시도할 수집 기록이 없습니다.')
        codes=previous['codes'];years=previous['years'];names=previous.get('names',{});note=previous.get('note')
        targets=[e['code'] for e in previous['errors']]
        if not targets:raise ValueError('실패 종목이 없습니다.')
        prior_id=previous.get('dataset_id')
    else:targets=codes;prior_id=None
    def priority(code):
        p=store.ROOT/'history_cache'/(code+'.json')
        if not p.exists():return (0,'',code)
        return (1,p.stat().st_mtime,code)
    targets=sorted(targets,key=priority)
    errors=[];record={'codes':codes,'years':years,'names':names or {},'note':note,'errors':[], 'status':'수집 중','started':store.now()}
    builder=price_store.Builder()
    try:
        if prior_id:
            progress(stage='기존 성공 종목 연결',done=0,total=len(codes))
            for code,rs in price_store.Dataset(prior_id).items():
                if code not in targets:builder.add(rs)
                del rs
        for i,code in enumerate(targets):
            progress(stage=f'{(names or {}).get(code,code)} 일봉 수집',done=i,total=len(targets))
            try:
                bars=series.history(code,(names or {}).get(code,code),years,progress)
                builder.add(bars)
                del bars
            except InterruptedError:
                record.update(status='일시정지',errors=errors,remaining=targets[i:]);store.write(path,record);raise
            except Exception as e:errors.append({'code':code,'error':str(e)[:180]})
            record.update(errors=errors,completed=i+1,cache_summary=market_cache.delta(cache_before));store.write(path,record)
            progress(stage='종목별 저장',done=i+1,total=len(targets))
        progress(stage='전체 일봉 저장 준비',done=0,total=1)
        meta=builder.finish('키움 일봉',note or '현재 사용자가 고른 종목. 생존·선택 편향 있음. 상장폐지·당시 편입 종목 복원 안 됨',progress)
        record.update(status='품질 점검 중',dataset_id=meta['id'],errors=errors);store.write(path,record)
        report=quality.inspect(meta['id'],codes,errors,progress)
        record.update(status='일부 실패' if errors else '완료',finished=store.now());store.write(path,record)
        return {'dataset':meta,'errors':errors,'cache_summary':market_cache.delta(cache_before),'quality_summary':{k:report[k] for k in ('days','short_count','gap_count','stale_count','absent')}}
    finally:
        builder.close()
