#!/usr/bin/env bash
set -euo pipefail
# Ubuntu / Debian, Python 3.10+. Run as your normal account.
if [ "$(id -u)" = 0 ]; then echo '일반 사용자로 실행하세요: bash install.sh'; exit 1; fi
INSTALL_MODE="auto"
if (( $# > 1 )); then echo '사용법: bash install.sh [--update|--deps]'; exit 1; fi
case "${1:-}" in
  '') ;;
  --update) INSTALL_MODE="update" ;;
  --deps) INSTALL_MODE="deps" ;;
  *) echo '사용법: bash install.sh [--update|--deps]'; exit 1 ;;
esac
SOURCE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
TARGET_DIR="${SWING_INSTALL_DIR:-$HOME/swing-lab-v3}"
PORT="${SWING_PORT:-8000}"
[[ "$PORT" =~ ^[0-9]+$ ]] && (( PORT >= 1024 && PORT <= 65535 )) || { echo '포트는 1024~65535'; exit 1; }
[[ "$TARGET_DIR" != *' '* && "$TARGET_DIR" != *$'\n'* && "$HOME" != *' '* ]] || { echo '설치 경로에 공백을 사용할 수 없습니다.'; exit 1; }
if [ "$INSTALL_MODE" != "update" ]; then
  MISSING_PACKAGES=()
  for package in python3 python3-venv python3-pip; do
    if [[ "$(dpkg-query -W -f='${Status}' "$package" 2>/dev/null || true)" != 'install ok installed' ]]; then
      MISSING_PACKAGES+=("$package")
    fi
  done
  if [ "$INSTALL_MODE" = "deps" ]; then MISSING_PACKAGES=(python3 python3-venv python3-pip); fi
  if (( ${#MISSING_PACKAGES[@]} )); then
    sudo apt-get update
    sudo apt-get install -y "${MISSING_PACKAGES[@]}"
  else
    echo '기본 Python 도구가 있어요. apt 목록 갱신과 설치를 건너뜁니다.'
  fi
fi

dependencies_ready() {
  [ -x "$TARGET_DIR/.venv/bin/python" ] && [ -x "$TARGET_DIR/.venv/bin/uvicorn" ] || return 1
  "$TARGET_DIR/.venv/bin/python" - "$SOURCE_DIR/requirements.txt" <<'PY'
import sys
from importlib.metadata import version, PackageNotFoundError
try:
    from pip._vendor.packaging.requirements import Requirement
    with open(sys.argv[1],encoding='utf-8') as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith('#'):continue
            req=Requirement(line)
            if req.marker and not req.marker.evaluate():continue
            if not req.specifier.contains(version(req.name),prereleases=True):sys.exit(1)
except (ImportError,PackageNotFoundError,OSError,ValueError):
    sys.exit(1)
PY
}

# Check before stopping the app. A code-only update never accesses package servers.
if [ "$INSTALL_MODE" = "update" ]; then
  if [ ! -f "$TARGET_DIR/app.py" ] || ! dependencies_ready; then
    echo '기존 앱이나 필요한 Python 패키지가 없어요. bash install.sh로 먼저 설치하세요.'
    exit 1
  fi
  echo '앱 파일만 업데이트합니다. apt·pip 설치와 다운로드를 건너뜁니다.'
else
  if [ ! -x "$TARGET_DIR/.venv/bin/python" ]; then
    mkdir -p "$TARGET_DIR"
    python3 -m venv "$TARGET_DIR/.venv"
  fi
  if [ "$INSTALL_MODE" = "deps" ] || ! dependencies_ready; then
    "$TARGET_DIR/.venv/bin/python" -m pip install -r "$SOURCE_DIR/requirements.txt"
  else
    echo '필요한 Python 패키지가 있어요. pip 설치와 다운로드를 건너뜁니다.'
  fi
fi
if [ -f /etc/systemd/system/swing-lab-v3.service ]; then
  sudo systemctl stop swing-lab-v3
fi
mkdir -p "$TARGET_DIR"
TARGET_DIR="$(cd "$TARGET_DIR" && pwd)"
if [ "$SOURCE_DIR" != "$TARGET_DIR" ]; then
  if [ -f "$TARGET_DIR/app.py" ]; then
    tar --exclude='./data' --exclude='./.venv' --exclude='./__pycache__' -czf "${TARGET_DIR}-source-$(date +%Y%m%d-%H%M%S).tar.gz" -C "$TARGET_DIR" .
  fi
  cp "$SOURCE_DIR"/*.py "$SOURCE_DIR/requirements.txt" "$SOURCE_DIR/README.md" "$SOURCE_DIR/CHANGELOG.md" "$SOURCE_DIR/install.sh" "$SOURCE_DIR/enable-auto-update.sh" "$TARGET_DIR/"
  mkdir -p "$TARGET_DIR/web"
  cp "$SOURCE_DIR/web/"* "$TARGET_DIR/web/"
  mkdir -p "$TARGET_DIR/reports"
  cp "$SOURCE_DIR/reports/"* "$TARGET_DIR/reports/"
  cp "$SOURCE_DIR/OVERNIGHT_PROGRESS.md" "$SOURCE_DIR/BUILD_MANIFEST.json" "$SOURCE_DIR/CHANGES-v3.14.md" "$SOURCE_DIR/CHANGES-v3.14.1.md" "$SOURCE_DIR/CHANGES-v3.14.2.md" "$SOURCE_DIR/CHANGES-v3.14.3.md" "$SOURCE_DIR/CHANGES-v3.14.4.md" "$SOURCE_DIR/CHANGES-v3.14.5.md" "$SOURCE_DIR/CHANGES-v3.15.0.md" "$SOURCE_DIR/CHANGES-v3.16.0.md" "$SOURCE_DIR/CHANGES-v3.16.1.md" "$SOURCE_DIR/CHANGES-v3.16.2.md" "$SOURCE_DIR/CHANGES-v3.17.0.md" "$SOURCE_DIR/CHANGES-v3.17.1.md" "$SOURCE_DIR/CHANGES-v3.18.0.md" "$TARGET_DIR/"
  for extra in archive research_new research_10 research_expansion research_pattern; do
    if [ -d "$SOURCE_DIR/$extra" ]; then
      mkdir -p "$TARGET_DIR/$extra"
      cp -R "$SOURCE_DIR/$extra/." "$TARGET_DIR/$extra/"
    fi
  done
fi
# The replacement package archives these retired implementations; user data is untouched.
for old in app.js phone.js compare.js candidates.js features.js; do
  if [ -f "$TARGET_DIR/web/$old" ]; then
    mkdir -p "$TARGET_DIR/archive/retired-web"
    mv "$TARGET_DIR/web/$old" "$TARGET_DIR/archive/retired-web/$old"
  fi
done
for old in research.py reproduce_analysis.py exit_analysis.py analysis_audit.py build_report.py build_dynamic_report.py build_selective_report.py; do
  if [ -f "$TARGET_DIR/$old" ]; then
    mkdir -p "$TARGET_DIR/archive/retired-source"
    mv "$TARGET_DIR/$old" "$TARGET_DIR/archive/retired-source/$old"
  fi
done
CONFIG_DIR="$HOME/.config/swing-lab-v3"
mkdir -p "$CONFIG_DIR"
chmod 700 "$CONFIG_DIR"
if [ ! -f "$CONFIG_DIR/server.env" ]; then
  umask 077
  NEW_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
  printf 'SWING_USER=radar\nSWING_PASSWORD=%s\n' "$NEW_PASSWORD" > "$CONFIG_DIR/server.env"
fi
chmod 600 "$CONFIG_DIR/server.env"
UNIT_FILE="$(mktemp)"
trap 'rm -f "$UNIT_FILE"' EXIT
cat > "$UNIT_FILE" <<EOF
[Unit]
Description=Swing Lab v3
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=$(id -un)
WorkingDirectory=$TARGET_DIR
EnvironmentFile=$CONFIG_DIR/server.env
Environment=PYTHONUNBUFFERED=1
ExecStart=$TARGET_DIR/.venv/bin/uvicorn app:app --host 0.0.0.0 --port $PORT --workers 1
Restart=on-failure
RestartSec=5
UMask=0077
[Install]
WantedBy=multi-user.target
EOF
sudo install -m 644 "$UNIT_FILE" /etc/systemd/system/swing-lab-v3.service
sudo systemctl daemon-reload
sudo systemctl enable swing-lab-v3
sudo systemctl restart swing-lab-v3
printf '\n설치 완료: http://서버IP:%s\n아이디: radar\n비밀번호 확인: cat %s/server.env\n로그: sudo journalctl -u swing-lab-v3 -n 80 --no-pager\n' "$PORT" "$CONFIG_DIR"
