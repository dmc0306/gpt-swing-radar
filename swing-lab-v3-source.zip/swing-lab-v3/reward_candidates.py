import price_store, strategies, operations
"""Read-only daily signal candidates with explicit R price scenarios."""
import json, math
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import engine, store, eligibility, session_calendar, candidate_diagnostics

MODES={k:v['name'] for k,v in strategies.DEFS.items()}

def _expected(now,observed):
    explicit=session_calendar.get()['days']
    d=now.date() if now.hour*60+now.minute>=940 else now.date()-timedelta(days=1)
    for _ in range(31):
        day=d.isoformat();known=explicit.get(day)
        if known==0 or (known is None and d.weekday()>4):d-=timedelta(days=1);continue
        return day,('사용자 달력' if known==1 else '일봉 관측' if day in observed else '평일 자료/거래일 확인 필요')
    raise ValueError('최근 거래일을 확인할 수 없습니다. 달력 자료를 확인하세요.')

def quote(signal,price,cfg,budget,reward,risk_cap=True):
    """Same initial risk/fee/whole-share sizing assumptions as the daily engine."""
    price=float(price);risk=1.5*signal['atr'];fill=price*(1+cfg['slippage_pct']/100)
    if not math.isfinite(price) or price<=0:raise ValueError('기준 가격은 양수여야 합니다.')
    limits={'현금':cfg['capital']/(fill*(1+cfg['fee_pct']/200)),
            '주문금액':min(budget,cfg['capital']*cfg['position_pct']/100)/fill,
            '위험예산':cfg['capital']*cfg['risk_pct']/100/risk,'거래량':signal['volume_limit']}
    qty=max(0,int(min(limits.values())));target=fill+risk*reward;stop=fill-risk
    cost=fill*(1+cfg['fee_pct']/200)
    net_target=target*(1-cfg['slippage_pct']/100)*(1-cfg['fee_pct']/200)-cost
    net_stop=stop*(1-cfg['slippage_pct']/100)*(1-cfg['fee_pct']/200)-cost
    reasons=[]
    if abs(price-signal['close'])>cfg['max_gap_atr']*signal['atr']:reasons.append('신호 종가 대비 허용 가격 차이 초과')
    if risk_cap and (risk/signal['close']*100>8 or risk/fill*100>8):reasons.append('최초 손절 위험폭8% 초과')
    if stop<=0:reasons.append('손절 기준가0 이하')
    if qty<1:reasons.append('현금·주문금액·위험·거래량 한도로1주 미만')
    if net_target<=0:reasons.append('선택R의 비용 후 목표손익0 이하')
    return {'reward':reward,'reference_price':price,'entry_fill':fill,'risk_per_share':risk,'stop':stop,'target':target,
            'qty':qty,'entry_amount':cost*qty,'target_net_pct':net_target/cost*100,'target_net_pnl':net_target*qty,
            'stop_net_pct':net_stop/cost*100,'stop_net_pnl':net_stop*qty,'sizing_limit':min(limits,key=limits.get),
            'price_conditions_pass':not reasons,'reasons':reasons}

def _signal_snapshot(ident,mode,cfg,today,closed):
    import candidate_pool
    pool,hit=candidate_pool.load(ident,cfg,today,closed)
    return candidate_pool.project(pool,strategies.get(mode)['spec']),hit

def scan(ident,payload):
    with operations.compute():return _scan(ident,payload)

def _scan(ident,payload,snapshot_info=None,now=None,gate=None,watch_limit=20):
    mode=str(payload.get('mode','focused'))
    if mode not in MODES:raise ValueError('후보 조건 오류')
    spec=strategies.get(mode)['spec'];risk_cap=spec['filter']=='risk_cap'
    cfg=engine.config(payload.get('config') or {})
    budget=float(payload['budget'] if payload.get('budget') is not None else cfg['capital']*cfg['position_pct']/100)
    if not math.isfinite(budget) or not 0<budget<=cfg['capital']:raise ValueError('주문금액은0 초과·원금 이하로 입력하세요.')
    now=now or datetime.fromisoformat(store.now()).astimezone(ZoneInfo('Asia/Seoul'));today=now.date().isoformat()
    snapshot,cache_hit=snapshot_info or _signal_snapshot(ident,mode,cfg,today,now.hour*60+now.minute>=940)
    latest=snapshot['latest'];days=snapshot['days'];stale=snapshot['stale'];short=snapshot['short'];signals=snapshot['signals']
    expected,calendar_note=_expected(now,set(days));blocks=[]
    if snapshot['filtered']:blocks.append('미완성 당일 봉 또는 미래 날짜를 제외했음 · 자료 재확인 필요')
    if latest!=expected:blocks.append('일봉 날짜 불일치: 필요한 날짜 '+expected+' / 선택 자료 '+latest)
    if session_calendar.get()['days'].get(latest)==0:blocks.append('가격 날짜와 휴장일 달력이 충돌함')
    if stale:blocks.append('선택 자료의 최신 봉 누락 '+str(len(stale))+'종목')
    path=store.ROOT/'collection.json'
    if path.exists():
        collection=json.loads(path.read_text())
        absent=set(collection.get('codes',[]))-set(snapshot['codes'])
        if collection.get('dataset_id')==ident and (collection.get('errors') or collection.get('remaining') or collection.get('status')!='완료' or absent):
            blocks.append('선택 자료의 수집 실패·중단·종목 누락 기록이 있음')
    gate=gate or eligibility.Gate(live=True,days=[today])
    result=[]
    for s in signals:
        missing=s.get('_missing_days',0)
        decision=gate.decision(s['code'],today,now.isoformat(timespec='seconds'))
        reason=list(blocks)
        if s.get('_bar_invalid'):reason.append('거래량 또는 당일 가격 범위 부족')
        if missing:reason.append('최근140개 관측일 중 종목 일봉 누락 '+str(missing)+'일')
        if not decision['allowed']:reason.append(decision['reason'])
        levels=[quote(s,s['close'],cfg,budget,spec['reward'],risk_cap)]
        low=s['close']-cfg['max_gap_atr']*s['atr']
        if risk_cap:low=max(low,(1.5*s['atr']/.08)/(1+cfg['slippage_pct']/100))
        result.append({**s,'data_reasons':reason,'screen_pass':not reason,'eligibility':decision,'levels':levels,
                       'reference_entry_range':[low,s['close']+cfg['max_gap_atr']*s['atr']]})
    watchlist=[]
    for row in snapshot.get('watchlist',[]):
        decision=gate.decision(row['code'],today,now.isoformat(timespec='seconds'))
        if not decision['allowed']:continue
        reasons=list(blocks)
        if row.get('_missing_days'):reasons.append('최근140개 관측일 중 일봉 누락 '+str(row['_missing_days'])+'일')
        if row.get('_bar_invalid'):reasons.append('거래량 또는 당일 가격 범위 부족')
        watchlist.append({**row,'data_reasons':reasons,'observation_only':True})
    watch_count=len(watchlist)
    calendar=session_calendar.get()['days'];today_open=calendar.get(today)
    if today_open==0 or (today_open is None and now.weekday()>4):timing='휴장일/주말 · 다음 거래일 시가와 제외 상태 확인 필요'
    elif now.hour*60+now.minute>=940:timing='종가 확정 후 다음 거래일 시가 검토 · 다음 거래일 제외 상태 재확인 필요'
    elif now.hour*60+now.minute<540:timing='장전 시가 대기 후보 · 개장일과 시가를 확인해야 함'
    else:timing='시가 진입 시점 경과 · 일봉 전략의 장중 매수 성능은 미검증'
    if not result:timing='현재 진입 신호 없음 · 다음 확정 일봉에서 다시 확인'
    return {'score_details':snapshot.get('score_details',{}),'watchlist':watchlist if watch_limit is None else watchlist[:watch_limit],'watchlist_count':watch_count,'condition_funnel':snapshot.get('condition_funnel',[]),'scanned_symbols':snapshot['symbols'],'signal_cache_hit':cache_hit,'funnel':snapshot['funnel'],'dataset_id':ident,'generated_at':now.isoformat(timespec='seconds'),'date':latest,'expected_date':expected,
            'mode':mode,'mode_name':MODES[mode],'config':cfg,'budget':budget,'rewards':[spec['reward']],'rows':result,
            'data_blocks':blocks,'stale_codes':stale,'short_histories':short,'calendar_note':calendar_note,'timing':timing,
            'note':'R은 익절 거리이며 진입 신호를 바꾸지 않습니다. 신호일 ATR14×1.5=1R. 가격은 최근 종가 기준 가정이며 실시간 체결가가 아닙니다.',
            'limitation':'일봉 조건 후보이며 매수 추천/체결 보장이 아닙니다. 기존 모의계좌와 독립적인 신규1건의 수량 견적입니다. 현재 보유·현금은 반영하지 않습니다. 각 후보 수량을 동시에 모두 매수할 수 있다는 뜻이 아닙니다.'}
