'use strict';
// Presentation only: strategy IDs, settings, recorded numbers and order logic stay intact.
const EasyUI=(()=>{
 const paths={home:'M3 11 12 3l9 8M5 10v11h5v-6h4v6h5V10',search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',wallet:'M3 6h16v15H3zM3 6V3h13v3M15 12h6v5h-6z',settings:'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M9 15v6',refresh:'M20 7v5h-5M4 17v-5h5M5 8a8 8 0 0 1 13-3l2 3M4 16l2 3a8 8 0 0 0 13-3',download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',check:'m4 12 5 5L20 6',clock:'M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',help:'M9 8a3 3 0 1 1 5 2c-2 1-2 2-2 3M12 17h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',alert:'M12 3 2 21h20L12 3M12 9v5M12 17h.01',bell:'M6 9a6 6 0 0 1 12 0v7l2 2H4l2-2V9M9 21h6',chart:'M3 3v18h18M6 16l5-5 4 2 6-8'};
 const icon=key=>`<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="${paths[key]||paths.help}"/></svg>`;
 const names={focused:'볼린저 하단 복귀',risk:'반등 · 전량 익절',risk_partial:'반등 · 분할 익절',breadth:'시장 흐름 · 전량 익절',breadth_partial:'시장 흐름 · 분할 익절'};
 const descriptions={focused:'평소 가격 범위 아래로 내려갔다 다시 들어온 종목을 찾습니다.',risk:'며칠 하락한 뒤 다시 오르는지 확인합니다. 처음 정한 손절 가격이 너무 먼 종목은 뺍니다.',risk_partial:'반등을 확인한 뒤, 목표 가격에 닿으면 절반을 팔고 나머지는 정한 규칙으로 지켜봅니다.',breadth:'반등 종목을 찾되, 살펴보는 종목들 중 절반 이상이 60일 평균 가격 위에 있을 때만 고릅니다.',breadth_partial:'여러 종목의 흐름을 함께 확인합니다. 목표 가격에서 절반을 팔고 나머지는 정한 규칙으로 지켜봅니다.'};
 const rules={
  '기본 이력·가격·거래대금':'계산할 자료가 충분하고, 가격과 거래금액 기준에 맞기',
  '종가 > 120일선':'종가이 120거래일 평균보다 높기',
  '3거래일 수익률 < -2.5%':'3거래일 전보다 2.5% 넘게 내려와 있기',
  '종가 > 당일 시가':'장 시작 가격보다 높은 가격으로 끝나기',
  '종가 > 전일 고가':'전 거래일의 가장 높은 가격보다 높게 끝나기',
  '종가 ≤ 60일선':'종가이 60거래일 평균보다 높지 않기',
  'ADX14 < 25':'한쪽으로 쏠리는 힘이 기준보다 약하기 (ADX 25 미만)',
  '전일 종가 < 전일 볼린저 하단':'전 거래일에는 평소 가격 범위의 아래쪽을 벗어나기',
  '종가 ≥ 볼린저 하단':'이번에는 그 가격 범위 안으로 돌아오기',
  '전일 거래량 / 그 이전 20일 평균 > 1':'전 거래일에 사고판 주식 수가 그 이전 20일 평균보다 많기',
  '초기 손절 거리 ≤ 8%':'처음 정한 손절 가격까지의 거리가 8% 이내이기',
  '표본 50종목 이상·60일선 위 비율 ≥ 50%':'50종목 이상을 살펴보고, 절반 이상이 60일 평균 가격 위에 있기',
  '검색 종목':'살펴본 종목','최신 일봉 있음':'가장 최근 날짜의 가격 자료 있음','진입 지표 신호':'사는 조건을 모두 만족','전략 필터 통과':'전략의 추가 조건까지 만족'};
 const reasons={
  'Failed to fetch':'서버 연결 실패. 작업 상태를 확인한 뒤 다시 시도하세요.',
  'Load failed':'서버 연결 실패. 잠시 후 다시 시도하세요.',
  'NetworkError when attempting to fetch resource.':'서버 연결 실패. 잠시 후 다시 시도하세요.',
  '현금':'현금', '주문금액':'종목별 투자금', '위험예산':'손실 예산', '거래량':'거래량',
  '거래량 또는 당일 가격 범위 부족':'거래량 또는 당일 가격 범위가 부족합니다.',
  '최초 손절 위험폭8% 초과':'초기 손절 거리가 8%를 초과합니다.',
  '현금·주문금액·위험·거래량 한도로1주 미만':'투자금·위험·거래량 한도 적용 후 매수 가능 수량이 1주 미만입니다.',
  '선택R의 비용 후 목표손익0 이하':'거래비용 차감 후 목표 수익이 0 이하입니다.',
  '신호 종가 대비 허용 가격 차이 초과':'계산할 때의 종가과 너무 차이가 나요.',
  '제외 상태 미확인':'거래정지·제외 상태를 확인하지 못했습니다.',
  'API 복합 선별 통과':'API 제외 상태 확인 완료',
  'CSV 전체 상태 확인':'CSV 제외 상태 확인 완료',
  '손절(동시 도달 포함)':'손절 (같은 날 익절·손절 도달 시 손절 우선)',
  '갭 손절':'갭 하락 손절',
  '갭 익절':'갭 상승 익절',
  '절반 익절 · 시가':'시가 분할 익절',
  '절반 익절':'분할 익절',
  '익절':'목표가 익절',
  '추적 청산':'추적 손절',
  '추적 갭 청산':'갭 하락 추적 손절',
  '만기':'보유 기간 종료'};
 function reason(value){return reasons[value]||String(value??'');}
 function date(value){return String(value??'—').replace('T',' ').replace(/\+09:00$/,'').replace(/\.\d+/,'');}
 function exit(spec){if(!spec||!['timeout','partial_trail'].includes(spec.exit_policy||'timeout'))return '이전 전략입니다. 상세 계산 조건을 확인하세요.';const r=Number(spec?.reward),partial=spec?.exit_policy==='partial_trail';return `${partial?'목표 가격에 닿으면 절반을 팔고, 남은 주식은 오름세를 따라 손절 기준을 올립니다.':'목표 가격에 닿으면 모두 팝니다.'} 손절 가격에 닿거나 최대 ${spec?.hold??15}거래일이 지나도 팝니다. ${Number.isFinite(r)?'목표 이익 폭은 처음 정한 손절 거리의 '+Math.round(r*100)+'%입니다.':''}`;}
 function decorate(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{if(!el.querySelector('.ui-icon'))el.insertAdjacentHTML('afterbegin',icon(el.dataset.icon));});}
 const shortRules={'기본 이력·가격·거래대금':'자료·가격·거래대금 충분','종가 > 120일선':'120일 평균 위','3거래일 수익률 < -2.5%':'3일 전보다 2.5% 넘게 하락','종가 > 당일 시가':'시가보다 높게 마감','종가 > 전일 고가':'전일 고가 위로 마감','초기 손절 거리 ≤ 8%':'손절 거리 8% 이내','종가 ≤ 60일선':'60일 평균 이하','ADX14 < 25':'추세 강도 ADX 25 미만','전일 종가 < 전일 볼린저 하단':'전일 볼린저 하단 이탈','종가 ≥ 볼린저 하단':'볼린저 하단 안으로 복귀','전일 거래량 / 그 이전 20일 평균 > 1':'전일 거래량이 20일 평균 초과','표본 50종목 이상·60일선 위 비율 ≥ 50%':'50종목 이상·절반이 60일선 위','검색 종목':'전체 검색','최신 일봉 있음':'최신 일봉 있음','진입 지표 신호':'진입 신호','전략 필터 통과':'전략 조건 통과'};
 return {shortCondition:value=>shortRules[value]||rules[value]||value,icon,name:(id,fallback)=>names[id]||fallback||'이전 전략',description:id=>descriptions[id]||'',condition:value=>rules[value]||value,reason,date,exit,decorate};
})();
EasyUI.decorate();
