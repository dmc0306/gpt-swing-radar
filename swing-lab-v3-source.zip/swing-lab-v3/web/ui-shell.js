'use strict';
// One editable control per preference. Other pages show a read-only summary.
window.SwingUX=(()=>{
 const localKeys=['dataset','limit','years','scanMode','refreshExclusions','onlyPass','compareStart','compareEnd','historyMembership','historyEligibility'];
 const storageKey='swing-v320-workspace';
 let saved={},restored=false;
 try{saved=JSON.parse(localStorage.getItem(storageKey)||'{}');}catch{}
 function section(key){
  if(!document.querySelector(`[data-settings-panel="${key}"]`))key='data';
  document.querySelectorAll('[data-settings-panel]').forEach(el=>el.hidden=el.dataset.settingsPanel!==key);
  document.querySelectorAll('[data-settings]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.settings===key)));
 }
 function sync(){
  const ds=state?.datasets||[],selected=ds.find(d=>d.id===$('dataset').value)||[...ds].sort((a,b)=>(b.end+b.created).localeCompare(a.end+a.created))[0];
  $('dataContextSummary').textContent=selected?`${selected.end} · ${fmt(selected.symbols)}종목 · 확정 일봉`:'가격 자료 없음 · 자료 준비에서 시작하세요';
  $('collectionSettingsSummary').textContent=`최대 ${fmt($('limit').value)}종목 · ${$('years').value}년 · ${fmt($('minPrice').value)}원 이상 · 일평균 ${fmt($('minTurnover').value)}억원 이상`;
  const mode=$('scanMode').value;
  $('activeMethodSummary').textContent=mode==='all'?'5개 방법 함께 비교':EasyUI.name(mode);
  $('activeRiskSummary').textContent=`종목당 ${fmt($('budget').value)}원 한도 · 거래 손실 예산 ${fmt($('risk').value,2)}%`;
  $('resultFilterSummary').textContent=$('onlyPass').checked?'통과 후보만 표시':'보류 종목 포함';
 }
 function restore(){
  if(restored||!state)return;
  for(const id of localKeys){const el=$(id),v=saved[id];if(v===undefined)continue;if(el.type==='checkbox')el.checked=!!v;else if(el.tagName!=='SELECT'||[...el.options].some(o=>o.value===String(v)))el.value=v;}
  restored=true;renderSearchHeading();sync();
 }
 function save(){
  const values=Object.fromEntries(localKeys.map(id=>[id,$(id).type==='checkbox'?$(id).checked:$(id).value]));
  localStorage.setItem(storageKey,JSON.stringify(values));saved=values;mark(false);sync();
 }
 function mark(dirty){const bar=document.querySelector('.settings-savebar');bar.dataset.dirty=String(dirty);$('settingsSaveState').textContent=dirty?'이 기기에 저장하지 않은 변경이 있습니다.':'이 기기에 저장했습니다. 다음 조회부터 적용됩니다.';}
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.settings)section(b.dataset.settings);if(b.dataset.settingsFocus)section(b.dataset.settingsFocus);});
 for(const id of [...localKeys,...calcKeys,'minPrice','minTurnover'])$(id).addEventListener('change',()=>{mark(true);sync();});
 return {section,sync,restore,save};
})();
SwingUX.restore();SwingUX.sync();
