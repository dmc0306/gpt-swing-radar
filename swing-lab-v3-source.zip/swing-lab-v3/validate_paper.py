import sys,tempfile,copy,json
from pathlib import Path
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root))
import store,engine,paper,paper_status
store.ROOT=Path(tempfile.mkdtemp());paper.GROUP=store.ROOT/'paper_group.json';paper.PATH=store.ROOT/'paper.json'
cfg=engine.config({});spec={'strategy':'recovery','reward':2,'hold':10,'filter':'risk_cap'}
# Real virtual fill/exit and metrics, supplied deterministic bars and signals.
b=engine.fresh(cfg);signal={'code':'000001','name':'검사','date':'2026-10-07','close':10000,'atr':100,'volume_limit':10000,'reason':'검사'}
bar={'open':10000,'high':10100,'low':9900,'close':10000,'volume':1000000,'atr14':100}
engine.advance(b,'2026-10-07',{'000001':bar},[signal],spec,cfg);assert len(b['pending'])==1
engine.advance(b,'2026-10-08',{'000001':bar},[],spec,cfg);assert len(b['positions'])==1 and b['cash']<cfg['capital']
engine.advance(b,'2026-10-09',{'000001':{**bar,'open':10500,'high':10600,'low':10400,'close':10500}},[],spec,cfg);assert len(b['trades'])==1 and not b['positions'];assert engine.metrics(b)['trades']==1
now=datetime(2026,10,11,18,tzinfo=ZoneInfo('Asia/Seoul'))
g={'schema':2,'id':'a'*24,'active':True,'last_date':'2026-10-09','accounts':[{'id':'b'*24,'label':'A','active':True,'book':b}]}
d=paper_status.describe(g,{'auto':True},[{'end':'2026-10-09'}],now);assert d['operating']['next_check']['at'].startswith('2026-10-12T15:40');assert d['accounts'][0]['diagnostics']['last_trade']=='2026-10-09'
for key,expected in [('read_only','incompatible'),('blocked','blocked')]:
 test=copy.deepcopy(g);test[key]=True if key=='read_only' else {'reason':'자료 누락'}
 assert paper_status.describe(test,{'auto':True},[],now)['operating']['status']==expected
ended=copy.deepcopy(g);ended['active']=False;ended['accounts'][0]['active']=False
assert paper_status.describe(ended,{'auto':True},[],now)['operating']['status']=='ended'
# Full paper update: actual atomic writes/evidence/idempotency, deterministic data boundary.
today=datetime.now(ZoneInfo('Asia/Seoul')).date();day=(today-timedelta(days=2)).isoformat();previous=(today-timedelta(days=3)).isoformat()
book=engine.fresh(cfg);book['last_date']=previous;book['pending']=[{**signal,'date':previous}]
account={'id':'b'*24,'label':'A','name':'test','active':True,'config':cfg,'spec':spec,'book':book,'snapshots':[],'warnings':[]}
group={'schema':2,'id':'a'*24,'active':True,'code_hash':store.code_hash(),'config':cfg,'codes':['000001'],'last_date':previous,'accounts':[account, {**copy.deepcopy(account),'id':'c'*24,'label':'B'}],'snapshots':[],'anchor_file':'start'}
paper._save(group);paper.quality.get=lambda x:{};paper.price_store.Subset=lambda *a:[];paper._basis_change=lambda *a:None;paper._anchor=lambda *a:[]
prepared={'dates':[day],'bars':{day:{'000001':bar}},'eligibility':{day:{'000001':{'allowed':True}}}}
paper.price_store.prepared_since=lambda *a:copy.deepcopy(prepared);paper.membership.apply=lambda *a:{}
class Gate:
 def __init__(self,**kw):pass
 def apply(self,*a):pass
paper.eligibility.Gate=Gate;paper.engine.select_signals=lambda *a:[];paper.alerts.paper_events=lambda *a:None
paper.session_calendar.decisions=lambda last,through,observed:iter([(day,'open')]) if last<day else iter([])
progress=[];paper.update('test',lambda **kw:progress.append(kw));saved=paper.get();assert saved['last_date']==day;assert all(len(a['book']['positions'])==1 for a in saved['accounts']);assert len(saved['snapshots'])==1
paper.update('test');assert len(paper.get()['snapshots'])==1
assert progress[-1]['done']==progress[-1]['total']==1
print('PASS: real signal/virtual-fill/exit/metrics; state diagnostics; atomic two-account settlement and retry idempotency')
