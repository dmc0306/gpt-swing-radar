"""Disk-backed immutable price snapshots; bounded-memory collection and reads."""
import gzip, hashlib, json, os, sqlite3, tempfile, threading
from pathlib import Path
import ijson
import store

INDEX_LOCK=threading.RLock()

def connect(path):
    c=sqlite3.connect(str(path),timeout=60)
    c.execute('PRAGMA cache_size=-2048')
    c.execute('PRAGMA temp_store=FILE')
    return c

class Builder:
    def __init__(self):
        folder=store.ROOT/'price_staging';folder.mkdir(parents=True,exist_ok=True)
        fd,self.path=tempfile.mkstemp(suffix='.sqlite',dir=folder);os.close(fd)
        self.con=connect(self.path)
        self.con.execute('CREATE TABLE bars(date TEXT,code TEXT,payload TEXT,PRIMARY KEY(date,code)) WITHOUT ROWID')
    def add(self,rows):
        # Each symbol is an atomic batch; conflicting duplicate rows fail closed.
        with self.con:
            for r in rows:
                raw=store.encode(r).decode()
                old=self.con.execute('SELECT payload FROM bars WHERE date=? AND code=?',(r['date'],r['code'])).fetchone()
                if old and old[0]!=raw:raise ValueError('같은 날짜·종목의 가격 불일치')
                if not old:self.con.execute('INSERT INTO bars VALUES(?,?,?)',(r['date'],r['code'],raw))
    def close(self):
        if self.con is not None:self.con.close()
        for suffix in ('','-journal'):
            try:os.unlink(self.path+suffix)
            except FileNotFoundError:pass
    def finish(self,source,note,progress=lambda **kw:None):
        count=self.con.execute('SELECT count(*) FROM bars').fetchone()[0]
        if not count:raise ValueError('수집한 일봉이 없습니다.')
        self.con.execute('CREATE INDEX by_code ON bars(code,date)');self.con.commit()
        folder=store.ROOT/'prices';folder.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(dir=folder);os.close(fd);h=hashlib.sha256()
        try:
            with open(tmp,'wb') as out:
                with gzip.GzipFile(fileobj=out,mode='wb',compresslevel=3) as gz:
                    def put(b):h.update(b);gz.write(b)
                    put(b'[')
                    for i,(raw,) in enumerate(self.con.execute('SELECT payload FROM bars ORDER BY date,code')):
                        if i:put(b',')
                        put(raw.encode())
                        if i%10000==0:progress(stage='일봉 압축 저장',done=i,total=count)
                    put(b']')
                out.flush();os.fsync(out.fileno())
            ident=h.hexdigest();dest=folder/(ident+'.json.gz')
            if dest.exists():os.unlink(tmp)
            else:os.replace(tmp,dest)
            dates=[r[0] for r in self.con.execute('SELECT DISTINCT date FROM bars ORDER BY date')]
            counts=list(self.con.execute('SELECT code,count(*) FROM bars GROUP BY code ORDER BY code'))
            meta={'id':ident,'created':store.now(),'source':source,'universe_note':note,'rows':count,
                  'symbols':len(counts),'start':dates[0],'end':dates[-1],'days':len(dates),'codes':[x[0] for x in counts],
                  'short_histories':sum(x[1]<140 for x in counts),'point_in_time_universe':False}
            index=store.ROOT/'price_indexes';index.mkdir(parents=True,exist_ok=True)
            self.con.close();self.con=None
            os.replace(self.path,index/(ident+'.sqlite'))
            self.con=connect(index/(ident+'.sqlite'))
            with store.db() as c:c.execute('INSERT OR IGNORE INTO datasets VALUES(?,?,?)',(ident,meta['created'],json.dumps(meta,ensure_ascii=False)))
            progress(stage='일봉 저장 완료',done=count,total=count)
            return meta
        finally:
            if os.path.exists(tmp):os.unlink(tmp)

def ensure_index(ident):
    store.check_id(ident);folder=store.ROOT/'price_indexes';dest=folder/(ident+'.sqlite')
    if dest.exists():return dest
    with INDEX_LOCK:
        if dest.exists():return dest
        b=Builder()
        try:
            with gzip.open(store.ROOT/'prices'/(ident+'.json.gz'),'rb') as f:
                batch=[]
                for row in ijson.items(f,'item',use_float=True):
                    batch.append(row)
                    if len(batch)>=1000:b.add(batch);batch=[]
                if batch:b.add(batch)
            b.con.execute('CREATE INDEX by_code ON bars(code,date)');b.con.commit();b.con.close()
            folder.mkdir(parents=True,exist_ok=True);os.replace(b.path,dest)
        finally:
            # close() is safe for an already closed sqlite connection.
            b.close()
    return dest

class Dataset:
    def __init__(self,ident,before=None,inclusive=True):
        self.path=ensure_index(ident);self.before=before;self.inclusive=inclusive
    def query(self,sql,args=()):
        c=connect(self.path)
        try:yield from c.execute(sql,args)
        finally:c.close()
    def where(self):
        return (' WHERE date'+('<=' if self.inclusive else '<')+'?',(self.before,)) if self.before else ('',())
    def __iter__(self):
        w,a=self.where()
        for raw, in self.query('SELECT payload FROM bars'+w+' ORDER BY date,code',a):yield json.loads(raw)
    def __len__(self):
        w,a=self.where();return next(self.query('SELECT count(*) FROM bars'+w,a))[0]
    def days(self):
        w,a=self.where();return [x[0] for x in self.query('SELECT DISTINCT date FROM bars'+w+' ORDER BY date',a)]
    def codes(self):
        w,a=self.where();return [x[0] for x in self.query('SELECT DISTINCT code FROM bars'+w+' ORDER BY code',a)]
    def symbol(self,code):
        w,a=self.where();w+=(' AND ' if w else ' WHERE ')+'code=?'
        return [json.loads(x[0]) for x in self.query('SELECT payload FROM bars'+w+' ORDER BY date',a+(code,))]
    def items(self):
        for code in self.codes():yield code,self.symbol(code)
    def __getitem__(self,code):return self.symbol(code)


def latest_prepared(ident,cfg,progress=lambda **kw:None):
    """Retain latest bars/signals only; all indicator history is evaluated per symbol."""
    import engine
    data=Dataset(ident);days=data.days()
    if not days:raise ValueError('가격 자료 없음')
    day=days[-1];bars={};breadth={};signals={k:[] for k in engine.STRATEGIES}
    codes=data.codes()
    for i,(code,rs) in enumerate(data.items()):
        progress(stage='최근 후보 종목별 계산',done=i,total=len(codes))
        p=engine.prepare(rs,cfg)
        bars.update(p['bars'].get(day,{}));breadth.update(p['breadth'].get(day,{}))
        for k in signals:signals[k].extend(p['signals'][k].get(day,[]))
        del p,rs
    for ss in signals.values():
        ss.sort(key=lambda s:(-s['score'],s['code']))
        for sig in ss:sig.update(breadth_count=len(breadth),breadth_pct=100*sum(breadth.values())/len(breadth) if breadth else 0)
    return {'dates':[day],'bars':{day:bars},'breadth':{day:breadth},'signals':{k:{day:ss} for k,ss in signals.items()}}

class Subset(Dataset):
    def __init__(self,ident,codes):
        super().__init__(ident);self.selected=set(codes)
    def codes(self):return [c for c in super().codes() if c in self.selected]
    def __iter__(self):
        for row in super().__iter__():
            if row['code'] in self.selected:yield row

def prepared_since(ident,cfg,after,codes,through):
    """Keep only uncommitted days in memory; compute indicators with full symbol history."""
    import engine
    data=Subset(ident,codes);dates=[d for d in data.days() if after<d<=through]
    # Dormant accounts can span years; do not allocate an unbounded catch-up window.
    try:
        info={x.split(':')[0]:int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith(('MemTotal:','MemAvailable:'))}
        budget=min(info['MemTotal']*.2,info['MemAvailable']*.4)
    except (OSError,KeyError,ValueError):budget=100*1024**2
    if len(dates)*len(codes)*2000>budget:raise ValueError('미정산 기간이 너무 길어 메모리 보호로 보류했습니다. 계좌 기록을 내보내고 새 관찰을 시작하세요.')
    bars={d:{} for d in dates};breadth={d:{} for d in dates};signals={s:{} for s in engine.STRATEGIES}
    for code,rs in data.items():
        p=engine.prepare(rs,cfg)
        for d in dates:
            bars[d].update(p['bars'].get(d,{}));breadth[d].update(p['breadth'].get(d,{}))
            for s in signals:
                if d in p['signals'][s]:signals[s].setdefault(d,[]).extend(p['signals'][s][d])
        del p,rs
    for smap in signals.values():
        for d,ss in smap.items():
            ss.sort(key=lambda s:(-s['score'],s['code']))
            for sig in ss:sig.update(breadth_count=len(breadth[d]),breadth_pct=100*sum(breadth[d].values())/len(breadth[d]) if breadth[d] else 0)
    return {'dates':dates,'bars':bars,'breadth':breadth,'signals':signals}
