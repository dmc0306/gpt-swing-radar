"""Share only same-session adjusted daily-bar first pages, never eligibility."""
import json,threading,time,re,shutil
from collections import Counter
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
import store

COUNTS=Counter();LOCK=threading.RLock()
MAX_SYMBOLS=3000
LAST_PRUNE=0.
def prune():
    # Only expendable caches created by this feature. History/evidence are untouched.
    global LAST_PRUNE
    if time.monotonic()-LAST_PRUNE<3600:return
    LAST_PRUNE=time.monotonic()
    cutoff=(datetime.now(ZoneInfo('Asia/Seoul')).date()-timedelta(days=3)).isoformat()
    folder=store.ROOT/'daily_page_cache'
    if folder.exists():
        for p in folder.iterdir():
            if p.is_dir() and not p.is_symlink() and re.fullmatch(r'\d{4}-\d{2}-\d{2}-(closed|before-close)',p.name) and p.name[:10]<cutoff:shutil.rmtree(p)
def count(key):
    with LOCK:COUNTS[key]+=1
def snapshot():
    with LOCK:return dict(COUNTS)
def delta(before):
    after=snapshot();return {k:v-before.get(k,0) for k,v in after.items() if v-before.get(k,0)}
def session():
    now=datetime.now(ZoneInfo('Asia/Seoul'))
    return now.date().isoformat()+('-closed' if now.hour*60+now.minute>=940 else '-before-close')
def first_page(code,refresh=False,cutoff=None):
    from kiwoom import _post
    prune()
    path=store.ROOT/'daily_page_cache'/session()/(code+'.json')
    value=json.loads(path.read_text()) if path.exists() and not refresh else None
    # Continuation keys are short-lived; a stale cached key must be refreshed.
    covered=bool(value and cutoff and value.get('bars') and min(str(r.get('dt','99999999')) for r in value['bars'])<=cutoff)
    if value and value.get('schema')==1 and (covered or time.time()-value.get('saved_epoch',0)<1800):
        count('page_cache_hits');return value['bars'],value['cont'],value['key']
    now=datetime.now(ZoneInfo('Asia/Seoul'))
    response,data=_post('/api/dostk/chart','ka10081',{'stk_cd':code,'base_dt':now.strftime('%Y%m%d'),'upd_stkpc_tp':'1'})
    bars=data.get('stk_dt_pole_chart_qry')
    if not isinstance(bars,list) or not bars:raise ValueError('유효한 일봉 응답 없음')
    value={'schema':1,'adjusted':True,'bars':bars,'cont':response.headers.get('cont-yn'),'key':response.headers.get('next-key'),'saved_epoch':time.time()}
    store.write(path,value);count('page_requests');time.sleep(.3)
    return bars,value['cont'],value['key']
