"""Five fixed observation strategies; historical source data is not a live score."""
import copy,json,secrets
from pathlib import Path
import store,engine,operations
CATALOG=json.loads((Path(__file__).parent/'reports/curated-five.json').read_text())
DEFS={s['id']:s for s in CATALOG['strategies']}

def catalog():return copy.deepcopy(CATALOG)
def get(key):
    if key not in DEFS:raise ValueError('남겨 둔 5개 전략 중 선택하세요.')
    return copy.deepcopy(DEFS[key])
def latest_dataset():
    ds=store.datasets()
    if not ds:raise ValueError('오늘 화면에서 가격 자료를 먼저 준비하세요.')
    return max(ds,key=lambda d:(d['end'],d['created']))['id']
def scan(payload):
    import reward_candidates
    s=get(str(payload.get('strategy_id','focused')));ident=payload.get('dataset_id') or latest_dataset()
    data=reward_candidates.scan(ident,{'mode':s['id'],'config':payload.get('config',{}),'budget':payload.get('budget')})
    data['strategy']=s;data['price_basis']='최신 확정 일봉 종가 가정 · 실시간 호가 아님'
    data['fixed_reward']=s['spec']['reward'];data['exit_rule']=s['exit'];data['snapshot_id']=secrets.token_hex(12)
    store.write(store.ROOT/'candidate_snapshots'/(s['id']+'.json'),data)
    return data

def start_pair(payload):
    import paper,comparison
    ids=payload.get('strategies',[])
    if len(ids)!=2 or len(set(ids))!=2:raise ValueError('서로 다른 전략2개를 선택하세요.')
    ss=[get(key) for key in ids];ident=payload.get('dataset_id') or latest_dataset()
    store.check_id(ident)
    from price_store import Dataset
    ds=Dataset(ident);days=ds.days()
    if not days:raise ValueError('가격 자료 없음')
    cfg=engine.config(payload.get('config') or {})
    record={'id':secrets.token_hex(12),'created':store.now(),'schema':4,'suite':'curated','dataset_id':ident,
      'code_hash':store.code_hash(),'config':cfg,'membership_id':None,'start':days[0],'end':days[-1],
      'label':'고정5전략 신규 관찰 · 새 백테스트 아님','eligible_ids':[],
      'variants':[{'id':s['id'],'name':s['name'],'spec':s['spec'],'eligible':False,
        'ineligible_reasons':['과거 적격 미확증 · 시작일 이후 모의관찰'],'historical_source':s['source']} for s in ss]}
    store.write(comparison._path(record['id']),record)
    return paper.start_pair(record['id'],ids)

def compare(payload,progress=lambda **kw:None):
    """Five fixed specs, same dates/capital/cost. Always labeled reused historical analysis."""
    import membership,eligibility,comparison
    ident=payload.get('dataset_id') or latest_dataset();cfg=engine.config(payload.get('config') or {})
    rows=store.load_dataset(ident)  # Explicit memory budget before full-history simulation.
    progress(stage='5개 고정 전략 지표 계산',done=0,total=5)
    prepared=engine.prepare(rows,cfg);del rows
    dates=prepared['dates'][120:]
    start=payload.get('start') or (dates[-252] if len(dates)>=252 else dates[0] if dates else '')
    end=payload.get('end') or (dates[-1] if dates else '')
    dates=[d for d in dates if start<=d<=end]
    if len(dates)<63:raise ValueError('지표 준비120거래일 이후 평가구간63거래일 이상이 필요합니다.')
    membership_id=payload.get('membership_id') or None
    membership_report=membership.apply(prepared,membership_id)
    if membership_report.get('missing_codes'):raise ValueError('과거 구성 종목의 가격 자료가 누락됐습니다.')
    eid=payload.get('eligibility_id') or None
    exclusion=eligibility.Gate(eid).apply(prepared) if eid else None
    out=[]
    for i,s in enumerate(DEFS.values()):
        progress(stage='고정 조건 비교 · '+s['name'],done=i,total=5)
        result=engine.simulate(prepared,dates,s['spec'],cfg)
        stress=engine.simulate(prepared,dates,s['spec'],{**cfg,'fee_pct':cfg['fee_pct']*2,'slippage_pct':cfg['slippage_pct']*2})
        out.append({'id':s['id'],'name':s['name'],'spec':s['spec'],'result':result,'stress':stress['metrics'],'fixed_cost':engine.fixed_cost_diagnostic(result,cfg,2),
           'eligible':False,'ineligible_reasons':['동일 과거 재분석 · 독립 검증 없음'],'reason':s['conditions']+' '+s['exit']})
    d={'id':secrets.token_hex(12),'schema':4,'suite':'curated','created':store.now(),'label':'5개 고정 전략 · 과거 재분석',
       'dataset_id':ident,'code_hash':store.code_hash(),'config':cfg,'start':dates[0],'end':dates[-1],
       'membership_id':membership_id,'membership_report':membership_report,'eligibility_id':eid,'exclusion_counts':exclusion,
       'eligible_ids':[],'variants':out,'limitations':CATALOG['limitations']+['현재 제공 가격자료를 재사용한 계산입니다. 손실거래를 사후 제외하지 않습니다.','비용2배는 재시뮬레이션이며 거래 수가 달라질 수 있습니다.','과거 제외 이력 미적용.' if not eid else '사용자 제공 제외 이력 적용; 완전성 인증은 아닙니다.']}
    store.write(comparison._path(d['id']),d)
    return {'comparison_id':d['id']}
