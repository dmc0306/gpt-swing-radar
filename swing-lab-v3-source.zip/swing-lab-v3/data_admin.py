"""Explicit reset scopes, reversible directory moves, and allowlisted diagnostic exports."""
import json,os,re,secrets,tempfile,time,zipfile
from pathlib import Path
import store,jobs
import ijson
PLANS={}
CACHE_DIRS=('history_cache','history_parts','daily_page_cache','signal_cache','screen_cache','price_indexes','price_staging','research_cache')
PHRASES={'cache':'캐시 초기화','all':'전체 자료 초기화'}
BACKUPS=store.ROOT.parent/(store.ROOT.name+'-reset-backups')

def inventory(paths):
    count=total=0
    for base in paths:
        if not base.exists() or base.is_symlink():continue
        for p in ([base] if base.is_file() else base.rglob('*')):
            if p.is_file() and not p.is_symlink():count+=1;total+=p.stat().st_size
    return {'files':count,'bytes':total}

def preview(scope):
    if scope not in PHRASES:raise ValueError('초기화 범위 오류')
    paths=[store.ROOT] if scope=='all' else [store.ROOT/x for x in CACHE_DIRS]
    stat=inventory(paths);key=secrets.token_hex(16)
    PLANS.clear();PLANS[key]={'scope':scope,'expires':time.monotonic()+600}
    return {**stat,'token':key,'scope':scope,'phrase':PHRASES[scope],
      'effect':'가격·분석·모의계좌·알림 기록을 복구용 폴더로 옮기고 빈 자료로 시작. 자동 갱신/알림은 꺼집니다. 서버 로그인/API/텔레그램 인증은 보존.' if scope=='all' else '재생성 가능한 조회/계산 캐시만 보관함으로 이동. 가격 데이터셋·분석·계좌는 유지됩니다.'}

def backups():
    out=[]
    if BACKUPS.exists():
        for p in sorted(BACKUPS.glob('*/reset.json'),reverse=True):
            try:
                d=json.loads(p.read_text());out.append({k:d.get(k) for k in ('id','scope','created','files','bytes','restored')})
            except (ValueError,OSError):pass
    return out[:20]

def reset(payload):
    plan=PLANS.get(str(payload.get('token','')))
    if not plan or plan['expires']<time.monotonic():raise ValueError('초기화 미리보기를 다시 열어주세요.')
    scope=plan['scope']
    if payload.get('confirm')!=PHRASES[scope]:raise ValueError('표시된 확인 문구를 정확히 입력하세요.')
    with jobs.LOCK:
        if jobs.JOB.get('running'):raise ValueError('진행 중 작업을 일시정지한 뒤 초기화하세요.')
        BACKUPS.mkdir(parents=True,exist_ok=True)
        key=str(time.time_ns())+'-'+secrets.token_hex(4);folder=BACKUPS/key;folder.mkdir(mode=0o700)
        paths=[store.ROOT] if scope=='all' else [store.ROOT/x for x in CACHE_DIRS]
        meta={'id':key,'scope':scope,'created':store.now(),**inventory(paths)}
        store.write(folder/'reset.json',meta)
        if scope=='all':
            if store.ROOT.exists():os.replace(store.ROOT,folder/'data')
            store.ROOT.mkdir(parents=True,exist_ok=True)
            store.write(store.ROOT/'settings.json',{'codes':[],'years':5,'auto':False})
            # Existing personal connection remains outside data; no automatic messages on reset.
            jobs.JOB.clear();jobs.JOB.update(running=False,paused=False,stage='전체 자료 초기화 완료',done=0,total=0,error=None,result=None,task=None)
            jobs.persist()
        else:
            for p in paths:
                if p.exists():os.replace(p,folder/p.name)
        PLANS.pop(payload['token'],None)
        return {'ok':True,'backup':meta,'note':'데이터는 복구용 보관함으로 이동했습니다. 디스크 공간을 바로 비우는 영구 삭제는 아닙니다.'}

def restore(payload):
    key=str(payload.get('backup_id',''))
    if not re.fullmatch(r'[0-9]+-[0-9a-f]{8}',key):raise ValueError('복구 번호 오류')
    folder=BACKUPS/key;path=folder/'reset.json'
    if not path.exists():raise ValueError('복구 기록 없음')
    meta=json.loads(path.read_text())
    if payload.get('confirm')!='자료 복구':raise ValueError('자료 복구를 입력하세요.')
    if meta.get('restored'):raise ValueError('이미 복구한 기록입니다.')
    with jobs.LOCK:
        if jobs.JOB.get('running'):raise ValueError('진행 중 작업을 일시정지하세요.')
        key2=str(time.time_ns())+'-'+secrets.token_hex(4);current=BACKUPS/key2;current.mkdir(mode=0o700)
        store.write(current/'reset.json',{'id':key2,'scope':meta['scope'],'created':store.now(),**inventory([store.ROOT] if meta['scope']=='all' else [store.ROOT/x for x in CACHE_DIRS])})
        if meta['scope']=='all':
            if not (folder/'data').is_dir():raise ValueError('복구할 자료 폴더 없음')
            if store.ROOT.exists():os.replace(store.ROOT,current/'data')
            os.replace(folder/'data',store.ROOT)
            settings=store.ROOT/'settings.json'
            d=json.loads(settings.read_text()) if settings.exists() else {'codes':[],'years':5};d['auto']=False;store.write(settings,d)
            phone=store.ROOT/'phone_alert_settings.json'
            if phone.exists():
                d=json.loads(phone.read_text());d['enabled']=False;d['revision']=secrets.token_hex(12);store.write(phone,d)
            jobs.JOB.clear();jobs.JOB.update(running=False,paused=False,stage='자료 복구 완료 · 자동 갱신 꺼짐',done=0,total=0,error=None,result=None,task=None);jobs.persist()
        else:
            for name in CACHE_DIRS:
                if (store.ROOT/name).exists():os.replace(store.ROOT/name,current/name)
                if (folder/name).exists():os.replace(folder/name,store.ROOT/name)
        meta['restored']=store.now();store.write(path,meta)
    return {'ok':True,'note':'자료 복구 완료. 전체 복구 후 자동 갱신과 알림은 직접 켜세요.'}

SENSITIVE=re.compile(r'token|password|secret|authorization|appkey|chat_id|recipient',re.I)
def scrub(x):
    if isinstance(x,dict):return {k:scrub(v) for k,v in x.items() if not SENSITIVE.search(k)}
    if isinstance(x,list):return [scrub(v) for v in x]
    if isinstance(x,str):return re.sub(r'\b[0-9]{6,}:[A-Za-z0-9_-]{20,}','[토큰 제거]',x)
    return x


def stream_record(path,output,on_value):
    """Redact known credential fields while streaming even large JSON records."""
    stack=[];skip_next=False;skip_depth=0
    def emit(value):output.write(value.encode('utf-8'))
    def before_value():
        if stack and stack[-1]['kind']=='array':
            if stack[-1]['count']:emit(',')
            stack[-1]['count']+=1
    with path.open('rb') as source:
        for prefix,event,value in ijson.parse(source,use_float=True):
            if skip_depth:
                if event in ('start_map','start_array'):skip_depth+=1
                elif event in ('end_map','end_array'):skip_depth-=1
                continue
            if skip_next:
                skip_next=False
                if event in ('start_map','start_array'):skip_depth=1
                continue
            if event=='map_key':
                if SENSITIVE.search(value):skip_next=True;continue
                if stack[-1]['count']:emit(',')
                stack[-1]['count']+=1
                emit(json.dumps(value,ensure_ascii=False)+':')
            elif event in ('start_map','start_array'):
                before_value();emit('{' if event=='start_map' else '[')
                stack.append({'kind':'map' if event=='start_map' else 'array','count':0})
            elif event in ('end_map','end_array'):
                stack.pop();emit('}' if event=='end_map' else ']')
            elif event in ('string','number','boolean','null'):
                on_value(prefix,value);before_value()
                emit(json.dumps(scrub(value),ensure_ascii=False,allow_nan=False))

def export(payload):
    with jobs.LOCK:
        if jobs.JOB.get('running'):raise ValueError('수집/계산을 일시정지하거나 완료한 뒤 내보내세요.')
        return _export(payload)

def _export(payload):
    from strategies import latest_dataset
    ident=payload.get('dataset_id') or (latest_dataset() if store.datasets() else None)
    if ident:store.check_id(ident)
    root=Path(__file__).parent;outdir=store.ROOT.parent/'swing-export-temp';outdir.mkdir(exist_ok=True)
    fd,out=tempfile.mkstemp(prefix='swing-analysis-',suffix='.zip',dir=outdir);os.close(fd)
    datasets=set([ident] if ident else []);omitted=[];evidence_ids=set();membership_ids=set();exclusion_ids=set()
    def ref_value(prefix,value):
        key=prefix.rsplit('.',1)[-1]
        if not isinstance(value,str):return
        if key.endswith('dataset_id') and re.fullmatch('[0-9a-f]{64}',value):datasets.add(value)
        elif key=='membership_id':membership_ids.add(value)
        elif key=='eligibility_id':exclusion_ids.add(value)
        elif prefix.endswith('sources.item') and re.fullmatch('[0-9a-f]{64}',value):evidence_ids.add(value)
    try:
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
            def put(name,value):z.writestr(name,json.dumps(scrub(value),ensure_ascii=False,separators=(',',':')))
            def put_file(path,name):
                with z.open(name,'w',force_zip64=True) as dest:stream_record(path,dest,ref_value)
            # Latest user records and active account evidence; no credentials, raw HTTP logs, or whole caches.
            paths=[store.ROOT/n for n in ('collection.json','universe.json','job.json','settings.json','paper_group.json','paper.json','session_calendar.json','phone_alert_settings.json','phone_alert_state.json')]
            for folder in ('runs','comparisons','comparison_summaries'):
                paths+=sorted((store.ROOT/folder).glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:3]
            paths+=list((store.ROOT/'candidate_snapshots').glob('*.json'))
            for folder in ('candidate_boards','candidate_price_checks'):
                paths+=sorted((store.ROOT/folder).glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:3]
            for check in list(paths):
                if check.parent.name!='candidate_price_checks':continue
                try:board_id=json.loads(check.read_text()).get('board_id','')
                except (ValueError,OSError):continue
                if re.fullmatch('[0-9a-f]{24}',board_id):
                    related=store.ROOT/'candidate_boards'/(board_id+'.json')
                    if related not in paths:paths.append(related)
            paths+=sorted((store.ROOT/'phone_evidence').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:3]
            with store.db() as con:catalog=[json.loads(r[0]) for r in con.execute('SELECT meta FROM datasets ORDER BY created DESC')]
            put('data/dataset-catalog.json',catalog)
            with store.db() as con:
                exists=con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='phone_outbox'").fetchone()
                if exists:
                    fields=('created','title','status','attempts','error')
                    deliveries=[dict(zip(fields,r)) for r in con.execute('SELECT created,title,status,attempts,error FROM phone_outbox ORDER BY created DESC LIMIT 30')]
                    put('data/phone-deliveries.json',deliveries)
            for p in paths:
                if not p.is_file() or p.is_symlink():continue
                put_file(p,'data/'+str(p.relative_to(store.ROOT)))
            current_id=None;current_path=store.ROOT/'paper_group.json'
            if not current_path.exists():current_path=store.ROOT/'paper.json'
            if current_path.exists():
                with current_path.open('rb') as f:current_id=next(ijson.items(f,'id'),None)
            evidence_folder='paper_shared_evidence' if (store.ROOT/'paper_group.json').exists() else 'paper_evidence'
            for p in ((store.ROOT/evidence_folder).glob(str(current_id)+'-*.json') if current_id else []):
                # Only the current account's evidence is exported; every archive remains local.
                if p.is_symlink():continue
                put_file(p,'data/'+evidence_folder+'/'+p.name)
            for ref_id in sorted(evidence_ids|exclusion_ids):
                if not re.fullmatch('[0-9a-f]{64}',ref_id):continue
                for folder in ('eligibility/imports','eligibility/observations'):
                    p=store.ROOT/folder/(ref_id+'.json')
                    if p.is_file() and not p.is_symlink():put_file(p,'data/'+folder+'/'+p.name)
            for ref_id in sorted(membership_ids):
                if not re.fullmatch('[0-9a-f]{64}',ref_id):continue
                p=store.ROOT/'membership'/(ref_id+'.json')
                if p.is_file() and not p.is_symlink():put_file(p,'data/membership/'+p.name)
            for p in (store.ROOT/'eligibility/failures').glob('*.json'):
                if not p.is_symlink():put_file(p,'data/eligibility/failures/'+p.name)
            for d in sorted(datasets):
                for sub in ('quality',):
                    p=store.ROOT/sub/(d+'.json')
                    if p.is_file() and not p.is_symlink():put_file(p,'data/'+sub+'/'+p.name)
                p=store.ROOT/'prices'/(d+'.json.gz')
                if payload.get('include_prices',True) and p.is_file() and not p.is_symlink():z.write(p,'data/prices/'+p.name,compress_type=zipfile.ZIP_STORED)
                else:omitted.append(d)
            # Source is allowlisted code only. Never traverse user home/configuration.
            for name in ('full_compare.py', 'alerts.py', 'app.py', 'comparison.py', 'data_admin.py', 'data_source.py', 'eligibility.py', 'engine.py', 'focus_indicators.py', 'jobs.py', 'kiwoom.py', 'market_cache.py', 'membership.py', 'operations.py', 'paper.py', 'phone_alerts.py', 'price_store.py', 'quality.py', 'reward_candidates.py','candidate_diagnostics.py','candidate_pool.py','candidate_board.py','pattern_features.py','pattern_rank.py', 'series.py', 'session_calendar.py', 'setup_phone_alerts.py', 'store.py', 'strategies.py', 'telegram_web.py', 'universe.py', 'workflows.py'):
                p=root/name
                if p.is_file() and not p.is_symlink():z.write(p,'source/'+name)
            for name in ('BUILD_MANIFEST.json','requirements.txt'):
                p=root/name
                if p.exists():z.write(p,'source/'+name)
            z.write(root/'reports/curated-five.json','source/reports/curated-five.json')
            z.write(root/'reports/pattern-model.json','source/reports/pattern-model.json')
            put('export-manifest.json',{'created':store.now(),'selected_dataset_id':ident,'referenced_datasets':sorted(datasets),'omitted_prices':omitted,'source_hash':store.code_hash(),'scope':'최근 실험/비교 각3개, 현재 계좌/공통증거, 전략별 마지막 후보, 참조 가격(선택). 개인정보 인증파일/토큰/비밀번호 제외.'})
            z.writestr('README.txt','이 ZIP을 대화에 첨부하세요. 조회 시각·일봉 날짜·후보 보류 사유·가격/거래 기록을 함께 분석할 수 있습니다. omitted_prices가 있으면 해당 과거 가격은 포함되지 않았습니다.\n')
        return Path(out)
    except BaseException:
        Path(out).unlink(missing_ok=True);raise
