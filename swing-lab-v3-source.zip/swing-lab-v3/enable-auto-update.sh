#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" = 0 ]; then echo '앱을 설치한 일반 사용자로 실행하세요.'; exit 1; fi
UPDATE_REPO="${1:-dmc0306/gpt-swing-radar}"
[[ "$UPDATE_REPO" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || { echo 'owner/repository 형식 필요'; exit 1; }
APP_DIR="${SWING_INSTALL_DIR:-$HOME/swing-lab-v3}"
APP_PORT="${SWING_PORT:-8000}"
UPDATE_DIR="$HOME/.config/swing-lab-v3/updater"
[[ "$APP_PORT" =~ ^[0-9]+$ ]] && (( APP_PORT >= 1024 && APP_PORT <= 65535 )) || exit 1
[[ "$APP_DIR" != *' '* && "$APP_DIR" != *$'\n'* && "$UPDATE_DIR" != *' '* ]] || { echo '경로 공백은 지원하지 않습니다.'; exit 1; }
test -f "$APP_DIR/auto_update.py"
test -x "$APP_DIR/.venv/bin/python"
if [ -n "${SWING_DATA_DIR:-}" ]; then echo '사용자 지정 데이터 경로는 이 버전 자동 업데이트에서 지원하지 않습니다.'; exit 1; fi
if [ -f "$HOME/.config/swing-lab-v3/server.env" ]; then
  if ! "$APP_DIR/.venv/bin/python" - "$HOME/.config/swing-lab-v3/server.env" <<'PY'
import re,sys
from pathlib import Path
if re.search(r'^\s*(?:export\s+)?SWING_DATA_DIR\s*=',Path(sys.argv[1]).read_text(),re.M):sys.exit(1)
PY
  then echo '사용자 지정 데이터 경로 설정이 있어 자동 업데이트를 활성화하지 않습니다.'; exit 1; fi
fi
mkdir -p "$UPDATE_DIR"
chmod 700 "$UPDATE_DIR"
cp "$APP_DIR/auto_update.py" "$UPDATE_DIR/agent.py"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
printf '#!/usr/bin/env bash\nset -euo pipefail\nAPP_USER=%q\nAPP_DIR=%q\nUPDATE_DIR=%q\nAPP_PORT=%q\nUPDATE_REPO=%q\n' "$(id -un)" "$APP_DIR" "$UPDATE_DIR" "$APP_PORT" "$UPDATE_REPO" > "$WORK_DIR/runner"
cat >> "$WORK_DIR/runner" <<'SCRIPT'
agent() {
  /usr/sbin/runuser -u "$APP_USER" -- "$APP_DIR/.venv/bin/python" "$UPDATE_DIR/agent.py" "$1" --target "$APP_DIR" --state "$UPDATE_DIR" --repo "$UPDATE_REPO"
}
# A failed or missing download leaves the running app untouched.
result=0
agent stage || result=$?
if [ "$result" = 10 ]; then exit 0; fi
if [ "$result" != 0 ]; then exit "$result"; fi
# Stop before replacing code; graceful app shutdown checkpoints active work.
/usr/bin/systemctl stop swing-lab-v3.service
restart_on_exit() { /usr/bin/systemctl start swing-lab-v3.service || true; }
trap restart_on_exit EXIT
if ! agent install; then exit 1; fi
/usr/bin/systemctl start swing-lab-v3.service
ready=0
for attempt in {1..15}; do
  if /usr/bin/systemctl is-active --quiet swing-lab-v3.service; then
    status=$(/usr/bin/curl --max-time 2 --silent --output /dev/null --write-out '%{http_code}' "http://127.0.0.1:$APP_PORT/" || true)
    if [ "$status" = 200 ] || [ "$status" = 401 ]; then ready=1; break; fi
  fi
  sleep 1
done
if [ "$ready" = 0 ]; then
  /usr/bin/systemctl stop swing-lab-v3.service
  agent rollback
  /usr/bin/systemctl start swing-lab-v3.service
  exit 1
fi
agent complete
SCRIPT
cat > "$WORK_DIR/service" <<'UNIT'
[Unit]
Description=Swing Lab validated automatic code update
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/libexec/swing-lab-auto-update
TimeoutStartSec=10min
UMask=0077
UNIT
cat > "$WORK_DIR/timer" <<'UNIT'
[Unit]
Description=Swing Lab daily automatic update check
[Timer]
OnBootSec=1min
OnUnitActiveSec=5min
AccuracySec=1s
RandomizedDelaySec=0
Unit=swing-lab-auto-update.service
[Install]
WantedBy=timers.target
UNIT
command -v curl >/dev/null || { echo 'curl 설치가 필요합니다.'; exit 1; }
sudo install -d -m 755 /usr/local/libexec
sudo install -m 755 "$WORK_DIR/runner" /usr/local/libexec/swing-lab-auto-update
sudo install -m 644 "$WORK_DIR/service" /etc/systemd/system/swing-lab-auto-update.service
sudo install -m 644 "$WORK_DIR/timer" /etc/systemd/system/swing-lab-auto-update.timer
sudo systemctl daemon-reload
sudo systemctl enable --now swing-lab-auto-update.timer
printf '자동 업데이트 설정 완료: 5분마다 · %s\n' "$UPDATE_REPO"
printf '즉시 확인: sudo systemctl start swing-lab-auto-update.service\n'
