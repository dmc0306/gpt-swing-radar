"""Recompute the fixed eight hypotheses from the authorized export ZIP.
Actual study is preserved in reports/ten-position-comparison.json.
This portable entry point was not application/regression tested.
"""
import os,sys,json,sqlite3,time,hashlib,argparse,zipfile,shutil
from pathlib import Path
from collections import Counter,defaultdict
parser=argparse.ArgumentParser()
parser.add_argument('--export',required=True,help='swing-analysis-export (1).zip')
parser.add_argument('--work-dir',default='swing-research-replay')
args=parser.parse_args()
HERE=Path(__file__).resolve().parent
BASE=Path(args.work_dir).resolve();BASE.mkdir(parents=True,exist_ok=True)
APP=HERE/'source'
os.environ['SWING_DATA_DIR']=str(BASE/'data')
sys.path.insert(0,str(APP))
import engine,price_store,store
plan=json.loads((HERE/'protocol.json').read_text())
with zipfile.ZipFile(args.export) as archive:
    original=json.loads(archive.read('data/comparisons/55dde1a1d8b29927894f766f.json'))
    if original['dataset_id']!=plan['dataset_id']:raise ValueError('분석 대상 가격 스냅샷이 다릅니다.')
    dest=store.ROOT/'prices'/(plan['dataset_id']+'.json.gz');dest.parent.mkdir(parents=True,exist_ok=True)
    with archive.open('data/prices/'+dest.name) as src,dest.open('wb') as output:shutil.copyfileobj(src,output,1024*1024)
DEFS=[{'id':v['id'],'name':v['name'],'spec':v['spec']} for v in original['variants']]+plan['hypotheses']
cfg=engine.config({**original['config'],'max_positions':10})
stress={**cfg,'fee_pct':2*cfg['fee_pct'],'slippage_pct':2*cfg['slippage_pct']}
dates=[p['date'] for p in original['variants'][0]['result']['curve']]
ds=price_store.Dataset(plan['dataset_id']);codes=ds.codes();last=0
key=store.digest([plan,cfg,hashlib.sha256((APP/'engine.py').read_bytes()).hexdigest()])
cache=BASE/(key+'.sqlite')
con=sqlite3.connect(cache)
con.executescript('CREATE TABLE IF NOT EXISTS bars(day TEXT,code TEXT,payload TEXT,PRIMARY KEY(day,code)); CREATE TABLE IF NOT EXISTS signals(day TEXT,kind TEXT,code TEXT,payload TEXT,PRIMARY KEY(day,kind,code)); CREATE TABLE IF NOT EXISTS breadth(day TEXT,code TEXT,up INTEGER,PRIMARY KEY(day,code)); CREATE TABLE IF NOT EXISTS done(code TEXT PRIMARY KEY);')
completed={r[0] for r in con.execute('SELECT code FROM done')};con.close()
for i,code in enumerate(codes):
    if code in completed:continue
    prepared=engine.prepare(ds.symbol(code),cfg)
    con=sqlite3.connect(cache)
    with con:
        for day in dates:
            bar=prepared['bars'].get(day,{}).get(code)
            if bar:con.execute('INSERT INTO bars VALUES(?,?,?)',(day,code,store.encode(bar).decode()))
            up=prepared['breadth'].get(day,{}).get(code)
            if up is not None:con.execute('INSERT INTO breadth VALUES(?,?,?)',(day,code,int(up)))
            for kind,mapping in prepared['signals'].items():
                for sig in mapping.get(day,[]):con.execute('INSERT INTO signals VALUES(?,?,?,?)',(day,kind,code,store.encode(sig).decode()))
        con.execute('INSERT INTO done VALUES(?)',(code,))
    con.close();del prepared
    if time.monotonic()-last>25:print('지표 계산',i+1,'/',len(codes),flush=True);last=time.monotonic()
con=sqlite3.connect('file:'+str(cache)+'?mode=ro',uri=True)
segments=[{'id':'full','start':dates[0],'end':dates[-1]}]+[{'id':'q'+str(i+1),'start':dates[i*63],'end':dates[(i+1)*63-1]} for i in range(4)]
books={(seg['id'],s['id'],cost):engine.fresh(c) for seg in segments for s in DEFS for cost,c in [('base',cfg),('stress',stress)]}
breadth={day:(n,u) for day,n,u in con.execute('SELECT day,count(*),sum(up) FROM breadth GROUP BY day')}
count=defaultdict(Counter);monthly=defaultdict(Counter)
for i,day in enumerate(dates):
 bars={code:json.loads(raw) for code,raw in con.execute('SELECT code,payload FROM bars WHERE day=?',(day,))}
 signals={kind:{day:[]} for kind in engine.STRATEGIES};n,u=breadth.get(day,(0,0))
 raw=list(con.execute('SELECT kind,payload FROM signals WHERE day=?',(day,)))
 for kind,value in raw:
  sig=json.loads(value);sig.update(breadth_count=n,breadth_pct=100*u/n if n else 0);signals[kind][day].append(sig)
 for mapping in signals.values():mapping[day].sort(key=lambda s:(-s['score'],s['code']))
 prepared={'bars':{day:bars},'signals':signals,'dates':[day]}
 for s in DEFS:
  passed=engine.select_signals(prepared,day,s['spec']);monthly[day[:7]][s['id']]+=len(passed)
  for seg in segments:
   if not seg['start']<=day<=seg['end']:continue
   count[seg['id']][s['id']]+=len(passed)
   for cost,c in [('base',cfg),('stress',stress)]:engine.advance(books[(seg['id'],s['id'],cost)],day,bars,passed,s['spec'],c)
 if time.monotonic()-last>25:print('고정 8조건 비교',i+1,'/',len(dates),flush=True);last=time.monotonic()
con.close()
variants=[]
for s in DEFS:
 b=books[('full',s['id'],'base')]
 result={'metrics':engine.metrics(b),'curve':b['curve'],'trades':b['trades'],'open':b['positions'],'pending':b['pending'],'events':b['events']}
 periods=[]
 for seg in segments[1:]:
  bb=books[(seg['id'],s['id'],'base')]
  periods.append({**seg,'signals':count[seg['id']][s['id']],'metrics':engine.metrics(bb),'stress':engine.metrics(books[(seg['id'],s['id'],'stress')])})
 v={**s,'result':result,'stress':engine.metrics(books[('full',s['id'],'stress')]),'fixed_cost':engine.fixed_cost_diagnostic(result,cfg,2),'signals':count['full'][s['id']],'periods':periods}
 m=v['result']['metrics'];recent=periods[-1]['metrics'];sr=periods[-1]['stress']
 v['observation_gate']={'full_sample':m['trades']>=60,'recent_sample':recent['trades']>=15,'full_net_positive':m['total_return_pct']>0 and (m['avg_trade_pct'] or 0)>0,'recent_net_positive':recent['total_return_pct']>0 and (recent['avg_trade_pct'] or 0)>0,'cost_stress_positive':v['stress']['total_return_pct']>0 and sr['total_return_pct']>0,'drawdown':m['max_drawdown_pct']>=-10 and recent['max_drawdown_pct']>=-10}
 v['observation_gate_pass']=all(v['observation_gate'].values())
 v['win80_observed']=m['trades']>0 and m['win_rate']>=80
 variants.append(v)
 print(s['id'],json.dumps({k:m[k] for k in ['trades','win_rate','total_return_pct','max_drawdown_pct','avg_trade_pct']},ensure_ascii=False),'recent',json.dumps({k:recent[k] for k in ['trades','win_rate','total_return_pct','max_drawdown_pct']},ensure_ascii=False),'gate',v['observation_gate'],flush=True)
record={'created':store.now(),'label':'10종목 한도 · 기존5개와 사전 가설3개 재분석','protocol':plan,'dataset_id':plan['dataset_id'],'source_comparison_id':original['id'],'source_engine_sha256':hashlib.sha256((APP/'engine.py').read_bytes()).hexdigest(),'config':cfg,'start':dates[0],'end':dates[-1],'scope':original['scope'],'segments':segments,'variants':variants,'monthly_signals':dict(monthly),'breadth':[{'date':d,'count':n,'above60_pct':100*u/n if n else 0} for d,(n,u) in breadth.items()],'limitations':['기존 평가기간 및 최신63거래일 모두 이미 확인한 과거자료 재사용. 독립검증 아님.','각63거래일은 원금1000만원·빈계좌에서 시작. 구간말 미청산은 종가평가하며 승률 건수에 포함하지 않음. 구간 수익의 합은 연간계좌수익이 아님.','현재 선택1662종목 편향 및 과거 거래정지 등 제외이력 부재. 표본확산도는 시장지수가 아님.','일봉 신호 후 다음 거래일 시가 진입. 동일일 장중 순서는 손절 우선 가정. 분봉검증 없음.','거래비용 왕복0.2%,편도슬리피지0.05%. 비용2배는 재시뮬레이션이며 건수가 달라질 수 있음.','최대보유10은 강제매수나 분산보장 아님. 원금·1종목20%·거래당위험0.5%·거래량제약 그대로.','현금/미실현 포함 계좌수익과 동일가중 평균거래수익은 다른 지표.','당시 조정주가와 구성종목을 독립 자료로 대조하지 못함. 가격 갭은 실제손실이 계획손절을 넘게할 수 있음.']}
store.write(BASE/'comparison.json',record)
print('DONE',BASE/'comparison.json',flush=True)
