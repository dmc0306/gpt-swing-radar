import gzip, hashlib, json, os, sqlite3, tempfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path(os.getenv('SWING_DATA_DIR',str(Path(__file__).parent/'data')))

def now():return datetime.now(ZoneInfo('Asia/Seoul')).isoformat(timespec='seconds')
def encode(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(v):return hashlib.sha256(encode(v)).hexdigest()
CODE_FILES=('engine.py','focus_indicators.py','strategies.py','reports/curated-five.json','paper.py','membership.py','comparison.py','session_calendar.py','eligibility.py','universe.py','workflows.py','data_source.py','store.py','price_store.py','quality.py')
def code_hash():return hashlib.sha256(b''.join((Path(__file__).parent/n).read_bytes() for n in CODE_FILES)).hexdigest()

def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:
        f.write(encode(value));f.flush();os.fsync(f.fileno());tmp=f.name
    os.replace(tmp,path)

@contextmanager
def db():
    ROOT.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(ROOT/'catalog.db',timeout=30)
    con.execute('PRAGMA journal_mode=WAL')
    con.executescript('''CREATE TABLE IF NOT EXISTS datasets(id TEXT PRIMARY KEY,created TEXT,meta TEXT);
    CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,created TEXT,status TEXT,summary TEXT);
    CREATE TABLE IF NOT EXISTS exposures(dataset TEXT PRIMARY KEY,opened TEXT);''')
    try:
        yield con;con.commit()
    finally:con.close()

def datasets():
    with db() as c:return [json.loads(r[0]) for r in c.execute('SELECT meta FROM datasets ORDER BY created DESC LIMIT 30')]

def save_dataset(rows,source,universe_note):
    rows=sorted(rows,key=lambda x:(x['date'],x['code']))
    # Preserve the canonical dataset identity while avoiding two giant JSON buffers.
    folder=ROOT/'prices';folder.mkdir(parents=True,exist_ok=True);hasher=hashlib.sha256()
    with tempfile.NamedTemporaryFile(dir=folder,delete=False) as f:
        tmp=f.name
        try:
            with gzip.GzipFile(fileobj=f,mode='wb') as gz:
                def chunk(b):hasher.update(b);gz.write(b)
                chunk(b'[')
                for i,row in enumerate(rows):
                    if i:chunk(b',')
                    chunk(encode(row))
                chunk(b']')
            f.flush();os.fsync(f.fileno())
        except BaseException:
            os.unlink(tmp);raise
    ident=hasher.hexdigest();path=folder/(ident+'.json.gz')
    if path.exists():os.unlink(tmp)
    else:os.replace(tmp,path)
    dates=sorted({r['date'] for r in rows});codes=sorted({r['code'] for r in rows})
    counts={c:0 for c in codes}
    for r in rows:counts[r['code']]+=1
    meta={'id':ident,'created':now(),'source':source,'universe_note':universe_note,'rows':len(rows),
          'symbols':len(codes),'start':dates[0],'end':dates[-1],'days':len(dates),'codes':codes,
          'short_histories':sum(n<140 for n in counts.values()),'point_in_time_universe':False}
    with db() as c:c.execute('INSERT OR IGNORE INTO datasets VALUES(?,?,?)',(ident,now(),json.dumps(meta,ensure_ascii=False)))
    return meta

def load_dataset(ident):
    # Full-history engines still materialize data. Refuse oversized work before allocation.
    import price_store
    data=price_store.Dataset(ident);count=len(data)
    try:
        info={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:'))}
        budget=min(info['MemTotal']*.25,info['MemAvailable']*.5)
    except (OSError,KeyError,ValueError):budget=200*1024**2
    if count*2500>budget:
        raise ValueError(f'전체 기간 계산 메모리 보호: {count:,}행입니다. 현재 서버에서는 전체 백테스트/비교을 보류합니다. 종목 수·기간을 줄인 별도 자료 또는 메모리가 더 큰 환경을 사용하세요. 전체 종목 수집·후보 조회는 가능합니다. 자료를 임의 축소해 계산하지 않았습니다.')
    return list(data)


def save_run(run):
    write(ROOT/'runs'/(run['id']+'.json'),run)
    meta={k:run.get(k) for k in ('id','created','status','dataset_id','selected','fold_count','holdout_reused','config')}
    with db() as c:c.execute('INSERT OR REPLACE INTO runs VALUES(?,?,?,?)',(run['id'],run['created'],run['status'],json.dumps(meta,ensure_ascii=False)))

def get_run(ident):
    if not ident or any(c not in '0123456789abcdef' for c in ident):raise ValueError('잘못된 실험 번호')
    return json.loads((ROOT/'runs'/(ident+'.json')).read_text())

def runs():
    with db() as c:return [json.loads(r[0]) for r in c.execute('SELECT summary FROM runs ORDER BY created DESC LIMIT 50')]


def check_id(ident):
    if len(ident)!=64 or any(c not in '0123456789abcdef' for c in ident):raise ValueError('잘못된 자료 번호')
