# 고정 가설 재분석 코드

실제 완료 결과는 `../reports/ten-position-comparison.json`, 읽기 쉬운 보고서는 `../reports/ten-position-report.html`입니다. 가격 자료는 설치 ZIP에 복제하지 않습니다.

`source/engine.py`는 당시 계산에 사용한 엔진입니다. 기존 엔진에 사전 가설3개 계산용 진입/필터와 기본보유10만 추가했습니다. 손실 가설은 앱의 실전/모의 전략으로 승격하지 않았습니다. 앱이 이 연구용 파일을 실행하지 않습니다.

사용자가 올린 `swing-analysis-export (1).zip`을 지정해 같은 계산을 재현하도록 정리한 명령:

```bash
.venv/bin/python research_10/calculate.py --export /원본파일/경로/swing-analysis-export.zip --work-dir /계산결과/경로
```

입력 ZIP의 데이터ID/비교ID는 보고서에 기록된 값이어야 합니다. pandas, numpy, ijson이 필요합니다. 종목별 디스크 캐시를 사용하며 중단 시 완료 종목을 이어갑니다. 앱 서버를 실행하거나 기존 data/를 바꾸지 않습니다. 작업 폴더를 앱의 data/와 다른 곳으로 지정하세요.

`executed_calculation.py`는 이번 실제 계산에서 실행한 원본입니다. 기존 분석의 일봉/지표 캐시 경로를 사용했으므로 그대로 다른 서버에서 실행하는 파일은 아닙니다. `calculate.py`는 원본 ZIP에서 그 준비 단계를 수행하도록 옮긴 진입점이며, 사용자 요청에 따라 별도 앱/회귀/실행 검증은 하지 않았습니다.
