"""Web-only credential setup with a one-time proof sent by the user's private chat."""
import json,os,re,secrets,tempfile,threading,time
import httpx
from fastapi import HTTPException
import phone_alerts,store
LOCK=threading.RLock();PENDING={}

def secure(req):
    local=req.url.hostname in ('localhost','127.0.0.1','::1') and req.client and req.client.host in ('127.0.0.1','::1')
    if req.url.scheme!='https' and not local:raise HTTPException(400,'봇 토큰은 HTTPS 또는 SSH로 연결한 localhost 웹에서 입력하세요. HTTP 공개 주소에서는 저장을 차단합니다.')
    if not os.getenv('SWING_PASSWORD'):raise HTTPException(400,'웹 로그인 비밀번호를 설정한 서버에서 연결하세요.')

def request(token,method,body):
    try:
        r=httpx.post('https://api.telegram.org/bot'+token+'/'+method,json=body,timeout=15,follow_redirects=False)
        d=r.json()
        if not r.is_success or not d.get('ok'):raise ValueError('텔레그램 응답을 확인하지 못했습니다. 토큰·다른 봇 서비스 연결을 확인하세요.')
        return d['result']
    except (httpx.HTTPError,json.JSONDecodeError):raise ValueError('텔레그램 연결 실패. 토큰은 기록하지 않았습니다.') from None

def pending(key):
    d=PENDING.get(key)
    if not d or d['expires']<time.monotonic():
        PENDING.pop(key,None);raise ValueError('연결 확인이 만료됐습니다. 다시 시작하세요.')
    return d

def begin(req,payload):
    secure(req);token=str(payload.get('token','')).strip()
    if len(token)>200 or not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]{20,}',token):raise ValueError('봇 토큰 형식을 확인하세요.')
    bot=request(token,'getMe',{});key=secrets.token_hex(24);proof='swing-'+secrets.token_hex(10)
    with LOCK:
        PENDING.clear();PENDING[key]={'token':token,'proof':proof,'expires':time.monotonic()+600,'started':int(time.time())}
    return {'session':key,'proof':proof,'bot_username':bot.get('username'),'expires_seconds':600}

def verify(req,payload):
    secure(req)
    with LOCK:
        d=pending(str(payload.get('session','')))
        updates=request(d['token'],'getUpdates',{'timeout':0,'limit':100,'allowed_updates':['message']})
        found={}
        for u in updates:
            msg=u.get('message',{});chat=msg.get('chat',{})
            if msg.get('text')==d['proof'] and chat.get('type')=='private' and msg.get('date',0)>=d['started'] and chat.get('id')==msg.get('from',{}).get('id'):found[str(chat['id'])]=chat
        if len(found)!=1:raise ValueError('본인 봇의 개인 채팅에 확인문을 보내고 다시 확인하세요. 연결을 독점하는 다른 봇 프로그램이 있으면 중지해야 합니다.')
        chat=next(iter(found.values()));d['chat']=chat
        return {'verified':True,'display_name':' '.join(filter(None,[chat.get('first_name'),chat.get('last_name')])),'username':chat.get('username',''),'chat_suffix':str(chat['id'])[-4:]}

def commit(req,payload):
    secure(req)
    with LOCK,phone_alerts.LOCK:
        key=str(payload.get('session',''));d=pending(key)
        if payload.get('confirm_self') is not True or not d.get('chat'):raise ValueError('확인된 본인 개인 계정인지 체크하세요.')
        folder=phone_alerts.SECRET.parent;folder.mkdir(parents=True,exist_ok=True);os.chmod(folder,0o700)
        with tempfile.NamedTemporaryFile('w',dir=folder,delete=False) as f:
            os.chmod(f.name,0o600);json.dump({'token':d['token'],'chat_id':str(d['chat']['id']),'private_verified':True},f);f.flush();os.fsync(f.fileno());tmp=f.name
        os.replace(tmp,phone_alerts.SECRET);PENDING.pop(key,None)
        s=phone_alerts.get_settings();s.update(enabled=False,telegram=False,revision=secrets.token_hex(12));store.write(phone_alerts.PATH,s)
    return phone_alerts.view()

def disconnect():
    with LOCK,phone_alerts.LOCK:
        s=phone_alerts.get_settings();s.update(enabled=False,telegram=False,recipient=None,revision=secrets.token_hex(12));store.write(phone_alerts.PATH,s)
        phone_alerts.SECRET.unlink(missing_ok=True);PENDING.clear()
    return phone_alerts.view()
